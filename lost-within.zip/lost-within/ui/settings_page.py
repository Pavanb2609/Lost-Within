"""Settings: defaults, key-derivation strength, path limits, self-test, cleanup."""

from __future__ import annotations

from PySide6.QtCore import QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QPlainTextEdit, QSpinBox)

from core.journal import Journal, app_data_dir
from core.key_derivation import KDF_PRESETS, argon2_backend
from models.settings import CHUNK_CHOICES_MIB, AppSettings
from ui import styles as S
from ui.page import Page
from ui.widgets import ANIMATIONS, button, card, label
from ui.workers import TaskRunner


class SettingsPage(Page):
    changed = Signal()

    def __init__(self, settings: AppSettings, journal: Journal):
        super().__init__("Settings", "Defaults for new burials. Existing burials keep the settings they were "
                                     "created with (they are recorded in each descriptor).")
        self.settings = settings
        self.journal = journal
        self._loading = True

        # ---------------------------------------------------- security
        c, lay = card()
        lay.addWidget(label("KEY DERIVATION", "SectionLabel"))
        self.kdf = QComboBox()
        for key, params in KDF_PRESETS.items():
            self.kdf.addItem(f"{key.capitalize()} — {params.description}", key)
        self.kdf.currentIndexChanged.connect(self._save)
        lay.addWidget(self.kdf)
        lay.addWidget(label("Argon2id makes each password guess cost memory and time. Stronger presets slow "
                            "attackers more, but recovery needs that much free RAM on whichever computer you "
                            "recover on. Standard follows RFC 9106's recommendation.", "Hint", wrap=True))
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setColumnStretch(2, 1)
        self.min_pw = QSpinBox()
        self.min_pw.setRange(8, 64)
        self.min_pw.valueChanged.connect(self._save)
        grid.addWidget(label("Minimum password length", "FieldLabel"), 0, 0)
        grid.addWidget(self.min_pw, 0, 1)
        self.chunk = QComboBox()
        for mib in CHUNK_CHOICES_MIB:
            self.chunk.addItem(f"{mib} MiB", mib)
        self.chunk.currentIndexChanged.connect(self._save)
        grid.addWidget(label("Encryption chunk size", "FieldLabel"), 1, 0)
        grid.addWidget(self.chunk, 1, 1)
        grid.addWidget(label("Memory used per operation ≈ 3 × chunk size. 4 MiB suits most disks.", "Hint"), 1, 2)
        lay.addLayout(grid)
        self.rk_default = QCheckBox("Offer a Recovery Key by default")
        self.rk_default.toggled.connect(self._save)
        lay.addWidget(self.rk_default)
        self.body.addWidget(c)

        # ---------------------------------------------------- maze & paths
        c, lay = card()
        lay.addWidget(label("PATHS", "SectionLabel"))
        self.long_paths = QCheckBox("Long-path mode — allow maze paths up to 1000 characters")
        self.long_paths.toggled.connect(self._save)
        lay.addWidget(self.long_paths)
        lay.addWidget(label("By default every generated path stays under 240 characters, which every Windows "
                            "tool can handle. Long-path mode uses Windows' extended-length paths; Explorer, zip "
                            "tools and some backup software may then be unable to copy or delete the maze.",
                            "Hint", wrap=True))
        self.remember = QCheckBox("Remember the last maze and restore folders")
        self.remember.toggled.connect(self._save)
        lay.addWidget(self.remember)
        lay.addWidget(label("The default maze shape is taken from the Maze Configuration page each time you "
                            "bury something.", "Hint", wrap=True))
        self.body.addWidget(c)

        # ---------------------------------------------------- interface
        c, lay = card()
        lay.addWidget(label("INTERFACE", "SectionLabel"))
        self.animations = QCheckBox("Subtle animations (transitions, maze reveal, progress glow)")
        self.animations.toggled.connect(self._save)
        lay.addWidget(self.animations)
        self.body.addWidget(c)

        # ---------------------------------------------------- maintenance
        c, lay = card()
        lay.addWidget(label("INTERRUPTED OPERATIONS", "SectionLabel"))
        self.pending_label = label("", "Value", wrap=True)
        lay.addWidget(self.pending_label)
        row = QHBoxLayout()
        self.cleanup_btn = button("Clean up incomplete output", slot=self._cleanup)
        row.addWidget(self.cleanup_btn)
        row.addWidget(button("Open data folder", slot=lambda: QDesktopServices.openUrl(
            QUrl.fromLocalFile(str(app_data_dir())))))
        row.addStretch()
        lay.addLayout(row)
        self.body.addWidget(c)

        c, lay = card()
        lay.addWidget(label("TEST MODE", "SectionLabel"))
        lay.addWidget(label("Runs the complete bury → maze → recovery workflow on small generated files in a "
                            "temporary folder, including wrong-password, tampering, truncation and "
                            "cancellation checks. Your files are never touched.", "Hint", wrap=True))
        row = QHBoxLayout()
        self.test_btn = button("Run self-test", "Secondary", self._run_test)
        row.addWidget(self.test_btn)
        self.test_result = label("", "Value")
        row.addWidget(self.test_result)
        row.addStretch()
        lay.addLayout(row)
        self.test_log = QPlainTextEdit()
        self.test_log.setReadOnly(True)
        self.test_log.setMinimumHeight(220)
        self.test_log.hide()
        lay.addWidget(self.test_log)
        self.body.addWidget(c)
        self.body.addWidget(label(f"Settings file: {AppSettings.path()}  ·  Argon2id backend: {argon2_backend()}",
                                  "Hint", wrap=True, selectable=True))
        self.body.addStretch()

        self.runner = TaskRunner(self)
        self.runner.progress.connect(lambda line: self.test_log.appendPlainText(str(line)))
        self.runner.succeeded.connect(self._test_done)
        self.runner.failed.connect(lambda t, m, c: self._test_done(False, m))
        self.load()

    def load(self) -> None:
        self._loading = True
        s = self.settings
        self.kdf.setCurrentIndex(max(0, self.kdf.findData(s.kdf_preset)))
        self.min_pw.setValue(s.min_password_length)
        self.chunk.setCurrentIndex(max(0, self.chunk.findData(s.chunk_size_mib)))
        self.rk_default.setChecked(s.create_recovery_key)
        self.long_paths.setChecked(s.long_paths)
        self.remember.setChecked(s.remember_folders)
        self.animations.setChecked(s.animations)
        self._loading = False
        self.refresh_pending()

    def _save(self, *_) -> None:
        if self._loading:
            return
        s = self.settings
        s.kdf_preset = self.kdf.currentData()
        s.min_password_length = self.min_pw.value()
        s.chunk_size_mib = self.chunk.currentData()
        s.create_recovery_key = self.rk_default.isChecked()
        s.long_paths = self.long_paths.isChecked()
        s.remember_folders = self.remember.isChecked()
        s.animations = self.animations.isChecked()
        ANIMATIONS["enabled"] = s.animations
        s.save()
        self.changed.emit()

    def refresh_pending(self) -> None:
        pending = self.journal.pending()
        if not pending:
            self.pending_label.setText("None. No incomplete mazes or partial files were left by a crash.")
            self.cleanup_btn.setEnabled(False)
            return
        paths = [p for e in pending for p in e["paths"]]
        self.pending_label.setText(f"{len(pending)} interrupted operation(s) left incomplete output:\n"
                                   + "\n".join(f"  • {p}" for p in paths[:8]))
        self.pending_label.setStyleSheet(f"color: {S.WARN};")
        self.cleanup_btn.setEnabled(True)

    def _cleanup(self) -> None:
        for entry in self.journal.pending():
            self.journal.cleanup(entry)
        self.pending_label.setStyleSheet("")
        self.refresh_pending()

    def _run_test(self) -> None:
        if self.runner.running:
            return
        self.test_log.clear()
        self.test_log.show()
        self.test_btn.setEnabled(False)
        self.test_result.setText("Running…")
        self.test_result.setStyleSheet(f"color: {S.TEXT_DIM};")

        def job(emit, cancel):
            from core.selftest import run_self_test
            return run_self_test(emit)
        self.runner.start(job)

    def _test_done(self, ok, message: str = "") -> None:
        self.test_btn.setEnabled(True)
        if message:
            self.test_log.appendPlainText(message)
        self.test_result.setText("✓ All checks passed" if ok else "✕ Some checks failed")
        self.test_result.setStyleSheet(f"color: {S.SUCCESS if ok else S.DANGER};")
