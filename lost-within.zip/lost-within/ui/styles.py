"""Visual identity: a dark, torch-lit cave.

Deep slate-black stone, a single warm lantern-amber accent for the path and
primary actions, cool mineral greys for everything that is merely structure.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtGui import QColor, QFont, QFontDatabase

ICONS = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent)) / "assets" / "icons"

# ---------------------------------------------------------------- palette
BG = "#07090b"          # the deep
BG_RAISED = "#0d1114"   # rock shelf
SURFACE = "#11161a"     # cards
SURFACE_HI = "#172026"  # hovered / inputs
BORDER = "#222c33"
BORDER_HI = "#34424b"
TEXT = "#dfe4e6"
TEXT_DIM = "#93a1a9"
TEXT_FAINT = "#5c6a72"
ACCENT = "#e3a857"      # lantern
ACCENT_HI = "#f2c27d"
ACCENT_DEEP = "#7a5426"
SUCCESS = "#79c7a1"
DANGER = "#e0736b"
WARN = "#d9b45f"


def qc(hex_color: str, alpha: int = 255) -> QColor:
    c = QColor(hex_color)
    c.setAlpha(alpha)
    return c


# Families tried in order: Bahnschrift ships with Windows 10+ and has the
# engraved, wayfinding-sign feel; Segoe UI is the safe Windows fallback.
DISPLAY_FAMILIES = ["Bahnschrift", "Segoe UI", "Inter", "DejaVu Sans", "Sans Serif"]
TEXT_FAMILIES = ["Segoe UI", "Inter", "DejaVu Sans", "Sans Serif"]
MONO_FAMILIES = ["Cascadia Mono", "Consolas", "JetBrains Mono", "DejaVu Sans Mono", "Monospace"]


def _pick(families: list[str]) -> str:
    available = set(QFontDatabase.families())
    for f in families:
        if f in available:
            return f
    return families[-1]


def display_font(px: int, weight: QFont.Weight = QFont.Weight.Light, spacing: float = 0) -> QFont:
    f = QFont()
    f.setFamilies(DISPLAY_FAMILIES)
    f.setPixelSize(px)
    f.setWeight(weight)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return f


def mono_font(px: int = 12) -> QFont:
    f = QFont()
    f.setFamilies(MONO_FAMILIES)
    f.setPixelSize(px)
    f.setStyleHint(QFont.StyleHint.Monospace)
    return f


def app_font() -> QFont:
    """Base font. Set on the application rather than in the stylesheet, so that
    widgets can still override size/weight with setFont()."""
    f = QFont()
    f.setFamilies(TEXT_FAMILIES)
    f.setPixelSize(13)
    return f


def stylesheet() -> str:
    up = (ICONS / "chevron_up.svg").as_posix()
    down = (ICONS / "chevron_down.svg").as_posix()
    disp = ", ".join(f'"{f}"' for f in DISPLAY_FAMILIES)
    mono = ", ".join(f'"{f}"' for f in MONO_FAMILIES)
    return f"""
QWidget {{ color: {TEXT}; }}
QMainWindow, #Root {{ background: {BG}; }}
QWidget#Page, QWidget#Transparent, QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; }}
QToolTip {{ background: {SURFACE_HI}; color: {TEXT}; border: 1px solid {BORDER_HI}; padding: 6px; }}

/* ---------- top bar ---------- */
#TopBar {{ background: transparent; border-bottom: 1px solid {BORDER}; }}
#Wordmark {{ font-family: {disp}; font-size: 13px; letter-spacing: 5px; color: {TEXT}; }}
QPushButton#NavButton {{
    background: transparent; border: none; border-bottom: 2px solid transparent;
    color: {TEXT_DIM}; padding: 14px 12px 12px 12px; font-size: 12px; letter-spacing: 2px;
}}
QPushButton#NavButton:hover {{ color: {TEXT}; }}
QPushButton#NavButton:checked {{ color: {ACCENT}; border-bottom: 2px solid {ACCENT}; }}
QPushButton#NavButton:disabled {{ color: {TEXT_FAINT}; }}
#Footer {{ border-top: 1px solid {BORDER}; }}
#FooterText {{ color: {TEXT_FAINT}; font-size: 11px; letter-spacing: 1px; }}

/* ---------- typography ---------- */
#PageTitle {{ font-family: {disp}; font-size: 26px; font-weight: 300; letter-spacing: 6px; color: {TEXT}; }}
#PageSubtitle {{ color: {TEXT_DIM}; font-size: 13px; }}
#SectionLabel {{ color: {TEXT_FAINT}; font-size: 11px; letter-spacing: 3px; font-weight: 600; }}
#FieldLabel {{ color: {TEXT_DIM}; font-size: 12px; }}
#Hint {{ color: {TEXT_FAINT}; font-size: 12px; }}
#Value {{ color: {TEXT}; }}
#Mono {{ font-family: {mono}; font-size: 12px; color: {TEXT_DIM}; }}
#ErrorText {{ color: {DANGER}; font-size: 12px; }}
#WarnText {{ color: {WARN}; font-size: 12px; }}
#OkText {{ color: {SUCCESS}; font-size: 12px; }}

/* ---------- cards ---------- */
#Card {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 10px; }}
#Callout {{ background: rgba(227,168,87,0.06); border: 1px solid rgba(227,168,87,0.28); border-radius: 8px; }}
#CalloutText {{ color: {ACCENT_HI}; font-size: 12px; }}
#DangerCallout {{ background: rgba(224,115,107,0.07); border: 1px solid rgba(224,115,107,0.35); border-radius: 8px; }}

/* ---------- buttons ---------- */
QPushButton {{
    background: {SURFACE_HI}; border: 1px solid {BORDER_HI}; border-radius: 6px;
    padding: 8px 16px; color: {TEXT};
}}
QPushButton:hover {{ border-color: {TEXT_FAINT}; background: #1b262d; }}
QPushButton:pressed {{ background: {SURFACE}; }}
QPushButton:disabled {{ color: {TEXT_FAINT}; border-color: {BORDER}; background: {SURFACE}; }}
QPushButton#Primary {{
    background: {ACCENT}; color: #1a1108; border: 1px solid {ACCENT_HI};
    font-family: {disp}; font-weight: 600; letter-spacing: 3px; padding: 12px 28px; font-size: 13px;
}}
QPushButton#Primary:hover {{ background: {ACCENT_HI}; }}
QPushButton#Primary:pressed {{ background: #c98f43; }}
QPushButton#Primary:disabled {{ background: {ACCENT_DEEP}; color: #3a2a17; border-color: {ACCENT_DEEP}; }}
QPushButton#Secondary {{
    background: transparent; border: 1px solid {BORDER_HI}; color: {TEXT};
    font-family: {disp}; letter-spacing: 3px; padding: 12px 28px; font-size: 13px;
}}
QPushButton#Secondary:hover {{ border-color: {ACCENT}; color: {ACCENT_HI}; }}
QPushButton#Ghost {{ background: transparent; border: none; color: {ACCENT}; padding: 4px 6px; }}
QPushButton#Ghost:hover {{ color: {ACCENT_HI}; text-decoration: underline; }}
QPushButton#Danger {{ background: transparent; border: 1px solid rgba(224,115,107,0.5); color: {DANGER}; }}
QPushButton#Danger:hover {{ background: rgba(224,115,107,0.10); }}

/* ---------- inputs ---------- */
QLineEdit, QSpinBox, QComboBox, QPlainTextEdit {{
    background: {BG_RAISED}; border: 1px solid {BORDER_HI}; border-radius: 6px;
    padding: 7px 9px; selection-background-color: {ACCENT_DEEP}; color: {TEXT};
}}
QLineEdit:focus, QSpinBox:focus, QComboBox:focus, QPlainTextEdit:focus {{ border-color: {ACCENT}; }}
QLineEdit:disabled, QSpinBox:disabled {{ color: {TEXT_FAINT}; }}
QLineEdit[readOnly="true"] {{ color: {TEXT_DIM}; background: {SURFACE}; }}
QPlainTextEdit {{ font-family: {mono}; font-size: 12px; }}
QSpinBox::up-button, QSpinBox::down-button {{ width: 18px; border: none; background: transparent; }}
QSpinBox {{ padding-right: 22px; }}
QSpinBox::up-button {{ subcontrol-origin: border; subcontrol-position: top right; }}
QSpinBox::down-button {{ subcontrol-origin: border; subcontrol-position: bottom right; }}
QSpinBox::up-arrow {{ image: url("{up}"); width: 10px; height: 6px; }}
QSpinBox::down-arrow {{ image: url("{down}"); width: 10px; height: 6px; }}
QSpinBox::up-button:hover, QSpinBox::down-button:hover {{ background: {SURFACE_HI}; }}
QComboBox::drop-down {{ border: none; width: 26px; }}
QComboBox::down-arrow {{ image: url("{down}"); width: 10px; height: 6px; }}
QComboBox QAbstractItemView {{ background: {SURFACE_HI}; border: 1px solid {BORDER_HI};
    selection-background-color: {ACCENT_DEEP}; outline: none; }}
QCheckBox, QRadioButton {{ spacing: 9px; color: {TEXT}; }}
QCheckBox::indicator, QRadioButton::indicator {{ width: 15px; height: 15px; border: 1px solid {BORDER_HI};
    background: {BG_RAISED}; }}
QCheckBox::indicator {{ border-radius: 3px; }}
QRadioButton::indicator {{ border-radius: 8px; }}
QCheckBox::indicator:checked, QRadioButton::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT_HI}; }}
QCheckBox::indicator:hover, QRadioButton::indicator:hover {{ border-color: {ACCENT}; }}

QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {BORDER_HI}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {TEXT_FAINT}; }}
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{ height: 0; background: none; }}

QMessageBox, QDialog {{ background: {SURFACE}; }}
QMessageBox QLabel {{ color: {TEXT}; }}
"""
