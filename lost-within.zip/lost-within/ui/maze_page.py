"""Maze Configuration: shape the labyrinth, validated live against path limits."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QSpinBox, QVBoxLayout

from core.maze import LIMITS, MazeConfig, check_config, plan_maze
from models.settings import AppSettings
from ui import styles as S
from ui.page import Page
from ui.widgets import MazeView, button, callout, card, label

FIELDS = [
    ("depth", "Maze depth", "Folders between the entrance and the payload."),
    ("name_length", "Folder-name length", "Random characters per name (A–Z, a–z, 0–9)."),
    ("branching", "Branching factor", "Passages at every junction of the true path."),
    ("decoy_dirs", "Decoy passages", "Extra dead-end tunnels branching off at random."),
    ("decoy_files", "Decoy files", "Small files of random bytes placed at dead ends."),
]


class MazePage(Page):
    start_requested = Signal()
    back_requested = Signal()

    def __init__(self, settings: AppSettings):
        super().__init__("Maze Configuration", "Shape the labyrinth. A fresh, unpredictable maze is generated when "
                                               "you enter; the preview shows its form, not its real names.",
                         max_width=1080)
        self.settings = settings
        self.base_dir: Optional[Path] = None
        self.long_paths = False
        self.check = None

        row = QHBoxLayout()
        row.setSpacing(16)

        # ---------------------------------------------------- controls
        c, lay = card()
        lay.addWidget(label("SHAPE", "SectionLabel"))
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(4)
        self.spins: dict[str, QSpinBox] = {}
        for i, (key, title, hint) in enumerate(FIELDS):
            spin = QSpinBox()
            lo, hi = LIMITS[key]
            spin.setRange(lo, hi)
            spin.setFixedWidth(96)
            spin.valueChanged.connect(self._schedule)
            self.spins[key] = spin
            grid.addWidget(label(title, "Value"), i * 2, 0)
            grid.addWidget(spin, i * 2, 1, 2, 1, Qt.AlignmentFlag.AlignVCenter)
            h = label(hint, "Hint", wrap=True)
            grid.addWidget(h, i * 2 + 1, 0)
            grid.setRowMinimumHeight(i * 2 + 1, 26)
        lay.addLayout(grid)
        lay.addSpacing(6)
        preset_row = QHBoxLayout()
        for name, cfg in (("Shallow", MazeConfig(4, 6, 2, 6, 3)), ("Balanced", MazeConfig()),
                          ("Labyrinth", MazeConfig(14, 8, 4, 120, 60))):
            preset_row.addWidget(button(name, slot=lambda _=False, c=cfg: self.set_config(c)))
        preset_row.addStretch()
        lay.addLayout(preset_row)

        lay.addSpacing(8)
        lay.addWidget(label("ASSESSMENT", "SectionLabel"))
        stats = QGridLayout()
        stats.setHorizontalSpacing(14)
        stats.setVerticalSpacing(6)
        self.stat_dirs = label("", "Value")
        self.stat_path = label("", "Value")
        self.stat_entropy = label("", "Value")
        for i, (t, w) in enumerate((("Folders (approx.)", self.stat_dirs), ("Longest path", self.stat_path),
                                    ("Entropy per name", self.stat_entropy))):
            stats.addWidget(label(t, "FieldLabel"), i, 0)
            stats.addWidget(w, i, 1)
        stats.setColumnStretch(1, 1)
        lay.addLayout(stats)
        self.issues = label("", "ErrorText", wrap=True)
        self.issues.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(self.issues)
        lay.addStretch()
        c.setFixedWidth(400)
        row.addWidget(c)

        # ---------------------------------------------------- preview
        c, lay = card(16)
        head = QHBoxLayout()
        head.addWidget(label("PREVIEW", "SectionLabel"))
        head.addStretch()
        self.preview_note = label("", "Hint")
        head.addWidget(self.preview_note)
        head.addWidget(button("Regenerate", "Ghost", self._refresh))
        lay.addLayout(head)
        self.view = MazeView("preview")
        self.view.setMinimumHeight(420)
        lay.addWidget(self.view, 1)
        legend = QHBoxLayout()
        for color, text in ((S.ACCENT, "true path → payload"), (S.TEXT_FAINT, "dead ends & decoys")):
            dot = label("●")
            dot.setStyleSheet(f"color: {color}; font-size: 11px;")
            legend.addWidget(dot)
            legend.addWidget(label(text, "Hint"))
            legend.addSpacing(10)
        legend.addStretch()
        lay.addLayout(legend)
        row.addWidget(c, 1)
        self.body.addLayout(row)

        self.body.addWidget(callout(
            "<b>The maze is not the lock.</b> It keeps the name and location out of casual sight, but anyone "
            "who can browse the disk can find the payload (it is usually the largest file). AES-256-GCM "
            "encryption is what keeps the contents secret."))

        nav = QHBoxLayout()
        nav.addWidget(button("‹  Back", slot=self.back_requested.emit))
        nav.addStretch()
        self.start_btn = button("ENTER THE MAZE", "Primary", self.start_requested.emit)
        nav.addWidget(self.start_btn)
        self.body.addLayout(nav)
        self.body.addStretch()

        self._timer = QTimer(self, singleShot=True, interval=160)
        self._timer.timeout.connect(self._refresh)
        self.set_config(settings.maze_config)

    def set_config(self, cfg: MazeConfig) -> None:
        for key, spin in self.spins.items():
            spin.blockSignals(True)
            spin.setValue(getattr(cfg, key))
            spin.blockSignals(False)
        self._refresh()

    def config(self) -> MazeConfig:
        return MazeConfig(**{k: s.value() for k, s in self.spins.items()})

    def set_context(self, base_dir: Optional[Path], long_paths: bool) -> None:
        self.base_dir, self.long_paths = base_dir, long_paths
        self._refresh()

    def _schedule(self) -> None:
        self._timer.start()

    def _refresh(self) -> None:
        cfg = self.config()
        chk = check_config(cfg, self.base_dir, long_paths=self.long_paths)
        self.check = chk
        self.stat_dirs.setText(f"{chk.estimated_dirs:,}")
        over = chk.longest_path > chk.path_limit
        self.stat_path.setText(f"{chk.longest_path} / {chk.path_limit} characters")
        self.stat_path.setStyleSheet(f"color: {S.DANGER if over else S.TEXT};")
        self.stat_entropy.setText(f"{chk.name_entropy:.0f} bits")
        msgs = [f"<span style='color:{S.DANGER}'>✕ {e}</span>" for e in chk.errors]
        msgs += [f"<span style='color:{S.WARN}'>! {w}</span>" for w in chk.warnings]
        self.issues.setText("<br>".join(msgs))
        self.start_btn.setEnabled(chk.ok)
        if chk.ok:
            # Preview: cap decoys so drawing stays fast; real maze uses the full config.
            preview_cfg = replace(cfg, decoy_dirs=min(cfg.decoy_dirs, 150), decoy_files=min(cfg.decoy_files, 80))
            plan = plan_maze(preview_cfg)
            self.view.set_plan(plan)
            self.preview_note.setText("simplified" if self.view.simplified or preview_cfg != cfg else "")
        else:
            self.view.set_plan(None)
            self.preview_note.setText("")
