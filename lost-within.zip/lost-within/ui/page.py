"""Base layout for content pages: centered column, scrolling, engraved header."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QPainter, QLinearGradient
from PySide6.QtWidgets import QFrame, QHBoxLayout, QScrollArea, QVBoxLayout, QWidget

from ui import styles as S
from ui.widgets import label


class Rule(QWidget):
    """A short lantern-lit horizontal rule, fading out to the right."""

    def __init__(self, width: int = 120):
        super().__init__()
        self.setFixedSize(width, 2)

    def paintEvent(self, e):
        p = QPainter(self)
        g = QLinearGradient(0, 0, self.width(), 0)
        g.setColorAt(0, S.qc(S.ACCENT, 230))
        g.setColorAt(1, S.qc(S.ACCENT, 0))
        p.fillRect(self.rect(), g)


class Page(QWidget):
    def __init__(self, title: str = "", subtitle: str = "", max_width: int = 940):
        super().__init__()
        self.setObjectName("Page")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        holder = QWidget()
        holder.setObjectName("Transparent")
        row = QHBoxLayout(holder)
        row.setContentsMargins(32, 28, 32, 32)
        column = QWidget()
        column.setObjectName("Transparent")
        column.setMaximumWidth(max_width)
        row.addStretch(1)
        row.addWidget(column, 100)
        row.addStretch(1)
        scroll.setWidget(holder)
        self.body = QVBoxLayout(column)
        self.body.setContentsMargins(0, 0, 0, 0)
        self.body.setSpacing(16)
        if title:
            self.title_label = label(title.upper(), "PageTitle")
            self.body.addWidget(self.title_label)
            self.body.addWidget(Rule())
            if subtitle:
                self.subtitle_label = label(subtitle, "PageSubtitle", wrap=True)
                self.body.addWidget(self.subtitle_label)
            self.body.addSpacing(6)
