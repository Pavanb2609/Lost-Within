"""Home: the entrance. Drop something to bury it, or a descriptor to recover."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QFileDialog, QHBoxLayout, QVBoxLayout, QWidget

from models.metadata import DESCRIPTOR_EXT
from ui import styles as S
from ui.page import Rule
from ui.widgets import DropZone, button, describe_path, label


class HomePage(QWidget):
    bury_requested = Signal(object)      # Path | None
    recover_requested = Signal(object)   # Path | None

    def __init__(self):
        super().__init__()
        self.setObjectName("Page")
        self.source: Optional[Path] = None

        lay = QVBoxLayout(self)
        lay.setContentsMargins(32, 24, 32, 24)
        lay.addStretch(3)

        title = label("LOST WITHIN", align=Qt.AlignmentFlag.AlignCenter)
        title.setFont(S.display_font(52, S.QFont.Weight.ExtraLight, spacing=16))
        title.setStyleSheet(f"color: {S.TEXT};")
        lay.addWidget(title)
        rule_row = QHBoxLayout()
        rule_row.addStretch()
        rule_row.addWidget(Rule(260))
        rule_row.addStretch()
        lay.addSpacing(4)
        lay.addLayout(rule_row)
        lay.addSpacing(14)
        for line in ("Enter. Disappear.", "Find your way back."):
            t = label(line, align=Qt.AlignmentFlag.AlignCenter)
            t.setFont(S.display_font(17, S.QFont.Weight.Light, spacing=2))
            t.setStyleSheet(f"color: {S.TEXT_DIM};")
            lay.addWidget(t)
        lay.addSpacing(6)
        sub = label("SECURE FILE MAZE", "SectionLabel", align=Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(sub)
        lay.addStretch(2)

        zone_row = QHBoxLayout()
        zone_row.addStretch()
        self.zone = DropZone("DROP FILE HERE")
        self.zone.setMaximumWidth(560)
        self.zone.setMinimumWidth(420)
        zone_row.addWidget(self.zone, 1)
        zone_row.addStretch()
        lay.addLayout(zone_row)
        lay.addSpacing(26)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(16)
        btn_row.addStretch()
        self.bury_btn = button("BURY FILE", "Primary", lambda: self.bury_requested.emit(self.source))
        self.recover_btn = button("RECOVER", "Secondary", lambda: self.recover_requested.emit(None))
        for b in (self.bury_btn, self.recover_btn):
            b.setMinimumWidth(170)
            btn_row.addWidget(b)
        btn_row.addStretch()
        lay.addLayout(btn_row)
        lay.addSpacing(22)

        lay.addWidget(label("STATUS", "SectionLabel", align=Qt.AlignmentFlag.AlignCenter))
        self.status = label("Ready", "Hint", align=Qt.AlignmentFlag.AlignCenter, wrap=True)
        self.status.setStyleSheet(f"color: {S.TEXT_DIM}; font-size: 13px;")
        lay.addWidget(self.status)
        lay.addStretch(3)

        self.zone.dropped.connect(self.accept_path)
        self.zone.browse_file.connect(self._browse_file)
        self.zone.browse_folder.connect(self._browse_folder)
        self.zone.cleared.connect(self.clear_source)

    # -- selection
    def accept_path(self, path: Path) -> None:
        path = Path(path)
        if path.suffix.lower() == DESCRIPTOR_EXT and path.is_file():
            self.recover_requested.emit(path)
            return
        if not path.exists():
            self.set_status("That item no longer exists.")
            return
        self.source = path
        title, subtitle = describe_path(path)
        self.zone.set_selected(title, subtitle)
        self.set_status(f"Ready to bury “{path.name}”. Press BURY FILE to continue.")

    def clear_source(self) -> None:
        self.source = None
        self.zone.reset()
        self.set_status("Ready")

    def _browse_file(self) -> None:
        p, _ = QFileDialog.getOpenFileName(self, "Choose a file to bury", str(Path.home()))
        if p:
            self.accept_path(Path(p))

    def _browse_folder(self) -> None:
        p = QFileDialog.getExistingDirectory(self, "Choose a folder to bury", str(Path.home()))
        if p:
            self.accept_path(Path(p))

    def set_status(self, text: str) -> None:
        self.status.setText(text)
