"""Bury File: choose what to bury, where the maze goes, and the password."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QCheckBox, QFileDialog, QGridLayout, QHBoxLayout, QLineEdit, QVBoxLayout, QWidget)

from core.burial import default_descriptor_name
from models.metadata import DESCRIPTOR_EXT
from models.settings import AppSettings
from ui import styles as S
from ui.page import Page
from ui.widgets import PathField, StrengthMeter, button, callout, card, describe_path, label
from utils.random_names import random_name
from utils.validation import password_problems, password_strength, sanitize_filename


class BuryPage(Page):
    next_requested = Signal()
    back_requested = Signal()

    def __init__(self, settings: AppSettings):
        super().__init__("Bury File", "Choose what disappears, where its maze is carved, and the password "
                                      "that brings it back.")
        self.settings = settings
        self.source: Optional[Path] = None

        # ---------------------------------------------------- what
        c, lay = card()
        lay.addWidget(label("WHAT TO BURY", "SectionLabel"))
        row = QHBoxLayout()
        self.src_title = label("Nothing selected", "Value")
        self.src_title.setFont(S.display_font(18, S.QFont.Weight.Normal, 1))
        self.src_sub = label("", "Hint", selectable=True)
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(self.src_title)
        col.addWidget(self.src_sub)
        row.addLayout(col, 1)
        row.addWidget(button("File…", slot=self._pick_file))
        row.addWidget(button("Folder…", slot=self._pick_folder))
        lay.addLayout(row)
        self.body.addWidget(c)

        # ---------------------------------------------------- where
        c, lay = card()
        lay.addWidget(label("WHERE", "SectionLabel"))
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)
        grid.setColumnStretch(1, 1)
        self.output = PathField("dir", "Choose the folder that will contain the maze")
        self.output.changed.connect(self._sync_desc_placeholder)
        grid.addWidget(label("Maze location", "FieldLabel"), 0, 0)
        grid.addWidget(self.output, 0, 1)
        grid.addWidget(label("A new folder named LostWithin_xxxxxxxx is created here.", "Hint"), 1, 1)

        name_row = QHBoxLayout()
        self.desc_name = QLineEdit()
        name_row.addWidget(self.desc_name, 1)
        name_row.addWidget(button("Randomize", slot=self._randomize_name))
        grid.addWidget(label("Descriptor name", "FieldLabel"), 2, 0)
        grid.addLayout(name_row, 2, 1)
        grid.addWidget(label("The descriptor's name is visible. Randomize it to keep the original filename private.",
                             "Hint", wrap=True), 3, 1)
        self.desc_dir = PathField("dir", "Choose where to save the recovery descriptor",
                                  placeholder="Same as maze location")
        grid.addWidget(label("Descriptor folder", "FieldLabel"), 4, 0)
        grid.addWidget(self.desc_dir, 4, 1)
        grid.addWidget(label("Tip: keep the descriptor somewhere other than the maze (e.g. a second drive).",
                             "Hint", wrap=True), 5, 1)
        lay.addLayout(grid)
        self.body.addWidget(c)

        # ---------------------------------------------------- password
        c, lay = card()
        lay.addWidget(label("PASSWORD", "SectionLabel"))
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)
        grid.setColumnStretch(1, 1)
        self.pw = QLineEdit()
        self.pw2 = QLineEdit()
        for e, ph in ((self.pw, "A long passphrase you will remember"), (self.pw2, "Type it again")):
            e.setEchoMode(QLineEdit.EchoMode.Password)
            e.setPlaceholderText(ph)
            e.textChanged.connect(self._update_strength)
        grid.addWidget(label("Password", "FieldLabel"), 0, 0)
        grid.addWidget(self.pw, 0, 1)
        grid.addWidget(label("Confirm", "FieldLabel"), 1, 0)
        grid.addWidget(self.pw2, 1, 1)
        meter_row = QHBoxLayout()
        self.meter = StrengthMeter()
        self.meter.setFixedWidth(180)
        self.strength = label("", "Hint")
        self.show_pw = QCheckBox("Show")
        self.show_pw.toggled.connect(self._toggle_show)
        meter_row.addWidget(self.meter)
        meter_row.addSpacing(10)
        meter_row.addWidget(self.strength)
        meter_row.addStretch()
        meter_row.addWidget(self.show_pw)
        grid.addLayout(meter_row, 2, 1)
        lay.addLayout(grid)
        lay.addWidget(label("Four or more unrelated words make a strong, memorable passphrase. There is no "
                            "password reset: if it is forgotten and there is no recovery key, the data is gone.",
                            "Hint", wrap=True))
        self.recovery_key = QCheckBox("Also create a Recovery Key (a second, independent way to unlock — "
                                      "store it separately)")
        lay.addWidget(self.recovery_key)
        self.body.addWidget(c)

        self.body.addWidget(callout(
            "<b>The maze hides; encryption protects.</b> Anyone with disk access can list the maze and find "
            "the encrypted payload. Confidentiality comes only from AES-256-GCM and the strength of your password."))
        self.errors = label("", "ErrorText", wrap=True)
        self.body.addWidget(self.errors)

        nav = QHBoxLayout()
        nav.addWidget(button("‹  Back", slot=self.back_requested.emit))
        nav.addStretch()
        self.next_btn = button("NEXT: MAZE  ›", "Primary", self._next)
        nav.addWidget(self.next_btn)
        self.body.addLayout(nav)
        self.body.addStretch()
        self.apply_settings()

    # ---------------------------------------------------- state
    def apply_settings(self) -> None:
        self.recovery_key.setChecked(self.settings.create_recovery_key)
        if self.settings.last_output_dir and not self.output.text():
            self.output.setText(self.settings.last_output_dir)
        self._update_strength()

    def set_source(self, path: Optional[Path]) -> None:
        self.source = Path(path) if path else None
        if self.source is None:
            self.src_title.setText("Nothing selected")
            self.src_sub.setText("Choose a file or folder, or drop one onto the window.")
            return
        title, sub = describe_path(self.source)
        self.src_title.setText(title)
        self.src_sub.setText(f"{sub}  ·  {self.source.parent}")
        self.desc_name.setText(default_descriptor_name(self.source))
        if not self.output.text():
            self.output.setText(str(self.source.parent))

    def _pick_file(self) -> None:
        p, _ = QFileDialog.getOpenFileName(self, "Choose a file to bury", str(self.source or Path.home()))
        if p:
            self.set_source(Path(p))

    def _pick_folder(self) -> None:
        p = QFileDialog.getExistingDirectory(self, "Choose a folder to bury", str(self.source or Path.home()))
        if p:
            self.set_source(Path(p))

    def _randomize_name(self) -> None:
        self.desc_name.setText(random_name(12) + DESCRIPTOR_EXT)

    def _sync_desc_placeholder(self, text: str) -> None:
        self.desc_dir.edit.setPlaceholderText(f"Same as maze location" if not text else f"Same as {text}")

    def _toggle_show(self, on: bool) -> None:
        mode = QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password
        self.pw.setEchoMode(mode)
        self.pw2.setEchoMode(mode)

    def _update_strength(self) -> None:
        pw = self.pw.text()
        if not pw:
            self.meter.set_score(-1)
            self.strength.setText(f"At least {self.settings.min_password_length} characters")
            return
        score, text = password_strength(pw)
        self.meter.set_score(score)
        self.strength.setText(text)

    # ---------------------------------------------------- validation
    def problems(self) -> list[str]:
        out = []
        if self.source is None or not self.source.exists():
            out.append("Choose a file or folder to bury.")
        out_dir = self.output.text()
        if not out_dir or not Path(out_dir).is_dir():
            out.append("Choose an existing folder for the maze.")
        if self.desc_dir.text() and not Path(self.desc_dir.text()).is_dir():
            out.append("The descriptor folder does not exist.")
        name = self.desc_name.text().strip()
        if not name or sanitize_filename(name) != name:
            out.append("The descriptor name is empty or contains characters that are not allowed.")
        out += password_problems(self.pw.text(), self.pw2.text(), self.settings.min_password_length)
        return out

    def _next(self) -> None:
        problems = self.problems()
        self.errors.setText("\n".join(f"•  {p}" for p in problems))
        if not problems:
            self.next_requested.emit()

    def descriptor_path(self) -> Path:
        name = self.desc_name.text().strip()
        if not name.lower().endswith(DESCRIPTOR_EXT):
            name += DESCRIPTOR_EXT
        folder = Path(self.desc_dir.text() or self.output.text())
        return folder / name

    def password(self) -> str:
        return self.pw.text()

    def clear_secrets(self) -> None:
        # Python strings cannot be wiped from memory; this at least drops the
        # widget's copy and keeps the password off screen.
        for e in (self.pw, self.pw2):
            e.clear()
        self.show_pw.setChecked(False)
        self._update_strength()
