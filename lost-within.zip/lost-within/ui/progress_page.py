"""Encryption Progress / Recovery Progress, and the result screens."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import QFileDialog, QGridLayout, QHBoxLayout, QVBoxLayout, QWidget

from core.burial import BuryResult
from core.maze import MazeConfig, plan_maze
from core.recovery import RecoverResult
from core.streaming import ProgressInfo
from ui import styles as S
from ui.page import Page
from ui.widgets import LanternProgress, MazeView, button, callout, card, label
from utils.filesystem import atomic_write_bytes, human_duration, human_size

BURY_STAGES = ["Preparing", "Deriving key", "Building maze", "Encrypting", "Finalizing"]
RECOVER_STAGES = ["Reading descriptor", "Deriving key", "Locating payload", "Decrypting", "Verifying", "Restoring"]
STAGE_ALIASES = {"Restoring folder": "Restoring", "Cleaning up": None}
STAGE_VERBS = {"Encrypting": "Encrypting…", "Decrypting": "Decrypting…", "Deriving key": "Deriving key…",
               "Building maze": "Carving the maze…", "Locating payload": "Following the path…",
               "Verifying": "Verifying integrity…", "Finalizing": "Sealing…", "Restoring": "Restoring…",
               "Restoring folder": "Restoring folder…", "Cleaning up": "Cleaning up…",
               "Preparing": "Preparing…", "Reading descriptor": "Reading descriptor…"}


def open_in_explorer(path: Path) -> None:
    folder = path if path.is_dir() else path.parent
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))


class StageList(QWidget):
    def __init__(self):
        super().__init__()
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(9)
        self.items: dict[str, tuple] = {}
        self.order: list[str] = []

    def set_stages(self, stages: list[str]) -> None:
        while self.lay.count():
            w = self.lay.takeAt(0).widget()
            if w:
                w.deleteLater()
        self.items.clear()
        self.order = stages
        for s in stages:
            lab = label(f"○   {s}", "Hint")
            self.lay.addWidget(lab)
            self.items[s] = lab
        self.lay.addStretch()

    def set_current(self, stage: str) -> None:
        if stage not in self.items:
            return
        idx = self.order.index(stage)
        for i, s in enumerate(self.order):
            lab = self.items[s]
            if i < idx:
                lab.setText(f"✓   {s}")
                lab.setStyleSheet(f"color: {S.SUCCESS};")
            elif i == idx:
                lab.setText(f"◉   {s}")
                lab.setStyleSheet(f"color: {S.ACCENT}; font-weight: 600;")
            else:
                lab.setText(f"○   {s}")
                lab.setStyleSheet(f"color: {S.TEXT_FAINT};")

    def complete(self) -> None:
        for s in self.order:
            self.items[s].setText(f"✓   {s}")
            self.items[s].setStyleSheet(f"color: {S.SUCCESS};")


class ProgressPage(Page):
    cancel_requested = Signal()
    home_requested = Signal()
    back_requested = Signal()
    again_requested = Signal()

    def __init__(self, mode: str):
        self.mode = mode
        super().__init__("Encryption Progress" if mode == "bury" else "Recovery Progress")
        # running and result views are siblings toggled with show/hide (a
        # QStackedWidget would size both to the taller one)
        self.stack = _Switch()
        self._build_running()
        self.body.addWidget(self.running)
        self.result = QWidget()
        self.result_lay = QVBoxLayout(self.result)
        self.result_lay.setContentsMargins(0, 0, 0, 0)
        self.result_lay.setSpacing(16)
        self.body.addWidget(self.result)
        self.body.addStretch()
        self.stack.widgets = [self.running, self.result]
        self.result.hide()
        self.stages = BURY_STAGES if mode == "bury" else RECOVER_STAGES
        self._recovery_key: Optional[str] = None

    # ------------------------------------------------------------------ running view
    def _build_running(self) -> None:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        c, cl = card(16)
        self.view = MazeView("progress")
        self.view.setFixedHeight(230)
        cl.addWidget(self.view)
        lay.addWidget(c)

        row = QHBoxLayout()
        row.setSpacing(16)
        c, cl = card(24)
        self.stage_label = label("Preparing…")
        self.stage_label.setFont(S.display_font(26, S.QFont.Weight.Light, 2))
        self.detail_label = label("", "Hint", wrap=True)
        top = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(4)
        col.addWidget(self.stage_label)
        col.addWidget(self.detail_label)
        col.addStretch()
        top.addLayout(col, 1)
        self.pct = label("")
        self.pct.setFont(S.display_font(34, S.QFont.Weight.ExtraLight))
        self.pct.setStyleSheet(f"color: {S.ACCENT_HI};")
        top.addWidget(self.pct, 0, Qt.AlignmentFlag.AlignBottom)
        cl.addLayout(top)
        self.bar = LanternProgress()
        cl.addWidget(self.bar)
        grid = QGridLayout()
        grid.setHorizontalSpacing(28)
        self.bytes_label = label("—", "Value")
        self.speed_label = label("—", "Value")
        self.eta_label = label("—", "Value")
        self.elapsed_label = label("—", "Value")
        for i, (t, wdg) in enumerate((("PROCESSED", self.bytes_label), ("SPEED", self.speed_label),
                                      ("REMAINING", self.eta_label), ("ELAPSED", self.elapsed_label))):
            grid.addWidget(label(t, "SectionLabel"), 0, i)
            grid.addWidget(wdg, 1, i)
        grid.setVerticalSpacing(6)
        cl.addLayout(grid)
        cl.addStretch(1)
        cancel_row = QHBoxLayout()
        self.cancel_note = label("Cancelling removes everything created so far.", "Hint")
        cancel_row.addWidget(self.cancel_note)
        cancel_row.addStretch()
        self.cancel_btn = button("Cancel", "Danger", self._cancel)
        cancel_row.addWidget(self.cancel_btn)
        cl.addLayout(cancel_row)
        row.addWidget(c, 1)

        c, cl = card(24)
        cl.addWidget(label("PASSAGE", "SectionLabel"))
        self.stage_list = StageList()
        cl.addWidget(self.stage_list)
        c.setFixedWidth(250)
        row.addWidget(c)
        lay.addLayout(row)
        self.running = w

    def start(self, preview: Optional[MazeConfig] = None) -> None:
        self.stack.setCurrentWidget(self.running)
        self.stage_list.set_stages(self.stages)
        self.stage_label.setText("Preparing…")
        self.detail_label.setText("")
        self.pct.setText("")
        for l in (self.bytes_label, self.speed_label, self.eta_label, self.elapsed_label):
            l.setText("—")
        self.bar.set_value(0)
        self.bar.set_indeterminate(True)
        self.cancel_btn.setEnabled(True)
        self.cancel_btn.setText("Cancel")
        cfg = preview or MazeConfig()
        from dataclasses import replace
        self.view.set_plan(plan_maze(replace(cfg, decoy_dirs=min(cfg.decoy_dirs, 60),
                                             decoy_files=min(cfg.decoy_files, 30))), animate=False)
        self.view.set_lantern(0)

    def _cancel(self) -> None:
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setText("Cancelling…")
        self.cancel_requested.emit()

    def update_progress(self, info: ProgressInfo) -> None:
        self.stage_label.setText(STAGE_VERBS.get(info.stage, info.stage))
        self.detail_label.setText(info.detail)
        stage = STAGE_ALIASES.get(info.stage, info.stage)
        if stage:
            self.stage_list.set_current(stage)
        byte_stage = info.stage in ("Encrypting", "Decrypting")
        if info.total:
            self.bar.set_value(info.fraction)
            self.pct.setText(f"{info.fraction * 100:.0f}%")
        else:
            self.bar.set_indeterminate(True)
            self.pct.setText("")
        if byte_stage:
            self.bytes_label.setText(f"{human_size(info.processed)} / {human_size(info.total)}")
            self.speed_label.setText(f"{human_size(info.speed)}/s" if info.speed else "—")
            self.eta_label.setText(human_duration(info.eta))
            self.elapsed_label.setText(human_duration(info.elapsed))
        elif info.total and info.stage in ("Building maze", "Restoring folder"):
            self.bytes_label.setText(f"{info.processed:,} / {info.total:,} items")
        if stage in self.stages:
            idx = self.stages.index(stage)
            self.view.set_lantern((idx + (info.fraction if info.total else 0.0)) / len(self.stages))

    # ------------------------------------------------------------------ result views
    def _clear_result(self) -> None:
        while self.result_lay.count():
            item = self.result_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                _delete_layout(item.layout())

    def _headline(self, mark: str, title: str, sub: str, color: str) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 8, 0, 4)
        lay.setSpacing(6)
        w.setSizePolicy(w.sizePolicy().horizontalPolicy(), w.sizePolicy().Policy.Maximum)
        t = label(f"{mark}  {title}")
        t.setFont(S.display_font(30, S.QFont.Weight.Light, 1))
        t.setStyleSheet(f"color: {color};")
        lay.addWidget(t)
        if sub:
            s = label(sub, "PageSubtitle", wrap=True)
            s.setStyleSheet(f"color: {S.TEXT_DIM}; font-size: 15px;")
            lay.addWidget(s)
        return w

    def _details(self, rows: list[tuple[str, str]]) -> QWidget:
        c, lay = card(22, 8)
        grid = QGridLayout()
        grid.setHorizontalSpacing(22)
        grid.setVerticalSpacing(10)
        grid.setColumnStretch(1, 1)
        for i, (k, v) in enumerate(rows):
            grid.addWidget(label(k.upper(), "SectionLabel"), i, 0, Qt.AlignmentFlag.AlignTop)
            val = label(v, "Mono" if k in ("SHA-256", "Payload SHA-256") else "Value", wrap=True, selectable=True)
            grid.addWidget(val, i, 1)
        lay.addLayout(grid)
        return c

    def _nav(self, *buttons) -> QHBoxLayout:
        row = QHBoxLayout()
        for b in buttons[:-1]:
            row.addWidget(b)
        row.addStretch()
        row.addWidget(buttons[-1])
        return row

    def show_bury_result(self, res: BuryResult) -> None:
        self._clear_result()
        self.stage_list.complete()
        L = self.result_lay
        kind = "Folder" if res.kind == "dir" else "File"
        L.addWidget(self._headline("✓", "Buried.", f"“{res.original_name}” has disappeared into the maze.",
                                   S.SUCCESS))
        rows = [
            (f"Original {kind.lower()}", res.original_name + (f"  ({res.file_count:,} files)" if res.kind == "dir" else "")),
            ("Size", human_size(res.original_size)),
            ("Descriptor", str(res.descriptor_path)),
            ("Maze", f"{res.maze_root}\n{res.directories_created:,} folders · {res.decoy_files} decoy files"),
            ("Encryption", "AES-256-GCM · key from Argon2id"),
            ("Payload SHA-256", res.payload_sha256),
            ("Time", human_duration(res.elapsed)),
        ]
        if res.skipped:
            rows.append(("Skipped", f"{len(res.skipped)} symbolic link(s) or special file(s) were not included."))
        L.addWidget(self._details(rows))

        if res.recovery_key:
            c, lay = card(22, 10)
            lay.addWidget(label("RECOVERY KEY — SHOWN ONLY ONCE", "SectionLabel"))
            key = label(res.recovery_key, selectable=True)
            key.setFont(S.mono_font(15))
            key.setStyleSheet(f"color: {S.ACCENT_HI}; padding: 6px 0;")
            key.setWordWrap(True)
            lay.addWidget(key)
            lay.addWidget(label("It unlocks this burial without the password. Store it apart from the descriptor "
                                "(on paper, or in a password manager). Anyone holding both can recover the data.",
                                "Hint", wrap=True))
            row = QHBoxLayout()
            self._recovery_key = res.recovery_key
            row.addWidget(button("Copy", slot=self._copy_key))
            row.addWidget(button("Save as text file…", slot=lambda: self._save_key(res)))
            row.addStretch()
            lay.addLayout(row)
            L.addWidget(c)

        L.addWidget(callout(
            "<b>Keep the descriptor safe.</b> It holds the wrapped keys and the way through the maze. "
            "Without it, recovery may be impossible — back it up. It does not contain your password."))
        L.addWidget(label("Your original was not modified or deleted. Once you have tested recovery, delete it "
                          "yourself if you want it gone (on SSDs and cloud-synced folders, deleted data may "
                          "remain recoverable).", "Hint", wrap=True))
        L.addLayout(self._nav(button("Show descriptor", slot=lambda: open_in_explorer(res.descriptor_path)),
                              button("Bury another", slot=self.again_requested.emit),
                              button("DONE", "Primary", self._done)))
        L.addStretch()
        self.stack.setCurrentWidget(self.result)

    def show_recover_result(self, res: RecoverResult) -> None:
        self._clear_result()
        self.stage_list.complete()
        L = self.result_lay
        kind = "folder" if res.kind == "dir" else "file"
        if res.verify_only:
            L.addWidget(self._headline("✓", "You found your way back.",
                                       f"The buried {kind} is intact. Nothing was written (verify-only).",
                                       S.SUCCESS))
        else:
            L.addWidget(self._headline("✓", "You found your way back.",
                                       f"{kind.capitalize()} recovered successfully.", S.SUCCESS))
        rows = [(f"Original {kind}", res.original_name)]
        if res.output_path:
            rows.append(("Restored to", str(res.output_path)))
        rows += [("Integrity", "SHA-256 verified ✓  ·  every chunk authenticated (AES-256-GCM)"),
                 ("SHA-256", res.plaintext_sha256),
                 ("Size", human_size(res.original_size) + (f" · {res.file_count:,} files" if res.kind == "dir" else "")),
                 ("Time", human_duration(res.elapsed))]
        L.addWidget(self._details(rows))
        for note in res.notes:
            L.addWidget(label(f"Note: {note}", "WarnText", wrap=True))
        buttons = []
        if res.output_path:
            buttons.append(button("Open folder", slot=lambda: open_in_explorer(res.output_path)))
        buttons.append(button("Recover another", slot=self.again_requested.emit))
        buttons.append(button("DONE", "Primary", self._done))
        L.addLayout(self._nav(*buttons))
        L.addStretch()
        self.stack.setCurrentWidget(self.result)

    def show_error(self, title: str, message: str, cancelled: bool) -> None:
        self._clear_result()
        L = self.result_lay
        if cancelled:
            L.addWidget(self._headline("◌", "Cancelled.", message, S.TEXT_DIM))
        else:
            L.addWidget(self._headline("✕", title, "", S.DANGER))
            c, lay = card()
            lay.addWidget(label(message, "Value", wrap=True, selectable=True))
            if self.mode == "bury":
                lay.addWidget(label("Nothing was left behind: the incomplete maze and payload were removed.",
                                    "Hint", wrap=True))
            else:
                lay.addWidget(label("No partially recovered file was kept.", "Hint", wrap=True))
            L.addWidget(c)
        L.addLayout(self._nav(button("Home", slot=self._done),
                              button("‹  BACK", "Primary", self.back_requested.emit)))
        L.addStretch()
        self.stack.setCurrentWidget(self.result)

    # ------------------------------------------------------------------ actions
    def _done(self) -> None:
        self._recovery_key = None
        self.home_requested.emit()

    def _copy_key(self) -> None:
        if self._recovery_key:
            QGuiApplication.clipboard().setText(self._recovery_key)

    def _save_key(self, res: BuryResult) -> None:
        default = str(Path.home() / f"{res.descriptor_path.stem}-recovery-key.txt")
        p, _ = QFileDialog.getSaveFileName(self, "Save recovery key", default, "Text files (*.txt)")
        if not p or not self._recovery_key:
            return
        text = (f"Lost Within — Recovery Key\n\n{self._recovery_key}\n\n"
                f"Unlocks: {res.descriptor_path.name}\n"
                "Store this apart from the descriptor. Anyone with both can recover the data.\n")
        atomic_write_bytes(Path(p), text.encode("utf-8"), overwrite=True)


class _Switch:
    """Shows exactly one of its widgets."""

    def __init__(self):
        self.widgets: list[QWidget] = []

    def setCurrentWidget(self, widget: QWidget) -> None:
        for w in self.widgets:
            w.setVisible(w is widget)


def _delete_layout(layout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        if item.widget():
            item.widget().deleteLater()
        elif item.layout():
            _delete_layout(item.layout())
