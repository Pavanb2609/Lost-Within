"""Run long operations on a background QThread so the window stays responsive."""

from __future__ import annotations

import traceback
from typing import Callable

from PySide6.QtCore import QObject, QThread, Signal, Slot

from core.errors import LostWithinError, OperationCancelled
from core.streaming import CancelToken, ProgressInfo


class _Worker(QObject):
    progress = Signal(object)          # ProgressInfo
    succeeded = Signal(object)         # result object
    failed = Signal(str, str, bool)    # title, message, cancelled
    done = Signal()

    def __init__(self, fn: Callable[[Callable[[ProgressInfo], None], CancelToken], object], cancel: CancelToken):
        super().__init__()
        self._fn = fn
        self.cancel = cancel

    @Slot()
    def run(self) -> None:
        try:
            result = self._fn(self.progress.emit, self.cancel)
        except OperationCancelled as exc:
            self.failed.emit(exc.title, str(exc), True)
        except LostWithinError as exc:
            self.failed.emit(exc.title, str(exc), False)
        except MemoryError:
            self.failed.emit("Out of memory", "Not enough memory. Try a lower key-derivation strength in Settings.", False)
        except Exception as exc:  # noqa: BLE001 - unexpected bug: report, never crash the UI
            # The traceback never contains passwords: requests hide them in __repr__.
            detail = "".join(traceback.format_exception_only(type(exc), exc)).strip()
            self.failed.emit("Unexpected error", f"{detail}\n\nIncomplete output was removed where possible.", False)
        else:
            self.succeeded.emit(result)
        finally:
            self.done.emit()


class TaskRunner(QObject):
    """Owns one background operation at a time."""

    progress = Signal(object)
    succeeded = Signal(object)
    failed = Signal(str, str, bool)
    finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._thread: QThread | None = None
        self._worker: _Worker | None = None
        self._cancel: CancelToken | None = None

    @property
    def running(self) -> bool:
        return self._thread is not None

    def start(self, fn) -> None:
        if self.running:
            raise RuntimeError("an operation is already running")
        self._cancel = CancelToken()
        thread = QThread()
        worker = _Worker(fn, self._cancel)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self.progress)
        worker.succeeded.connect(self.succeeded)
        worker.failed.connect(self.failed)
        worker.done.connect(thread.quit)
        thread.finished.connect(self._cleanup)
        self._thread, self._worker = thread, worker
        thread.start()

    def cancel(self) -> None:
        if self._cancel is not None:
            self._cancel.cancel()

    def wait(self, ms: int = 15000) -> bool:
        if self._thread is None:
            return True
        return self._thread.wait(ms)

    def _cleanup(self) -> None:
        if self._worker is not None:
            self._worker.deleteLater()
        if self._thread is not None:
            self._thread.deleteLater()
        self._thread = self._worker = None
        self._cancel = None
        self.finished.emit()
