"""Reusable widgets: cave backdrop, drop zone, maze visualization, lantern progress bar."""

from __future__ import annotations

import math
import random
from pathlib import Path
from typing import Optional

from PySide6.QtCore import (QEasingCurve, QPointF, QPropertyAnimation, QRectF, Qt, QTimer, QVariantAnimation,
                            Signal)
from PySide6.QtGui import (QBrush, QColor, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap,
                           QRadialGradient)
from PySide6.QtWidgets import (QFileDialog, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel, QLineEdit,
                               QPushButton, QSizePolicy, QStackedWidget, QVBoxLayout, QWidget)

from core.maze import MazePlan
from ui import styles as S
from utils.filesystem import human_size

ANIMATIONS = {"enabled": True}  # toggled from Settings


# ---------------------------------------------------------------- small helpers

def label(text: str = "", obj: str = "", *, wrap: bool = False, selectable: bool = False,
          align: Qt.AlignmentFlag | None = None) -> QLabel:
    lab = QLabel(text)
    if obj:
        lab.setObjectName(obj)
    lab.setWordWrap(wrap)
    if selectable:
        lab.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    if align is not None:
        lab.setAlignment(align)
    return lab


def card(margins: int = 22, spacing: int = 12) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("Card")
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(margins, margins, margins, margins)
    lay.setSpacing(spacing)
    return frame, lay


def callout(text: str, danger: bool = False) -> QFrame:
    frame = QFrame()
    frame.setObjectName("DangerCallout" if danger else "Callout")
    lay = QHBoxLayout(frame)
    lay.setContentsMargins(14, 10, 14, 10)
    lab = label(text, "ErrorText" if danger else "CalloutText", wrap=True)
    lab.setTextFormat(Qt.TextFormat.RichText)
    lay.addWidget(lab)
    frame.text_label = lab  # type: ignore[attr-defined]
    return frame


def button(text: str, obj: str = "", slot=None) -> QPushButton:
    b = QPushButton(text)
    if obj:
        b.setObjectName(obj)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if slot:
        b.clicked.connect(slot)
    return b


class PathField(QWidget):
    """Line edit + Browse button for choosing a folder or file."""

    changed = Signal(str)

    def __init__(self, mode: str = "dir", caption: str = "Choose", filter_: str = "", placeholder: str = ""):
        super().__init__()
        self.mode, self.caption, self.filter = mode, caption, filter_
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText(placeholder)
        self.edit.textChanged.connect(self.changed)
        self.btn = button("Browse…", slot=self._browse)
        lay.addWidget(self.edit, 1)
        lay.addWidget(self.btn)

    def _browse(self) -> None:
        start = self.edit.text() or str(Path.home())
        if self.mode == "dir":
            p = QFileDialog.getExistingDirectory(self, self.caption, start)
        elif self.mode == "save":
            p, _ = QFileDialog.getSaveFileName(self, self.caption, start, self.filter)
        else:
            p, _ = QFileDialog.getOpenFileName(self, self.caption, start, self.filter)
        if p:
            self.edit.setText(str(Path(p)))

    def text(self) -> str:
        return self.edit.text().strip()

    def setText(self, t: str) -> None:
        self.edit.setText(t)


# ---------------------------------------------------------------- backdrop

class CaveBackground(QWidget):
    """Deep background with a lantern glow and a barely-visible labyrinth etching."""

    def __init__(self):
        super().__init__()
        self.setObjectName("Root")
        self._cache: Optional[QPixmap] = None
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

    def resizeEvent(self, e):
        self._cache = None
        super().resizeEvent(e)

    def _render(self) -> QPixmap:
        w, h = max(1, self.width()), max(1, self.height())
        pm = QPixmap(w, h)
        pm.fill(QColor(S.BG))
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        # Decorative etching. Uses a *seeded, non-cryptographic* RNG on purpose:
        # it is purely visual and must look the same every launch.
        rng = random.Random(1937)
        cell = 34
        pen = QPen(S.qc(S.TEXT, 9), 1.2)
        p.setPen(pen)
        for gx in range(0, w // cell + 2):
            for gy in range(0, h // cell + 2):
                x, y = gx * cell, gy * cell
                if rng.random() < 0.5:
                    p.drawLine(x, y, x + cell, y)
                else:
                    p.drawLine(x, y, x, y + cell)
        # lantern glow from above, vignette at the edges
        g = QRadialGradient(QPointF(w * 0.5, h * 0.18), max(w, h) * 0.75)
        g.setColorAt(0.0, S.qc("#2a2116", 120))
        g.setColorAt(0.35, S.qc("#121619", 60))
        g.setColorAt(1.0, S.qc(S.BG, 0))
        p.fillRect(0, 0, w, h, g)
        v = QRadialGradient(QPointF(w * 0.5, h * 0.45), max(w, h) * 0.8)
        v.setColorAt(0.55, S.qc("#000000", 0))
        v.setColorAt(1.0, S.qc("#000000", 200))
        p.fillRect(0, 0, w, h, v)
        p.end()
        return pm

    def paintEvent(self, e):
        if self._cache is None or self._cache.size() != self.size():
            self._cache = self._render()
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache)


# ---------------------------------------------------------------- page transitions

class FadeStack(QStackedWidget):
    def fade_to(self, widget: QWidget) -> None:
        if widget is self.currentWidget():
            return
        self.setCurrentWidget(widget)
        if not ANIMATIONS["enabled"]:
            return
        eff = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(eff)
        anim = QPropertyAnimation(eff, b"opacity", widget)
        anim.setDuration(240)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        # remove the effect afterwards: it slows down repaints of complex pages
        anim.finished.connect(lambda: widget.setGraphicsEffect(None))
        anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)


# ---------------------------------------------------------------- drop zone

class DropZone(QFrame):
    """Dashed tunnel mouth that accepts dropped files/folders."""

    dropped = Signal(Path)
    browse_file = Signal()
    browse_folder = Signal()
    cleared = Signal()

    def __init__(self, title: str = "DROP FILE HERE", compact: bool = False, accept_ext: str = ""):
        super().__init__()
        self.setAcceptDrops(True)
        self.accept_ext = accept_ext
        self._hover = False
        self._glow = 0.0
        self.setMinimumHeight(130 if compact else 200)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 18, 24, 18)
        lay.setSpacing(6)
        lay.addStretch()
        self.title = label(title, align=Qt.AlignmentFlag.AlignCenter)
        self.title.setFont(S.display_font(16 if compact else 19, spacing=5))
        self.title.setStyleSheet(f"color: {S.TEXT};")
        self.sub = label("or", "Hint", align=Qt.AlignmentFlag.AlignCenter)
        links = QHBoxLayout()
        links.setSpacing(4)
        links.addStretch()
        self.file_btn = button("Browse Files", "Ghost", self.browse_file.emit)
        self.folder_btn = button("Browse Folder", "Ghost", self.browse_folder.emit)
        self.sep = label("·", "Hint")
        self.clear_btn = button("Clear", "Ghost", self.cleared.emit)
        self.clear_btn.hide()
        for w in (self.file_btn, self.sep, self.folder_btn, self.clear_btn):
            links.addWidget(w)
        links.addStretch()
        lay.addWidget(self.title)
        lay.addWidget(self.sub)
        lay.addLayout(links)
        lay.addStretch()

        self._pulse = QVariantAnimation(self, startValue=0.0, endValue=1.0, duration=220)
        self._pulse.valueChanged.connect(self._set_glow)

    def show_folder_button(self, show: bool) -> None:
        self.folder_btn.setVisible(show)
        self.sep.setVisible(show)

    def set_selected(self, title: str, subtitle: str) -> None:
        self.title.setText(title)
        self.title.setStyleSheet(f"color: {S.ACCENT_HI};")
        self.sub.setText(subtitle)
        self.clear_btn.show()

    def reset(self, title: str = "DROP FILE HERE") -> None:
        self.title.setText(title)
        self.title.setStyleSheet(f"color: {S.TEXT};")
        self.sub.setText("or")
        self.clear_btn.hide()

    def _set_glow(self, v):
        self._glow = float(v)
        self.update()

    def _animate(self, on: bool):
        self._hover = on
        self._pulse.stop()
        self._pulse.setStartValue(self._glow)
        self._pulse.setEndValue(1.0 if on else 0.0)
        self._pulse.setDuration(220 if ANIMATIONS["enabled"] else 1)
        self._pulse.start()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls() and any(u.isLocalFile() for u in e.mimeData().urls()):
            e.acceptProposedAction()
            self._animate(True)

    def dragLeaveEvent(self, e):
        self._animate(False)

    def dropEvent(self, e):
        self._animate(False)
        urls = [u for u in e.mimeData().urls() if u.isLocalFile()]
        if urls:
            e.acceptProposedAction()
            self.dropped.emit(Path(urls[0].toLocalFile()))

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        g = QRadialGradient(r.center(), r.width() * 0.6)
        g.setColorAt(0, S.qc(S.ACCENT, int(10 + 30 * self._glow)))
        g.setColorAt(1, S.qc(S.SURFACE, 150))
        p.setBrush(QBrush(g))
        border = QColor(S.BORDER_HI)
        accent = QColor(S.ACCENT)
        mix = QColor(
            int(border.red() + (accent.red() - border.red()) * self._glow),
            int(border.green() + (accent.green() - border.green()) * self._glow),
            int(border.blue() + (accent.blue() - border.blue()) * self._glow),
        )
        pen = QPen(mix, 1.4, Qt.PenStyle.CustomDashLine)
        pen.setDashPattern([5, 4])
        p.setPen(pen)
        p.drawRoundedRect(r, 12, 12)


# ---------------------------------------------------------------- maze visualization

class MazeView(QWidget):
    """Draws a maze plan as tunnels. The true path glows like a lit passage.

    modes:
      "preview"  - reveal animation, whole true path lit
      "progress" - a lantern travels along the true path as work progresses
    """

    MAX_NODES = 1800

    def __init__(self, mode: str = "preview"):
        super().__init__()
        self.mode = mode
        self.setMinimumSize(320, 220)
        self._plan: Optional[MazePlan] = None
        self._edges: list[tuple[int, int, int, int, int, bool]] = []  # x0,y0,x1,y1,depth,true
        self._true_points: list[tuple[float, float]] = []
        self._decoys: list[tuple[int, float]] = []
        self._max_depth = 1
        self._max_y = 1.0
        self._reveal = 1.0
        self._lantern = 0.0
        self._phase = 0.0
        self.simplified = False
        self._reveal_anim = QVariantAnimation(self, startValue=0.0, endValue=1.0, duration=1100)
        self._reveal_anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self._reveal_anim.valueChanged.connect(self._on_reveal)
        self._lantern_anim = QVariantAnimation(self, duration=400)
        self._lantern_anim.valueChanged.connect(self._on_lantern)
        self._timer = QTimer(self)
        self._timer.setInterval(60)
        self._timer.timeout.connect(self._tick)

    # -- data
    def set_plan(self, plan: Optional[MazePlan], animate: bool = True) -> None:
        self._plan = plan
        self._layout()
        if animate and ANIMATIONS["enabled"] and self.mode == "preview":
            self._reveal_anim.stop()
            self._reveal_anim.start()
        else:
            self._reveal = 1.0
        self.update()

    def set_lantern(self, fraction: float) -> None:
        fraction = max(0.0, min(1.0, fraction))
        if not ANIMATIONS["enabled"]:
            self._lantern = fraction
            self.update()
            return
        self._lantern_anim.stop()
        self._lantern_anim.setStartValue(self._lantern)
        self._lantern_anim.setEndValue(fraction)
        self._lantern_anim.start()

    def _on_reveal(self, v):
        self._reveal = float(v)
        self.update()

    def _on_lantern(self, v):
        self._lantern = float(v)
        self.update()

    def _tick(self):
        self._phase = (self._phase + 0.06) % (2 * math.pi)
        self.update()

    def showEvent(self, e):
        if ANIMATIONS["enabled"]:
            self._timer.start()
        super().showEvent(e)

    def hideEvent(self, e):
        self._timer.stop()
        super().hideEvent(e)

    def _layout(self) -> None:
        self._edges.clear()
        self._true_points.clear()
        self._decoys.clear()
        plan = self._plan
        if plan is None:
            return
        dirs = plan.directories
        true_set = {plan.true_path[:i] for i in range(1, len(plan.true_path) + 1)}
        self.simplified = len(dirs) > self.MAX_NODES
        if self.simplified:  # keep the true path, its siblings and a sample of the rest
            keep = set(true_set)
            for d in dirs:
                if len(d) <= len(plan.true_path) and d[:-1] in true_set | {()}:
                    keep.add(d)
            rest = [d for d in dirs if d not in keep]
            step = max(1, len(rest) // (self.MAX_NODES - len(keep)))
            for d in rest[::step]:
                for i in range(1, len(d) + 1):
                    keep.add(d[:i])
            dirs = [d for d in dirs if d in keep]
        children: dict[tuple, list[tuple]] = {(): []}
        for d in dirs:
            children.setdefault(d, [])
            children.setdefault(d[:-1], []).append(d)
        ypos: dict[tuple, float] = {}
        counter = [0.0]

        def place(node: tuple) -> float:
            kids = children.get(node, [])
            if not kids:
                ypos[node] = counter[0]
                counter[0] += 1
            else:
                ys = [place(k) for k in kids]
                ypos[node] = (ys[0] + ys[-1]) / 2
            return ypos[node]

        import sys
        old = sys.getrecursionlimit()
        sys.setrecursionlimit(max(old, 200))
        place(())
        sys.setrecursionlimit(old)
        self._max_y = max(1.0, counter[0] - 1)
        self._max_depth = max(1, max((len(d) for d in dirs), default=1))
        for d in dirs:
            parent = d[:-1]
            self._edges.append((len(parent), ypos[parent], len(d), ypos[d], len(d), d in true_set))
        self._true_points = [(0, ypos[()])] + [(len(plan.true_path[:i]), ypos[plan.true_path[:i]])
                                                for i in range(1, len(plan.true_path) + 1)]
        for folder, _, _ in plan.decoy_files:
            if folder in ypos:
                self._decoys.append((len(folder), ypos[folder]))

    # -- painting
    def _map(self, x: float, y: float, rect: QRectF) -> QPointF:
        return QPointF(rect.left() + rect.width() * x / (self._max_depth + 0.6),
                       rect.top() + rect.height() * (y / self._max_y if self._max_y else 0.5))

    def _tunnel(self, a: QPointF, b: QPointF) -> QPainterPath:
        path = QPainterPath(a)
        mid = a.x() + (b.x() - a.x()) * 0.45
        path.lineTo(mid, a.y())
        path.lineTo(mid, b.y())
        path.lineTo(b)
        return path

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(18, 16, -26, -16)
        if not self._edges:
            p.setPen(S.qc(S.TEXT_FAINT))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No maze")
            return
        limit = self._reveal * (self._max_depth + 0.999)
        dense = len(self._edges) > 600
        dim = QPen(S.qc(S.TEXT_FAINT, 70 if dense else 110), 1.0 if dense else 1.3)
        p.setPen(dim)
        p.setBrush(Qt.BrushStyle.NoBrush)
        for x0, y0, x1, y1, depth, is_true in self._edges:
            if depth > limit + 1:
                continue
            if depth > limit:
                p.setOpacity(max(0.0, limit + 1 - depth))
            p.drawPath(self._tunnel(self._map(x0, y0, rect), self._map(x1, y1, rect)))
            p.setOpacity(1.0)
        # decoy files: small dull squares
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(S.qc(S.TEXT_FAINT, 120))
        for depth, y in self._decoys:
            if depth <= limit:
                pt = self._map(depth, y, rect)
                p.drawRect(QRectF(pt.x() + 3, pt.y() - 2.5, 5, 5))

        # the lit path
        pts = [self._map(x, y, rect) for x, y in self._true_points]
        path = QPainterPath(pts[0])
        for a, b in zip(pts, pts[1:]):
            path.addPath(self._tunnel(a, b))
        if self.mode == "progress":
            lit_fraction = self._lantern
        else:
            lit_fraction = min(1.0, limit / max(1, len(pts) - 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        if self.mode == "progress":
            p.setPen(QPen(S.qc(S.ACCENT, 40), 1.6))
            p.drawPath(path)
        lit = self._partial(pts, lit_fraction)
        for width, alpha in ((9, 22), (5, 45), (2.0, 230)):
            p.setPen(QPen(S.qc(S.ACCENT, alpha), width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                          Qt.PenJoinStyle.RoundJoin))
            p.drawPath(lit[0])
        # payload / lantern
        pulse = 0.5 + 0.5 * math.sin(self._phase)
        if self.mode == "progress":
            self._glow(p, lit[1], 7 + 2 * pulse, S.ACCENT_HI)
            self._entrance(p, pts[0])
        else:
            self._entrance(p, pts[0])
            if lit_fraction >= 0.999:
                self._glow(p, pts[-1], 6 + 2.5 * pulse, S.ACCENT_HI)

    def _entrance(self, p: QPainter, pt: QPointF):
        p.setPen(QPen(S.qc(S.TEXT_DIM), 1.4))
        p.setBrush(S.qc(S.BG))
        p.drawEllipse(pt, 4.5, 4.5)

    @staticmethod
    def _glow(p: QPainter, pt: QPointF, r: float, color: str):
        g = QRadialGradient(pt, r * 4)
        g.setColorAt(0, S.qc(color, 150))
        g.setColorAt(1, S.qc(color, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(g)
        p.drawEllipse(pt, r * 4, r * 4)
        p.setBrush(S.qc(color))
        p.drawEllipse(pt, r * 0.55, r * 0.55)

    def _partial(self, pts: list[QPointF], frac: float) -> tuple[QPainterPath, QPointF]:
        """Tunnel path from the entrance covering ``frac`` of the true path."""
        full = QPainterPath(pts[0])
        for a, b in zip(pts, pts[1:]):
            mid = a.x() + (b.x() - a.x()) * 0.45
            full.lineTo(mid, a.y())
            full.lineTo(mid, b.y())
            full.lineTo(b)
        if frac >= 0.999:
            return full, pts[-1]
        length = full.length() * max(0.0, frac)
        out = QPainterPath(pts[0])
        steps = 120
        end = pts[0]
        for i in range(1, steps + 1):
            t = full.percentAtLength(length * i / steps)
            end = full.pointAtPercent(t)
            out.lineTo(end)
        return out, end


# ---------------------------------------------------------------- progress

class LanternProgress(QWidget):
    """A thin progress track with a warm glowing head. Smoothly animated."""

    def __init__(self):
        super().__init__()
        self.setFixedHeight(22)
        self._value = 0.0
        self._indeterminate = False
        self._phase = 0.0
        self._anim = QVariantAnimation(self, duration=260)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._set)
        self._timer = QTimer(self, interval=30)
        self._timer.timeout.connect(self._tick)

    def set_value(self, frac: float) -> None:
        frac = max(0.0, min(1.0, frac))
        self.set_indeterminate(False)
        if not ANIMATIONS["enabled"] or frac < self._value:
            self._anim.stop()
            self._set(frac)
            return
        self._anim.stop()
        self._anim.setStartValue(self._value)
        self._anim.setEndValue(frac)
        self._anim.start()

    def set_indeterminate(self, on: bool) -> None:
        self._indeterminate = on
        if on and ANIMATIONS["enabled"]:
            self._timer.start()
        else:
            self._timer.stop()
        self.update()

    def _set(self, v):
        self._value = float(v)
        self.update()

    def _tick(self):
        self._phase = (self._phase + 0.012) % 1.0
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(2, 8, -2, -8)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(S.qc(S.BORDER))
        p.drawRoundedRect(r, 3, 3)
        if self._indeterminate:
            w = r.width() * 0.22
            x = r.left() - w + (r.width() + w) * self._phase
            g = QLinearGradient(x, 0, x + w, 0)
            g.setColorAt(0, S.qc(S.ACCENT, 0))
            g.setColorAt(0.7, S.qc(S.ACCENT, 200))
            g.setColorAt(1, S.qc(S.ACCENT, 0))
            p.setBrush(g)
            p.drawRoundedRect(QRectF(max(r.left(), x), r.top(), min(w, r.right() - x), r.height()), 3, 3)
            return
        if self._value <= 0:
            return
        fw = r.width() * self._value
        g = QLinearGradient(r.left(), 0, r.left() + fw, 0)
        g.setColorAt(0, S.qc(S.ACCENT_DEEP))
        g.setColorAt(1, S.qc(S.ACCENT))
        p.setBrush(g)
        p.drawRoundedRect(QRectF(r.left(), r.top(), fw, r.height()), 3, 3)
        head = QPointF(r.left() + fw, r.center().y())
        glow = QRadialGradient(head, 14)
        glow.setColorAt(0, S.qc(S.ACCENT_HI, 160))
        glow.setColorAt(1, S.qc(S.ACCENT_HI, 0))
        p.setBrush(glow)
        p.drawEllipse(head, 14, 14)


class StrengthMeter(QWidget):
    COLORS = [S.DANGER, S.DANGER, S.WARN, S.SUCCESS, S.SUCCESS]

    def __init__(self):
        super().__init__()
        self.setFixedHeight(6)
        self.score = -1

    def set_score(self, score: int) -> None:
        self.score = score
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        gap = 5
        w = (self.width() - 3 * gap) / 4
        lit = 0 if self.score < 0 else max(1, self.score)  # score -1 = empty field
        for i in range(4):
            on = i < lit
            color = S.qc(self.COLORS[max(0, self.score)]) if on else S.qc(S.BORDER)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(color)
            p.drawRoundedRect(QRectF(i * (w + gap), 0, w, self.height()), 2, 2)


def describe_path(path: Path) -> tuple[str, str]:
    """Title and subtitle for a selected file/folder."""
    try:
        if path.is_dir():
            return path.name or str(path), "Folder"
        return path.name, f"File · {human_size(path.stat().st_size)}"
    except OSError:
        return path.name, "Unavailable"
