"""Recovery: select the descriptor, unlock, and find the way back."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QFileDialog, QGridLayout, QHBoxLayout, QLineEdit,
                               QRadioButton)

from core.errors import LostWithinError
from core.recovery import find_maze_root_public, load_descriptor
from models.metadata import DESCRIPTOR_EXT, SLOT_PASSWORD, Descriptor
from models.settings import AppSettings
from ui import styles as S
from ui.page import Page
from ui.widgets import DropZone, PathField, button, callout, card, label
from utils.filesystem import human_size


class RecoveryPage(Page):
    start_requested = Signal()
    back_requested = Signal()

    def __init__(self, settings: AppSettings):
        super().__init__("Recovery", "Bring the descriptor. Speak the password. Find your way back.")
        self.settings = settings
        self.descriptor: Optional[Descriptor] = None
        self.descriptor_path: Optional[Path] = None
        self.maze_root: Optional[Path] = None

        # ---------------------------------------------------- descriptor
        self.zone = DropZone("DROP .LOSTWITHIN HERE", compact=True)
        self.zone.show_folder_button(False)
        self.zone.file_btn.setText("Browse for descriptor")
        self.zone.dropped.connect(self.load)
        self.zone.browse_file.connect(self._browse)
        self.zone.cleared.connect(self.clear)
        self.body.addWidget(self.zone)

        self.info_card, lay = card()
        lay.addWidget(label("DESCRIPTOR", "SectionLabel"))
        self.info_grid = QGridLayout()
        self.info_grid.setHorizontalSpacing(22)
        self.info_grid.setVerticalSpacing(8)
        self.info_grid.setColumnStretch(1, 1)
        self.info_values: dict[str, object] = {}
        for i, key in enumerate(("Format", "Encryption", "Key derivation", "Payload", "Recovery key")):
            self.info_grid.addWidget(label(key, "FieldLabel"), i, 0)
            v = label("", "Value", wrap=True, selectable=True)
            self.info_grid.addWidget(v, i, 1)
            self.info_values[key] = v
        lay.addLayout(self.info_grid)
        maze_row = QHBoxLayout()
        maze_row.addWidget(label("Maze", "FieldLabel"))
        maze_row.addSpacing(14)
        self.maze_status = label("", "Value", wrap=True)
        maze_row.addWidget(self.maze_status, 1)
        maze_row.addWidget(button("Select maze folder…", slot=self._pick_maze))
        lay.addLayout(maze_row)
        self.body.addWidget(self.info_card)
        self.desc_error = label("", "ErrorText", wrap=True)
        self.desc_error.hide()
        self.body.addWidget(self.desc_error)

        # ---------------------------------------------------- unlock
        c, lay = card()
        lay.addWidget(label("UNLOCK", "SectionLabel"))
        mode_row = QHBoxLayout()
        self.use_pw = QRadioButton("Password")
        self.use_rk = QRadioButton("Recovery key")
        self.use_pw.setChecked(True)
        grp = QButtonGroup(self)
        grp.addButton(self.use_pw)
        grp.addButton(self.use_rk)
        self.use_pw.toggled.connect(self._mode_changed)
        mode_row.addWidget(self.use_pw)
        mode_row.addWidget(self.use_rk)
        mode_row.addStretch()
        self.show_secret = QCheckBox("Show")
        self.show_secret.toggled.connect(self._mode_changed)
        mode_row.addWidget(self.show_secret)
        lay.addLayout(mode_row)
        self.secret = QLineEdit()
        self.secret.returnPressed.connect(self._start)
        lay.addWidget(self.secret)
        self.body.addWidget(c)

        # ---------------------------------------------------- destination
        c, lay = card()
        lay.addWidget(label("RESTORE TO", "SectionLabel"))
        self.dest = PathField("dir", "Choose where to restore the original")
        lay.addWidget(self.dest)
        self.verify_only = QCheckBox("Verify only — decrypt and check integrity without writing any files")
        self.verify_only.toggled.connect(lambda on: self.dest.setEnabled(not on))
        lay.addWidget(self.verify_only)
        lay.addWidget(label("Existing files are never overwritten without asking.", "Hint"))
        self.body.addWidget(c)

        self.body.addWidget(callout(
            "The <b>.lostwithin</b> descriptor is a recovery map, not a password. It holds the wrapped keys "
            "and the path through the maze. If it is lost, recovery may be impossible."))
        self.errors = label("", "ErrorText", wrap=True)
        self.body.addWidget(self.errors)
        nav = QHBoxLayout()
        nav.addWidget(button("‹  Back", slot=self.back_requested.emit))
        nav.addStretch()
        self.start_btn = button("FIND YOUR WAY BACK", "Primary", self._start)
        nav.addWidget(self.start_btn)
        self.body.addLayout(nav)
        self.body.addStretch()

        self.clear()
        self._mode_changed()
        if settings.last_restore_dir:
            self.dest.setText(settings.last_restore_dir)

    # ---------------------------------------------------- descriptor
    def _browse(self) -> None:
        p, _ = QFileDialog.getOpenFileName(self, "Open recovery descriptor", str(Path.home()),
                                           f"Lost Within descriptor (*{DESCRIPTOR_EXT});;All files (*)")
        if p:
            self.load(Path(p))

    def clear(self) -> None:
        self.descriptor = self.descriptor_path = self.maze_root = None
        self.zone.reset("DROP .LOSTWITHIN HERE")
        self.info_card.hide()
        self.desc_error.setText("")
        self.desc_error.hide()
        self.use_rk.setEnabled(True)

    def load(self, path: Path) -> None:
        path = Path(path)
        self.errors.setText("")
        try:
            desc = load_descriptor(path)
        except LostWithinError as exc:
            self.clear()
            self.desc_error.setText(f"✕  {exc}")
            self.desc_error.show()
            return
        self.descriptor, self.descriptor_path = desc, path
        self.desc_error.hide()
        self.zone.set_selected(path.name, f"Descriptor · {path.parent}")
        kdf = desc.slots(SLOT_PASSWORD)[0].kdf
        self.info_values["Format"].setText(f"Lost Within descriptor v{desc.version}  ({desc.app})")
        self.info_values["Encryption"].setText(f"AES-256-GCM, {human_size(desc.payload.chunk_size)} authenticated chunks")
        self.info_values["Key derivation"].setText(kdf.description)
        self.info_values["Payload"].setText(f"{human_size(desc.payload.size)}  ·  SHA-256 {desc.payload.sha256[:20]}…")
        self.info_values["Recovery key"].setText("Available" if desc.has_recovery_key else "Not created")
        self.use_rk.setEnabled(desc.has_recovery_key)
        if not desc.has_recovery_key:
            self.use_pw.setChecked(True)
        if not self.dest.text():
            self.dest.setText(str(path.parent))
        self.maze_root = None
        self._update_maze()
        self.info_card.show()
        self.secret.setFocus()

    def _update_maze(self) -> None:
        if not self.descriptor:
            return
        found = find_maze_root_public(self.descriptor, self.descriptor_path, self.maze_root)
        if found:
            self.maze_status.setText(f"✓  Found: {found}")
            self.maze_status.setStyleSheet(f"color: {S.SUCCESS};")
        else:
            self.maze_status.setText(f"Not next to the descriptor ({self.descriptor.maze.root_name}). Its original "
                                     "location will be tried after unlocking — or select the maze folder.")
            self.maze_status.setStyleSheet(f"color: {S.WARN};")

    def _pick_maze(self) -> None:
        start = str(self.descriptor_path.parent) if self.descriptor_path else str(Path.home())
        p = QFileDialog.getExistingDirectory(self, "Select the maze root (or the folder containing it)", start)
        if p:
            self.maze_root = Path(p)
            self._update_maze()

    # ---------------------------------------------------- unlock
    def _mode_changed(self, *_):
        rk = self.use_rk.isChecked()
        self.secret.setPlaceholderText("LW1-XXXX-XXXX-…" if rk else "Password")
        self.secret.setEchoMode(QLineEdit.EchoMode.Normal if (self.show_secret.isChecked() or rk)
                                else QLineEdit.EchoMode.Password)
        self.secret.setFont(S.mono_font(13) if rk else self.font())

    def problems(self) -> list[str]:
        out = []
        if self.descriptor is None:
            out.append("Choose a .lostwithin descriptor.")
        if not self.secret.text():
            out.append("Enter the recovery key." if self.use_rk.isChecked() else "Enter the password.")
        if not self.verify_only.isChecked() and (not self.dest.text() or not Path(self.dest.text()).is_dir()):
            out.append("Choose an existing destination folder.")
        return out

    def _start(self) -> None:
        problems = self.problems()
        self.errors.setText("\n".join(f"•  {p}" for p in problems))
        if not problems:
            self.start_requested.emit()

    def request_values(self) -> dict:
        secret = self.secret.text()
        return {
            "descriptor_path": self.descriptor_path,
            "destination_dir": None if self.verify_only.isChecked() else Path(self.dest.text()),
            "password": None if self.use_rk.isChecked() else secret,
            "recovery_key": secret if self.use_rk.isChecked() else None,
            "maze_root": self.maze_root,
            "verify_only": self.verify_only.isChecked(),
        }

    def clear_secrets(self) -> None:
        self.secret.clear()
        self.show_secret.setChecked(False)
