"""About Lost Within: what it does, how, and what it cannot do."""

from __future__ import annotations

from PySide6.QtCore import Qt

from core import __version__
from core.key_derivation import argon2_backend
from ui import styles as S
from ui.page import Page
from ui.widgets import card, label

HOW = [
    ("Enter", "A random 256-bit data key is created. Your password is stretched with Argon2id into a "
              "key-encryption key that wraps it; an optional Recovery Key wraps it a second time."),
    ("Disappear", "The file (or a folder, packed on the fly) is streamed through AES-256-GCM in 4 MiB "
                  "authenticated chunks into a new maze of randomly named folders. Nothing is ever loaded "
                  "whole into memory, so 70 GB+ works the same as 70 KB."),
    ("Find your way back", "The .lostwithin descriptor holds the wrapped keys and, encrypted, the original "
                           "name and the path through the maze. With the password, every chunk is "
                           "authenticated, both SHA-256 digests are checked, and only then is the original "
                           "restored under its name."),
]

LIMITS = [
    "<b>The maze is obfuscation, not security.</b> Anyone with disk access can list it and find the payload "
    "(usually the largest file). Its size and timestamps are visible.",
    "<b>Security rests on your password.</b> Argon2id slows guessing, but a short or common password can "
    "still be guessed offline by someone who has the descriptor.",
    "<b>The descriptor is required.</b> It holds the wrapped data key. Lose it and recovery may be impossible; "
    "keep backups, ideally apart from the maze.",
    "<b>No protection on a compromised computer.</b> Malware, keyloggers or someone with access to your "
    "unlocked session can capture the password or the recovered file.",
    "<b>Memory hygiene is best-effort.</b> Python cannot reliably erase passwords and keys from RAM; they "
    "may linger in memory, the page file or a hibernation file.",
    "<b>Your original is left untouched.</b> Lost Within does not delete it. Deleting files, especially on "
    "SSDs or cloud-synced folders, may not destroy the data.",
    "<b>Metadata leaks.</b> The payload's approximate size, the time of burial and the maze's existence are "
    "not hidden. A descriptor named after the file reveals that name — use “Randomize”.",
    "<b>Not independently audited.</b> It uses the well-reviewed <i>cryptography</i> library (OpenSSL) and "
    "standard constructions, but this application itself has not had a professional security audit.",
]


class AboutPage(Page):
    def __init__(self):
        super().__init__("About Lost Within", f"Version {__version__}  ·  Enter. Disappear. Find your way back.")

        c, lay = card(26, 14)
        intro = label("Lost Within encrypts a file or folder and buries it deep inside a randomly generated maze "
                      "of folders. A small recovery descriptor and your password are the way back.",
                      wrap=True)
        intro.setStyleSheet(f"font-size: 15px; color: {S.TEXT};")
        lay.addWidget(intro)
        for i, (title, text) in enumerate(HOW, 1):
            t = label(f"{i:02d}  ·  {title.upper()}")
            t.setFont(S.display_font(14, S.QFont.Weight.Normal, 3))
            t.setStyleSheet(f"color: {S.ACCENT};")
            lay.addSpacing(4)
            lay.addWidget(t)
            lay.addWidget(label(text, "PageSubtitle", wrap=True))
        self.body.addWidget(c)

        c, lay = card(26, 10)
        lay.addWidget(label("SECURITY MODEL", "SectionLabel"))
        rows = [
            ("Encryption", "AES-256-GCM (authenticated) in the STREAM chunked construction"),
            ("Key derivation", f"Argon2id, salted, parameters stored per burial  ·  {argon2_backend()}"),
            ("Subkeys", "HKDF-SHA256 from a random 256-bit data key"),
            ("Integrity", "Per-chunk GCM tags + SHA-256 of payload and of original"),
            ("Detects", "wrong password · modified, reordered, truncated or extended data · edited descriptor"),
            ("Randomness", "OS CSPRNG (secrets / os.urandom) for keys, salts, nonces and every maze name"),
            ("Restore safety", "filename sanitized, no path traversal, folders extracted with a safe filter, "
                               "no overwrite without confirmation, atomic rename after verification"),
        ]
        for k, v in rows:
            r = label(f"<span style='color:{S.TEXT_FAINT}'>{k}</span>&nbsp;&nbsp;&nbsp;{v}", wrap=True)
            r.setTextFormat(Qt.TextFormat.RichText)
            lay.addWidget(r)
        self.body.addWidget(c)

        c, lay = card(26, 10)
        lay.addWidget(label("LIMITATIONS — READ THESE", "SectionLabel"))
        for item in LIMITS:
            r = label(f"—&nbsp;&nbsp;{item}", wrap=True)
            r.setTextFormat(Qt.TextFormat.RichText)
            r.setStyleSheet(f"color: {S.TEXT_DIM};")
            lay.addWidget(r)
        self.body.addWidget(c)
        self.body.addWidget(label("Built with Python, PySide6 (Qt), cryptography and argon2-cffi.", "Hint"))
        self.body.addStretch()
