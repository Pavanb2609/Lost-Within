"""Main window: navigation, drag-and-drop routing and the bury/recover controllers."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QIcon, QPainter, QPen
from PySide6.QtWidgets import (QApplication, QButtonGroup, QHBoxLayout, QMainWindow, QMessageBox, QPushButton,
                               QVBoxLayout, QWidget)

from core import APP_NAME, __version__
from core.burial import BuryRequest, bury
from core.journal import Journal
from core.key_derivation import KDF_PRESETS
from core.recovery import CONFLICT_ERROR, CONFLICT_OVERWRITE, CONFLICT_RENAME, RecoverRequest, recover
from core.errors import DestinationExistsError
from models.metadata import DESCRIPTOR_EXT
from models.settings import AppSettings
from ui import styles as S
from ui.about_page import AboutPage
from ui.bury_page import BuryPage
from ui.home_page import HomePage
from ui.maze_page import MazePage
from ui.progress_page import ProgressPage
from ui.recovery_page import RecoveryPage
from ui.settings_page import SettingsPage
from ui.widgets import ANIMATIONS, CaveBackground, FadeStack, label
from ui.workers import TaskRunner

ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
ICON = ROOT / "assets" / "icons" / "lost_within.png"


class Glyph(QWidget):
    """Tiny concentric-maze mark next to the wordmark."""

    def __init__(self):
        super().__init__()
        self.setFixedSize(22, 22)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(S.qc(S.TEXT_DIM), 1.4))
        for i, gap in enumerate((0, 1, 2)):
            r = QRectF(1.5 + i * 4, 1.5 + i * 4, 19 - i * 8, 19 - i * 8)
            start = (90 + gap * 120) * 16
            p.drawArc(r, start, 300 * 16)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(S.qc(S.ACCENT))
        p.drawEllipse(QRectF(9, 9, 4, 4))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = AppSettings.load()
        ANIMATIONS["enabled"] = self.settings.animations
        self.journal = Journal()
        self.runner = TaskRunner(self)
        self._op: Optional[str] = None
        self._recover_values: Optional[dict] = None
        self._pending_conflict: Optional[str] = None

        self.setWindowTitle(f"{APP_NAME} — Secure File Maze")
        if ICON.exists():
            self.setWindowIcon(QIcon(str(ICON)))
        self.setMinimumSize(1000, 720)
        self.resize(1180, 860)
        self.setAcceptDrops(True)

        root = CaveBackground()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ------------------------------------------------ top bar
        bar = QWidget()
        bar.setObjectName("TopBar")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(24, 0, 18, 0)
        bl.addWidget(Glyph())
        bl.addSpacing(10)
        bl.addWidget(label("LOST WITHIN", "Wordmark"))
        bl.addStretch()
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav: dict[str, QPushButton] = {}
        for key, text in (("home", "HOME"), ("bury", "BURY"), ("recover", "RECOVER"),
                          ("settings", "SETTINGS"), ("about", "ABOUT")):
            b = QPushButton(text)
            b.setObjectName("NavButton")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.go(k))
            self.nav_group.addButton(b)
            self.nav[key] = b
            bl.addWidget(b)
        outer.addWidget(bar)

        # ------------------------------------------------ pages
        self.home = HomePage()
        self.bury_page = BuryPage(self.settings)
        self.maze_page = MazePage(self.settings)
        self.bury_progress = ProgressPage("bury")
        self.recovery_page = RecoveryPage(self.settings)
        self.recover_progress = ProgressPage("recover")
        self.settings_page = SettingsPage(self.settings, self.journal)
        self.about = AboutPage()
        self.stack = FadeStack()
        for w in (self.home, self.bury_page, self.maze_page, self.bury_progress, self.recovery_page,
                  self.recover_progress, self.settings_page, self.about):
            self.stack.addWidget(w)
        outer.addWidget(self.stack, 1)

        # ------------------------------------------------ footer
        foot = QWidget()
        foot.setObjectName("Footer")
        fl = QHBoxLayout(foot)
        fl.setContentsMargins(24, 7, 24, 8)
        self.footer_status = label("STATUS · READY", "FooterText")
        fl.addWidget(self.footer_status)
        fl.addStretch()
        fl.addWidget(label(f"AES-256-GCM · ARGON2ID · v{__version__}", "FooterText"))
        outer.addWidget(foot)

        # ------------------------------------------------ wiring
        self.home.bury_requested.connect(self._home_bury)
        self.home.recover_requested.connect(self._home_recover)
        self.bury_page.back_requested.connect(lambda: self.go("home"))
        self.bury_page.next_requested.connect(self._to_maze)
        self.maze_page.back_requested.connect(lambda: self.go("bury"))
        self.maze_page.start_requested.connect(self.start_bury)
        self.recovery_page.back_requested.connect(lambda: self.go("home"))
        self.recovery_page.start_requested.connect(lambda: self.start_recover(CONFLICT_ERROR))
        for page in (self.bury_progress, self.recover_progress):
            page.cancel_requested.connect(self.runner.cancel)
            page.home_requested.connect(lambda: self.go("home"))
        self.bury_progress.back_requested.connect(lambda: self.go("bury"))
        self.bury_progress.again_requested.connect(self._bury_again)
        self.recover_progress.back_requested.connect(lambda: self.go("recover"))
        self.recover_progress.again_requested.connect(self._recover_again)
        self.runner.progress.connect(self._on_progress)
        self.runner.succeeded.connect(self._on_success)
        self.runner.failed.connect(self._on_failure)
        self.runner.finished.connect(self._on_finished)
        self.settings_page.changed.connect(self._settings_changed)

        self.go("home", animate=False)

    # ------------------------------------------------------------------ navigation
    PAGES = {"home": "home", "bury": "bury_page", "maze": "maze_page", "bury_progress": "bury_progress",
             "recover": "recovery_page", "recover_progress": "recover_progress", "settings": "settings_page",
             "about": "about"}
    NAV_FOR = {"maze": "bury", "bury_progress": "bury", "recover_progress": "recover"}

    def go(self, key: str, animate: bool = True) -> None:
        if self.runner.running and key not in ("bury_progress", "recover_progress"):
            # keep the progress page in view while working; other pages stay reachable via nav only after
            if key in ("bury", "recover", "home", "maze"):
                key = "bury_progress" if self._op == "bury" else "recover_progress"
        widget = getattr(self, self.PAGES[key])
        if key == "settings":
            self.settings_page.refresh_pending()
        if animate:
            self.stack.fade_to(widget)
        else:
            self.stack.setCurrentWidget(widget)
        nav = self.NAV_FOR.get(key, key)
        if nav in self.nav:
            self.nav[nav].setChecked(True)

    def set_status(self, text: str) -> None:
        self.home.set_status(text)
        self.footer_status.setText(f"STATUS · {text.upper()}"[:110])

    # ------------------------------------------------------------------ drag & drop (whole window)
    def dragEnterEvent(self, e):
        if not self.runner.running and e.mimeData().hasUrls() and any(u.isLocalFile() for u in e.mimeData().urls()):
            e.acceptProposedAction()

    def dropEvent(self, e):
        urls = [u for u in e.mimeData().urls() if u.isLocalFile()]
        if not urls or self.runner.running:
            return
        e.acceptProposedAction()
        if len(urls) > 1:
            self.set_status("Several items dropped: only the first is used. Put them in a folder to bury them together.")
        self.route_path(Path(urls[0].toLocalFile()))

    def route_path(self, path: Path) -> None:
        if path.suffix.lower() == DESCRIPTOR_EXT and path.is_file():
            self.recovery_page.load(path)
            self.go("recover")
        elif self.stack.currentWidget() is self.bury_page:
            self.bury_page.set_source(path)
        else:
            self.home.accept_path(path)
            self.go("home")

    # ------------------------------------------------------------------ bury flow
    def _home_bury(self, source: Optional[Path]) -> None:
        if source is None:
            self.home.zone.browse_file.emit()
            source = self.home.source
            if source is None:
                return
        self.bury_page.set_source(source)
        self.go("bury")

    def _to_maze(self) -> None:
        out = Path(self.bury_page.output.text())
        self.maze_page.set_context(out, self.settings.long_paths)
        self.go("maze")

    def start_bury(self) -> None:
        bp = self.bury_page
        problems = bp.problems()
        if problems:
            self.go("bury")
            bp._next()
            return
        desc_path = bp.descriptor_path()
        overwrite = False
        if desc_path.exists():
            answer = QMessageBox.warning(
                self, "Descriptor already exists",
                f"“{desc_path.name}” already exists in\n{desc_path.parent}\n\n"
                "Overwriting it makes whatever it protected UNRECOVERABLE (its maze would be orphaned).\n\n"
                "Overwrite it?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel, QMessageBox.StandardButton.Cancel)
            if answer != QMessageBox.StandardButton.Yes:
                return
            overwrite = True
        maze = self.maze_page.config()
        req = BuryRequest(
            source=bp.source, output_dir=Path(bp.output.text()), password=bp.password(),
            descriptor_path=desc_path, maze=maze, kdf=KDF_PRESETS[self.settings.kdf_preset],
            chunk_size=self.settings.chunk_size, create_recovery_key=bp.recovery_key.isChecked(),
            overwrite_descriptor=overwrite, long_paths=self.settings.long_paths,
            min_password_length=self.settings.min_password_length,
        )
        bp.clear_secrets()
        # remember defaults (never the password)
        self.settings.maze = maze.to_dict()
        if self.settings.remember_folders:
            self.settings.last_output_dir = str(req.output_dir)
        self.settings.save()

        self._op = "bury"
        self.bury_progress.start(maze)
        self.go("bury_progress")
        self._lock_nav(True)
        self.set_status(f"Burying “{req.source.name}”…")
        self.runner.start(lambda emit, cancel: bury(req, emit, cancel, self.journal))

    def _bury_again(self) -> None:
        self.home.clear_source()
        self.bury_page.set_source(None)
        self.go("home")

    # ------------------------------------------------------------------ recover flow
    def _home_recover(self, path: Optional[Path]) -> None:
        if path is not None:
            self.recovery_page.load(path)
        self.go("recover")

    def start_recover(self, conflict: str) -> None:
        if conflict == CONFLICT_ERROR:
            self._recover_values = self.recovery_page.request_values()
            self.recovery_page.clear_secrets()
        values = self._recover_values
        if not values:
            return
        req = RecoverRequest(conflict=conflict, **values)
        if self.settings.remember_folders and req.destination_dir:
            self.settings.last_restore_dir = str(req.destination_dir)
            self.settings.save()
        self._op = "recover"
        self.recover_progress.start()
        self.go("recover_progress")
        self._lock_nav(True)
        self.set_status("Finding the way back…")
        self.runner.start(lambda emit, cancel: recover(req, emit, cancel, self.journal))

    def _recover_again(self) -> None:
        self.recovery_page.clear()
        self.go("recover")

    # ------------------------------------------------------------------ runner callbacks
    def _on_progress(self, info) -> None:
        page = self.bury_progress if self._op == "bury" else self.recover_progress
        page.update_progress(info)

    def _on_success(self, result) -> None:
        if self._op == "bury":
            self.bury_progress.show_bury_result(result)
            self.set_status(f"Buried “{result.original_name}”.")
            self.home.clear_source()
            self.bury_page.set_source(None)
        else:
            self._recover_values = None
            self.recover_progress.show_recover_result(result)
            self.set_status("You found your way back.")

    def _on_failure(self, title: str, message: str, cancelled: bool) -> None:
        if self._op == "recover" and title == DestinationExistsError.title and self._recover_values:
            # ask after the worker thread has finished (see _on_finished)
            self._pending_conflict = message
            return
        page = self.bury_progress if self._op == "bury" else self.recover_progress
        page.show_error(title, message, cancelled)
        self.set_status("Cancelled." if cancelled else title)
        if self._op == "recover":
            self._recover_values = None

    def _on_finished(self) -> None:
        self._lock_nav(False)
        msg = getattr(self, "_pending_conflict", None)
        if msg:
            self._pending_conflict = None
            self._ask_conflict(msg)

    def _ask_conflict(self, message: str) -> None:
        box = QMessageBox(self)
        box.setWindowTitle("Already exists")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText(message)
        box.setInformativeText("Keep both (the recovered copy gets a new name), or replace the existing file?")
        keep = box.addButton("Keep both", QMessageBox.ButtonRole.AcceptRole)
        replace = box.addButton("Replace", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton(QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(keep)
        box.exec()
        clicked = box.clickedButton()
        if clicked is keep:
            self.start_recover(CONFLICT_RENAME)
        elif clicked is replace:
            sure = QMessageBox.warning(self, "Replace existing file?",
                                       "The existing file will be permanently replaced. Continue?",
                                       QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                                       QMessageBox.StandardButton.Cancel)
            if sure == QMessageBox.StandardButton.Yes:
                self.start_recover(CONFLICT_OVERWRITE)
                return
            self._abandon_recover()
        else:
            self._abandon_recover()

    def _abandon_recover(self) -> None:
        self._recover_values = None
        self.recover_progress.show_error("Not restored", "Nothing was changed: the existing item was kept.", True)
        self.set_status("Ready")

    def _lock_nav(self, locked: bool) -> None:
        for key in ("home", "bury", "recover"):
            self.nav[key].setEnabled(not locked)

    def _settings_changed(self) -> None:
        self.bury_page._update_strength()
        out = self.bury_page.output.text()
        self.maze_page.set_context(Path(out) if out else None, self.settings.long_paths)

    # ------------------------------------------------------------------ startup / shutdown
    def check_interrupted(self) -> None:
        pending = self.journal.pending()
        if not pending:
            return
        paths = [p for e in pending for p in e["paths"]]
        answer = QMessageBox.question(
            self, "Interrupted operation found",
            "A previous operation did not finish (the app was closed or the computer lost power). "
            "It left incomplete output:\n\n" + "\n".join(paths[:6]) +
            "\n\nThis output cannot be recovered. Remove it now?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.Yes)
        if answer == QMessageBox.StandardButton.Yes:
            for entry in pending:
                self.journal.cleanup(entry)
            self.set_status("Incomplete output from an interrupted operation was removed.")

    def closeEvent(self, e):
        if self.runner.running:
            answer = QMessageBox.warning(
                self, "Operation in progress",
                "An operation is still running. Stop it and remove its incomplete output?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                e.ignore()
                return
            self.runner.cancel()
            self.runner.wait(30_000)
        self.settings_page.runner.cancel()
        self.settings_page.runner.wait(10_000)
        e.accept()


def run_app(argv: list[str]) -> int:
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication.instance() or QApplication([sys.argv[0], *argv])
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("LostWithin")
    app.setApplicationVersion(__version__)
    if sys.platform == "win32":
        try:  # own taskbar icon instead of python.exe's
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("LostWithin.SecureFileMaze")
        except Exception:
            pass
    app.setStyle("Fusion")
    app.setFont(S.app_font())
    app.setStyleSheet(S.stylesheet())
    win = MainWindow()
    win.show()
    # a path passed on the command line / "Open with" / dropped onto the .exe
    for arg in argv:
        p = Path(arg)
        if p.exists():
            win.route_path(p)
            break
    win.check_interrupted()
    return app.exec()
