"""Test mode: exercise the complete bury -> maze -> recovery workflow safely.

Everything happens inside a fresh temporary folder that is deleted afterwards.
Only small generated files are used, with fast (deliberately weak) Argon2id
settings and a 64 KiB chunk size so multi-chunk paths are covered in seconds.
Run with ``python main.py --self-test`` or from Settings in the app.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import tempfile
import time
from pathlib import Path
from typing import Callable

from core.burial import BuryRequest, bury
from core.errors import (DescriptorError, DestinationExistsError, IntegrityError, OperationCancelled,
                         WrongPasswordError)
from core.journal import Journal
from core.key_derivation import TEST_KDF
from core.maze import MazeConfig
from core.recovery import CONFLICT_RENAME, RecoverRequest, recover
from core.streaming import CancelToken

PASSWORD = "self-test passphrase 7 lanterns"
CHUNK = 64 * 1024
MAZE = MazeConfig(depth=5, name_length=6, branching=3, decoy_dirs=6, decoy_files=4)


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _tree_digest(root: Path) -> dict[str, str]:
    return {str(p.relative_to(root)).replace("\\", "/"): (_sha(p) if p.is_file() else "<dir>")
            for p in sorted(root.rglob("*"))}


def run_self_test(log: Callable[[str], None] = print) -> bool:
    work = Path(tempfile.mkdtemp(prefix="lostwithin-selftest-"))
    journal = Journal(work / "journal")
    results: list[tuple[str, bool, str]] = []

    def check(name: str, fn: Callable[[], str | None]) -> None:
        t = time.monotonic()
        try:
            detail = fn() or ""
            results.append((name, True, detail))
            log(f"  ✓ {name}  ({(time.monotonic() - t) * 1000:.0f} ms){'  — ' + detail if detail else ''}")
        except Exception as exc:  # noqa: BLE001 - report every failure
            results.append((name, False, f"{type(exc).__name__}: {exc}"))
            log(f"  ✗ {name}  — {type(exc).__name__}: {exc}")

    src, out, dest = work / "source", work / "maze-output", work / "restored"
    for p in (src, out, dest):
        p.mkdir()

    def do_bury(path: Path, **kw):
        return bury(BuryRequest(path, out, PASSWORD, maze=MAZE, kdf=TEST_KDF, chunk_size=CHUNK, **kw),
                    journal=journal)

    def do_recover(desc: Path, **kw):
        kw.setdefault("password", PASSWORD)
        return recover(RecoverRequest(desc, dest, **kw), journal=journal)

    def roundtrip(name: str, data: bytes, **kw) -> str:
        f = src / name
        f.write_bytes(data)
        b = do_bury(f, **kw)
        assert name not in str(b.payload_path), "original name leaked into the maze"
        r = do_recover(b.descriptor_path)
        assert r.output_path.name == name, "filename not restored"
        assert _sha(r.output_path) == _sha(f), "content mismatch"
        return f"{len(data):,} bytes, payload at depth {len(b.payload_path.relative_to(b.maze_root).parts) - 1}"

    log("Lost Within self-test")
    log(f"  working in {work}")
    try:
        check("Small file round trip", lambda: roundtrip("notes.txt", b"Enter. Disappear. Find your way back.\n"))
        check("Empty file round trip", lambda: roundtrip("empty.bin", b""))
        check("Multi-chunk file (5.2 chunks)", lambda: roundtrip("multi.bin", os.urandom(CHUNK * 5 + 13_337)))
        check("Exact chunk boundary (3 chunks)", lambda: roundtrip("exact.bin", os.urandom(CHUNK * 3)))
        check("Unicode filename", lambda: roundtrip("Ünïcødé — файл 文件.dat", os.urandom(1000)))

        def folder():
            f = src / "Project Folder"
            (f / "docs" / "deep" / "deeper").mkdir(parents=True)
            (f / "empty-dir").mkdir()
            (f / "readme.md").write_text("# hello\n", "utf-8")
            (f / "docs" / "data.bin").write_bytes(os.urandom(CHUNK * 2 + 5))
            (f / "docs" / "deep" / "deeper" / "ü.txt").write_text("deep", "utf-8")
            b = do_bury(f)
            r = do_recover(b.descriptor_path)
            assert _tree_digest(r.output_path) == _tree_digest(f), "folder contents differ"
            return f"{b.file_count} files restored"
        check("Folder round trip", folder)

        shared = src / "secret.pdf"
        shared.write_bytes(os.urandom(CHUNK * 2 + 99))
        b = do_bury(shared, create_recovery_key=True)
        desc_bytes = b.descriptor_path.read_bytes()

        def maze_hides_name():
            names = [p.name for p in b.maze_root.rglob("*")]
            assert all("secret" not in n for n in names), "original name visible in maze"
            assert b"secret.pdf" not in desc_bytes, "original name visible in descriptor"
            assert PASSWORD.encode() not in desc_bytes, "password stored in descriptor"
            return f"{len(names)} entries in maze, none reveal the name"
        check("Maze and descriptor reveal no name or password", maze_hides_name)

        def recovery_key():
            r = do_recover(b.descriptor_path, password=None, recovery_key=b.recovery_key, conflict=CONFLICT_RENAME)
            assert _sha(r.output_path) == _sha(shared)
        check("Recovery key unlocks independently", recovery_key)

        def expect(exc_type, fn):
            try:
                fn()
            except exc_type as exc:
                return str(exc)[:70]
            raise AssertionError(f"expected {exc_type.__name__}")

        check("Wrong password is rejected", lambda: expect(WrongPasswordError, lambda: do_recover(
            b.descriptor_path, password="not the password", verify_only=True)))

        def tampered_payload():
            orig = b.payload_path.read_bytes()
            try:
                bad = bytearray(orig)
                bad[HEADER_OFFSET + CHUNK + 40] ^= 0x01  # flip one bit in chunk 2
                b.payload_path.write_bytes(bad)
                return expect(IntegrityError, lambda: do_recover(b.descriptor_path, verify_only=True))
            finally:
                b.payload_path.write_bytes(orig)
        check("Modified ciphertext is detected", tampered_payload)

        def truncated_payload():
            orig = b.payload_path.read_bytes()
            try:
                b.payload_path.write_bytes(orig[:-500])
                return expect(IntegrityError, lambda: do_recover(b.descriptor_path, verify_only=True))
            finally:
                b.payload_path.write_bytes(orig)
        check("Truncated (incomplete) payload is detected", truncated_payload)

        def tampered_descriptor():
            try:
                b.descriptor_path.write_bytes(desc_bytes.replace(b'"decoy_files": 4', b'"decoy_files": 5'))
                return expect(DescriptorError, lambda: do_recover(b.descriptor_path, verify_only=True))
            finally:
                b.descriptor_path.write_bytes(desc_bytes)
        check("Modified descriptor is detected", tampered_descriptor)

        def no_overwrite():
            if not (dest / "secret.pdf").exists():
                do_recover(b.descriptor_path)  # first restore
            return expect(DestinationExistsError, lambda: do_recover(b.descriptor_path))
        check("Existing files are not overwritten", no_overwrite)

        def moved_maze():
            moved = work / "elsewhere"
            moved.mkdir()
            new_root = moved / "renamed-maze"
            shutil.move(str(b.maze_root), str(new_root))
            try:
                r = do_recover(b.descriptor_path, maze_root=new_root, verify_only=True)
                return "found via selected maze root" + (" (scan)" if r.notes else "")
            finally:
                shutil.move(str(new_root), str(b.maze_root))
        check("Maze moved to another folder", moved_maze)

        def cancelled():
            big = src / "cancel-me.bin"
            big.write_bytes(os.urandom(CHUNK * 40))
            token = CancelToken()
            before = set(os.listdir(out))

            def cb(info):
                if info.stage == "Encrypting":  # cancel as soon as encryption starts
                    token.cancel()
            try:
                bury(BuryRequest(big, out, PASSWORD, maze=MAZE, kdf=TEST_KDF, chunk_size=CHUNK),
                     progress=cb, cancel=token, journal=journal)
            except OperationCancelled:
                pass
            else:
                raise AssertionError("bury was not cancelled")
            assert set(os.listdir(out)) == before, "cancelled bury left files behind"
            assert not journal.pending(), "journal entry left behind"
            return "incomplete maze removed"
        check("Cancelled bury cleans up", cancelled)
    finally:
        shutil.rmtree(work, ignore_errors=True)

    passed = sum(ok for _, ok, _ in results)
    log(f"\n{passed}/{len(results)} checks passed. Temporary files removed.")
    return passed == len(results)


HEADER_OFFSET = 28  # payload header length


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(0 if run_self_test() else 1)
