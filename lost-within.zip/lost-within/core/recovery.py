"""Recover: find the way back through the maze and restore the original item.

1. Load and strictly validate the descriptor (no secrets needed).
2. Derive the key from the password (Argon2id) or recovery key, unwrap the DEK.
   A wrong password fails here, before any file is touched.
3. Open the sealed metadata (authenticates the whole descriptor).
4. Locate the maze root and the payload (with a traversal-safe path check and a
   fallback scan if folders were renamed).
5. Stream-decrypt into a hidden temporary file, authenticating every chunk and
   hashing ciphertext and plaintext along the way.
6. Compare both SHA-256 digests with the descriptor.
7. Only then move the result to its (sanitized) original name. Folders are
   extracted from the authenticated tar with Python's ``data`` extraction
   filter, which blocks absolute paths, ``..`` and links that escape.
"""

from __future__ import annotations

import os
import secrets
import stat
import tarfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from cryptography.exceptions import InvalidTag

from core.encryption import HEADER_LEN, aead_decrypt, decrypt_stream, open_json
from core.errors import (DescriptorError, DestinationExistsError, InsufficientSpaceError, IntegrityError,
                         LostWithinError, MazeNotFoundError, OperationCancelled, PayloadNotFoundError,
                         WrongPasswordError)
from core.hashing import HashingWriter, digests_match, new_hasher
from core.journal import Journal
from core.key_derivation import (derive_password_key, metadata_key, parse_recovery_key, payload_key,
                                 recovery_key_kek)
from core.streaming import IO_BUFFER, CancelToken, NullSink, ProgressCallback, ProgressTracker
from models.metadata import (KIND_DIR, KIND_FILE, MAX_DESCRIPTOR_BYTES, SLOT_PASSWORD, SLOT_RECOVERY, Descriptor,
                             SealedMetadata)
from utils.filesystem import (free_space, human_size, is_within, os_path, remove_quietly, rename_no_clobber,
                              unique_path)
from utils.validation import sanitize_filename

CONFLICT_ERROR, CONFLICT_OVERWRITE, CONFLICT_RENAME = "error", "overwrite", "rename"
MAX_SCAN_ENTRIES = 250_000


@dataclass
class RecoverRequest:
    descriptor_path: Path
    destination_dir: Optional[Path] = None
    password: Optional[str] = None
    recovery_key: Optional[str] = None
    maze_root: Optional[Path] = None
    conflict: str = CONFLICT_ERROR
    verify_only: bool = False

    def __repr__(self) -> str:
        return f"RecoverRequest(descriptor={self.descriptor_path!s}, secrets=<hidden>)"


@dataclass
class RecoverResult:
    original_name: str
    restored_name: str
    kind: str
    output_path: Optional[Path]
    original_size: int
    file_count: int
    plaintext_sha256: str
    payload_path: Path
    elapsed: float
    verify_only: bool
    renamed: bool = False
    notes: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- steps

def load_descriptor(path: Path) -> Descriptor:
    path = Path(path)
    try:
        size = path.stat().st_size
        if size > MAX_DESCRIPTOR_BYTES:
            raise DescriptorError("The selected file is too large to be a Lost Within descriptor.")
        data = path.read_bytes()
    except OSError as exc:
        raise DescriptorError(f"Cannot read the descriptor: {exc.strerror or exc}") from None
    return Descriptor.from_bytes(data)


def _slot_aad(typ: str, file_id: bytes) -> bytes:
    return b"lostwithin/v1/keyslot/" + typ.encode() + b"/" + file_id


def unlock(desc: Descriptor, *, password: Optional[str] = None,
           recovery_key: Optional[str] = None) -> tuple[bytes, SealedMetadata]:
    """Return (DEK, sealed metadata) or raise WrongPasswordError / DescriptorError."""
    file_id = desc.payload.file_id
    dek = None
    if recovery_key:
        try:
            raw = parse_recovery_key(recovery_key)
        except ValueError as exc:
            raise WrongPasswordError(str(exc)) from None
        slots = desc.slots(SLOT_RECOVERY)
        if not slots:
            raise WrongPasswordError("This burial was created without a recovery key. Use the password.")
        for slot in slots:
            try:
                dek = aead_decrypt(recovery_key_kek(raw, slot.salt), slot.nonce, slot.wrapped_key,
                                   _slot_aad(SLOT_RECOVERY, file_id))
                break
            except InvalidTag:
                continue
        if dek is None:
            raise WrongPasswordError("That recovery key does not unlock this descriptor.")
    elif password:
        for slot in desc.slots(SLOT_PASSWORD):
            kek = derive_password_key(password, slot.salt, slot.kdf)
            try:
                dek = aead_decrypt(kek, slot.nonce, slot.wrapped_key, _slot_aad(SLOT_PASSWORD, file_id))
                break
            except InvalidTag:
                continue
        if dek is None:
            raise WrongPasswordError("Wrong password. (Or the descriptor's key data was altered.)")
    else:
        raise WrongPasswordError("Enter the password or a recovery key.")
    try:
        sealed_obj = open_json(metadata_key(dek, file_id), desc.sealed_nonce, desc.sealed_ciphertext, desc.aad())
    except (InvalidTag, ValueError):
        raise DescriptorError("The descriptor has been modified or corrupted "
                              "(its header failed authentication).") from None
    return dek, SealedMetadata.from_dict(sealed_obj)


def candidate_maze_roots(desc: Descriptor, descriptor_path: Path, explicit: Optional[Path] = None,
                         hint: str = "") -> list[Path]:
    out: list[Path] = []
    if explicit:
        explicit = Path(explicit)
        # Accept either the maze root itself or the folder that contains it.
        out += [explicit / desc.maze.root_name, explicit]
    out.append(Path(descriptor_path).absolute().parent / desc.maze.root_name)
    if hint:
        out.append(Path(hint))
    return out


def find_maze_root_public(desc: Descriptor, descriptor_path: Path, explicit: Optional[Path] = None) -> Optional[Path]:
    """Best guess before unlocking (used by the UI to decide whether to ask for the maze)."""
    for c in candidate_maze_roots(desc, descriptor_path, explicit):
        if os.path.isdir(os_path(c)):
            return c
    return None


def _payload_matches(path: str, size: int, file_id: bytes) -> bool:
    try:
        st = os.lstat(path)
        if not stat.S_ISREG(st.st_mode) or st.st_size != size:
            return False
        with open(path, "rb") as fh:
            head = fh.read(HEADER_LEN)
        return head[5:21] == file_id
    except OSError:
        return False


def locate_payload(desc: Descriptor, sealed: SealedMetadata, descriptor_path: Path,
                   explicit_root: Optional[Path], cancel: CancelToken) -> tuple[Path, list[str]]:
    notes: list[str] = []
    roots = [r for r in candidate_maze_roots(desc, descriptor_path, explicit_root, sealed.maze_root_hint)
             if os.path.isdir(os_path(r))]
    if not roots:
        raise MazeNotFoundError(
            f"The maze folder '{desc.maze.root_name}' was not found next to the descriptor or at its "
            "original location. Select the maze root folder (or the folder containing it).")
    # 1. the recorded path
    for root in roots:
        candidate = root.joinpath(*sealed.maze_path, sealed.payload_name)
        if is_within(root, candidate) and _payload_matches(os_path(candidate), desc.payload.size,
                                                           desc.payload.file_id):
            return candidate, notes
    # 2. fallback: the maze was moved/renamed internally -> scan for the payload
    seen = 0
    for root in roots:
        for dirpath, dirnames, filenames in os.walk(os_path(root), followlinks=False):
            cancel.check()
            for name in filenames:
                seen += 1
                full = os.path.join(dirpath, name)
                if _payload_matches(full, desc.payload.size, desc.payload.file_id):
                    p = Path(full)
                    if is_within(root, p):
                        notes.append("The payload was not at its recorded path; it was found by scanning the maze.")
                        return p, notes
            if seen > MAX_SCAN_ENTRIES:
                break
    # 3. diagnose the most likely problem for the user
    root = roots[0]
    candidate = root.joinpath(*sealed.maze_path, sealed.payload_name)
    if os.path.exists(os_path(candidate)):
        actual = os.path.getsize(os_path(candidate))
        raise IntegrityError(
            f"The encrypted payload is {human_size(actual)} but should be {human_size(desc.payload.size)}. "
            "It is incomplete (e.g. an interrupted copy) or corrupted.")
    partial = candidate.with_name(candidate.name + ".partial")
    if os.path.exists(os_path(partial)):
        raise IntegrityError("Only a partial payload exists: the original burial was interrupted.")
    raise PayloadNotFoundError("The encrypted payload is missing from the maze. Folders may have been "
                               "deleted, or this is a different maze.")


# --------------------------------------------------------------------------- main entry

def recover(req: RecoverRequest, progress: Optional[ProgressCallback] = None,
            cancel: Optional[CancelToken] = None, journal: Optional[Journal] = None) -> RecoverResult:
    t0 = time.monotonic()
    cancel = cancel or CancelToken()
    tracker = ProgressTracker(progress, cancel=cancel)
    journal = journal or Journal()

    tracker.stage("Reading descriptor", detail="Validating metadata")
    desc = load_descriptor(req.descriptor_path)

    tracker.stage("Deriving key", detail=("Recovery key" if req.recovery_key else
                                          desc.slots(SLOT_PASSWORD)[0].kdf.description))
    dek, sealed = unlock(desc, password=req.password, recovery_key=req.recovery_key)
    cancel.check()

    tracker.stage("Locating payload", detail="Following the path through the maze")
    payload_path, notes = locate_payload(desc, sealed, req.descriptor_path, req.maze_root, cancel)

    restored_name = sanitize_filename(sealed.original_name)
    if restored_name != sealed.original_name:
        notes.append(f"The stored name was unsafe and was changed to '{restored_name}'.")

    dest_dir = None
    final_path = None
    if not req.verify_only:
        if req.destination_dir is None:
            raise LostWithinError("Choose a destination folder.")
        dest_dir = Path(req.destination_dir).absolute()
        if not dest_dir.is_dir():
            raise LostWithinError(f"The destination folder does not exist: {dest_dir}")
        final_path = dest_dir / restored_name
        if not is_within(dest_dir, final_path):  # defence in depth; sanitize already prevents this
            raise LostWithinError("Refusing to restore outside the destination folder.")
        if final_path.exists() or final_path.is_symlink():
            if req.conflict == CONFLICT_ERROR:
                raise DestinationExistsError(f"'{restored_name}' already exists in {dest_dir}.")
            if req.conflict == CONFLICT_OVERWRITE and (sealed.kind == KIND_DIR or final_path.is_dir()):
                raise DestinationExistsError("Existing folders are never overwritten. Choose 'keep both' instead.")
        needed = desc.payload.size * (2 if sealed.kind == KIND_DIR else 1) + 32 * 1024 * 1024
        if free_space(dest_dir) < needed:
            raise InsufficientSpaceError(f"About {human_size(needed)} is needed in {dest_dir}, "
                                         f"but only {human_size(free_space(dest_dir))} is free.")

    entry = journal.begin("recover")
    partial = extract_dir = None
    renamed = False
    try:
        # ---------------------------------------------------------- decrypt
        tracker.stage("Decrypting", total=desc.payload.size, detail="Authenticating every chunk")
        ct_hash = new_hasher()

        def on_ct(block: bytes) -> None:
            ct_hash.update(block)
            tracker.advance(len(block))

        if req.verify_only:
            out_raw = None
        else:
            partial = dest_dir / f".{secrets.token_hex(6)}.lw-partial"
            journal.add_path(entry, partial)
            out_raw = open(os_path(partial), "xb", buffering=IO_BUFFER)
        try:
            plain = HashingWriter(out_raw if out_raw is not None else NullSink())
            with open(os_path(payload_path), "rb", buffering=IO_BUFFER) as src:
                decrypt_stream(src, plain, payload_key(dek, desc.payload.file_id),
                               expected_file_id=desc.payload.file_id,
                               expected_chunk_size=desc.payload.chunk_size,
                               on_ciphertext=on_ct, cancel=cancel)
            if out_raw is not None:
                out_raw.flush()
                os.fsync(out_raw.fileno())
        finally:
            if out_raw is not None:
                out_raw.close()
        del dek
        tracker.finish_stage()

        # ---------------------------------------------------------- verify
        tracker.stage("Verifying", detail="Comparing SHA-256 digests")
        if not digests_match(ct_hash.hexdigest(), desc.payload.sha256):
            raise IntegrityError("The payload's SHA-256 does not match the descriptor.")
        if not digests_match(plain.hexdigest(), sealed.plaintext_sha256):
            raise IntegrityError("The recovered data's SHA-256 does not match the original.")
        if sealed.kind == KIND_FILE and plain.bytes_written != sealed.original_size:
            raise IntegrityError("The recovered file has the wrong size.")

        # ---------------------------------------------------------- restore
        if not req.verify_only:
            if sealed.kind == KIND_FILE:
                tracker.stage("Restoring", detail=restored_name)
                final_path, renamed = _place(partial, final_path, req.conflict, is_dir=False)
            else:
                extract_dir = dest_dir / f".{secrets.token_hex(6)}.lw-extract"
                journal.add_path(entry, extract_dir)
                os.mkdir(os_path(extract_dir))
                top = _extract_tar(partial, extract_dir, tracker, cancel)
                remove_quietly(partial)
                final_path, renamed = _place(extract_dir / top, final_path, req.conflict, is_dir=True)
                remove_quietly(extract_dir)
            tracker.finish_stage()
    except BaseException as exc:
        remove_quietly(partial)
        remove_quietly(extract_dir)
        journal.end(entry)
        if isinstance(exc, LostWithinError):
            raise
        if isinstance(exc, OSError):
            raise LostWithinError(f"File system error: {exc.strerror or exc}. Partial output was removed.") from exc
        raise
    journal.end(entry)
    if sealed.skipped:
        notes.append(f"{sealed.skipped} link(s)/special file(s) were skipped when this folder was buried.")
    return RecoverResult(
        original_name=sealed.original_name, restored_name=final_path.name if final_path else restored_name,
        kind=sealed.kind, output_path=final_path, original_size=sealed.original_size,
        file_count=sealed.file_count, plaintext_sha256=sealed.plaintext_sha256, payload_path=payload_path,
        elapsed=time.monotonic() - t0, verify_only=req.verify_only, renamed=renamed, notes=notes,
    )


def _place(src: Path, final: Path, conflict: str, *, is_dir: bool) -> tuple[Path, bool]:
    """Move the verified result into place according to the conflict policy."""
    if conflict == CONFLICT_OVERWRITE and not is_dir:
        os.replace(os_path(src), os_path(final))
        return final, False
    renamed = False
    for _ in range(100):
        target = final
        if conflict == CONFLICT_RENAME:
            target = unique_path(final)
            renamed = target != final
        try:
            rename_no_clobber(src, target)
            return target, renamed
        except FileExistsError:
            if conflict != CONFLICT_RENAME:
                raise DestinationExistsError(f"'{final.name}' appeared in the destination during recovery.") from None
        except IsADirectoryError:
            raise DestinationExistsError(f"'{final.name}' already exists in the destination.") from None
        except OSError as exc:
            # Windows/POSIX report "directory exists" as ENOTEMPTY/EEXIST for folders
            if os.path.exists(os_path(target)) and conflict != CONFLICT_RENAME:
                raise DestinationExistsError(f"'{final.name}' already exists in the destination.") from None
            if not os.path.exists(os_path(target)):
                raise exc
    raise DestinationExistsError("Could not find a free name in the destination folder.")


def _extract_tar(tar_path: Path, extract_dir: Path, tracker: ProgressTracker, cancel: CancelToken) -> str:
    """Extract an authenticated tar safely; return the single top-level name."""
    with tarfile.open(os_path(tar_path), mode="r:") as tar:
        members = tar.getmembers()
        tops = {m.name.replace("\\", "/").split("/", 1)[0] for m in members}
        if len(tops) != 1:
            raise IntegrityError("The folder archive has an unexpected layout.")
        top = tops.pop()
        tracker.stage("Restoring folder", total=len(members), detail=sanitize_filename(top))
        for i, m in enumerate(members, 1):
            cancel.check()
            # 'data' filter: rejects absolute paths, '..', links outside the
            # destination, device files; strips dangerous permission bits.
            tar.extract(m, os_path(extract_dir), filter="data")
            tracker.set_processed(i)
    if sanitize_filename(top) != top or not os.path.isdir(os_path(extract_dir / top)):
        raise IntegrityError("The folder archive has an unsafe top-level name.")
    return top
