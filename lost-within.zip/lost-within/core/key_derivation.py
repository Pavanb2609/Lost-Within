"""Key derivation: Argon2id for passwords, HKDF-SHA256 for subkeys, recovery keys.

Key hierarchy for one buried item::

    password ──Argon2id(salt)──► KEK_pw ─┐
                                         ├─ AES-GCM wrap ─► DEK (random 256-bit)
    recovery key ──HKDF(salt)──► KEK_rk ─┘                   │
                                                             ├─HKDF─► payload key  (encrypts the file)
                                                             └─HKDF─► metadata key (encrypts filename, maze path)

The DEK is random, so changing which secrets unlock it never requires
re-encrypting a 70 GB payload, and a recovery key can unlock independently of
the password.
"""

from __future__ import annotations

import base64
import hashlib
import os
import unicodedata
from dataclasses import dataclass

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from core.errors import DescriptorError

KEY_LEN = 32          # AES-256
SALT_LEN = 16
RECOVERY_KEY_PREFIX = "LW1"


@dataclass(frozen=True)
class Argon2Params:
    time_cost: int           # iterations
    memory_cost_kib: int     # memory in KiB
    parallelism: int         # lanes

    # Hard limits applied to values read from a descriptor, so a malicious file
    # cannot make the app allocate unbounded memory or spin forever.
    MIN_MEMORY = 8 * 1024
    MAX_MEMORY = 4 * 1024 * 1024
    MAX_TIME = 20
    MAX_PARALLELISM = 16

    def validate(self) -> "Argon2Params":
        ok = (
            1 <= self.time_cost <= self.MAX_TIME
            and 1 <= self.parallelism <= self.MAX_PARALLELISM
            and self.MIN_MEMORY <= self.memory_cost_kib <= self.MAX_MEMORY
            and self.memory_cost_kib >= 8 * self.parallelism
        )
        if not ok:
            raise DescriptorError("Argon2id parameters are outside the accepted range.")
        return self

    def to_dict(self) -> dict:
        return {"algorithm": "argon2id", "version": 19, "time_cost": self.time_cost,
                "memory_cost_kib": self.memory_cost_kib, "parallelism": self.parallelism}

    @property
    def description(self) -> str:
        mem = self.memory_cost_kib / 1024
        mem_s = f"{mem / 1024:g} GiB" if mem >= 1024 else f"{mem:g} MiB"
        return f"Argon2id · {mem_s} · {self.time_cost} passes · {self.parallelism} lanes"


KDF_PRESETS: dict[str, Argon2Params] = {
    # RFC 9106 §4 "second recommended option" (64 MiB, t=3, p=4).
    "standard": Argon2Params(time_cost=3, memory_cost_kib=64 * 1024, parallelism=4),
    "strong": Argon2Params(time_cost=4, memory_cost_kib=256 * 1024, parallelism=4),
    "maximum": Argon2Params(time_cost=4, memory_cost_kib=1024 * 1024, parallelism=4),
}
# Deliberately weak: used ONLY by the self-test and unit tests to keep them fast.
TEST_KDF = Argon2Params(time_cost=1, memory_cost_kib=8 * 1024, parallelism=1)


def _normalize_password(password: str) -> bytes:
    # NFC so the same visible password typed on different systems gives the same bytes.
    return unicodedata.normalize("NFC", password).encode("utf-8")


def argon2_backend() -> str:
    try:
        from cryptography.hazmat.primitives.kdf.argon2 import Argon2id  # noqa: F401
        return "cryptography (OpenSSL)"
    except ImportError:
        return "argon2-cffi"


def derive_password_key(password: str, salt: bytes, params: Argon2Params) -> bytes:
    """Derive a 256-bit key-encryption key from a password with Argon2id."""
    if not password:
        raise ValueError("Password must not be empty.")
    params.validate()
    secret = _normalize_password(password)
    try:
        from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
        from cryptography.exceptions import UnsupportedAlgorithm
        try:
            return Argon2id(salt=salt, length=KEY_LEN, iterations=params.time_cost,
                            lanes=params.parallelism, memory_cost=params.memory_cost_kib).derive(secret)
        except UnsupportedAlgorithm:
            pass
    except ImportError:
        pass
    # Fallback: the reference implementation via argon2-cffi (identical output).
    from argon2.low_level import Type, hash_secret_raw
    return hash_secret_raw(secret, salt, params.time_cost, params.memory_cost_kib,
                           params.parallelism, KEY_LEN, Type.ID)


def hkdf(ikm: bytes, salt: bytes, info: bytes, length: int = KEY_LEN) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=salt, info=info).derive(ikm)


def payload_key(dek: bytes, file_id: bytes) -> bytes:
    return hkdf(dek, file_id, b"lostwithin/v1/payload")


def metadata_key(dek: bytes, file_id: bytes) -> bytes:
    return hkdf(dek, file_id, b"lostwithin/v1/metadata")


def random_bytes(n: int) -> bytes:
    return os.urandom(n)


# --------------------------------------------------------------------------- recovery keys

def generate_recovery_key() -> bytes:
    return os.urandom(KEY_LEN)


def _rk_checksum(raw: bytes) -> bytes:
    return hashlib.sha256(b"lostwithin-recovery-key" + raw).digest()[:3]


def format_recovery_key(raw: bytes) -> str:
    """Encode 32 random bytes + a 3-byte checksum as 56 base32 characters in groups
    of four, e.g. ``LW1-ABCD-EFGH-…``. The checksum catches typos before any slow
    key derivation happens."""
    if len(raw) != KEY_LEN:
        raise ValueError("recovery key must be 32 bytes")
    text = base64.b32encode(raw + _rk_checksum(raw)).decode("ascii")  # 35 bytes -> 56 chars
    return RECOVERY_KEY_PREFIX + "-" + "-".join(text[i:i + 4] for i in range(0, len(text), 4))


def parse_recovery_key(text: str) -> bytes:
    """Parse a recovery key typed or pasted by the user (tolerant of spacing,
    case and the look-alike characters 0/O, 1/I, 8/B)."""
    s = "".join(ch for ch in text.upper() if ch.isalnum())
    if s.startswith(RECOVERY_KEY_PREFIX) and len(s) == 59:
        s = s[len(RECOVERY_KEY_PREFIX):]
    s = s.translate(str.maketrans({"0": "O", "1": "I", "8": "B"}))
    if len(s) != 56:
        raise ValueError("A recovery key has 56 characters after the LW1 prefix.")
    try:
        data = base64.b32decode(s)
    except Exception:
        raise ValueError("The recovery key contains invalid characters.") from None
    raw, check = data[:KEY_LEN], data[KEY_LEN:]
    if _rk_checksum(raw) != check:
        raise ValueError("The recovery key has a typo (checksum mismatch).")
    return raw


def recovery_key_kek(raw: bytes, salt: bytes) -> bytes:
    # The recovery key already has 256 bits of entropy, so a slow KDF adds nothing.
    return hkdf(raw, salt, b"lostwithin/v1/recovery-key-slot")
