"""Lost Within core engine: encryption, key derivation, maze generation and recovery.

Nothing in this package imports Qt, so it can be used (and tested) headless.
"""

APP_NAME = "Lost Within"
__version__ = "1.0.0"
