"""SHA-256 integrity helpers (streaming). MD5/SHA-1 are never used."""

from __future__ import annotations

import hashlib
import hmac
from typing import BinaryIO, Callable, Optional

from core.streaming import CancelToken, IO_BUFFER


def new_hasher():
    return hashlib.sha256()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path, *, chunk_size: int = IO_BUFFER, cancel: Optional[CancelToken] = None,
                on_bytes: Optional[Callable[[int], None]] = None) -> str:
    """Hash a file of any size without loading it into memory."""
    h = hashlib.sha256()
    buf = bytearray(chunk_size)
    view = memoryview(buf)
    with open(path, "rb", buffering=0) as fh:
        while True:
            if cancel is not None:
                cancel.check()
            n = fh.readinto(buf)
            if not n:
                break
            h.update(view[:n])
            if on_bytes is not None:
                on_bytes(n)
    return h.hexdigest()


def digests_match(a: str, b: str) -> bool:
    """Constant-time comparison of two hex digests."""
    return hmac.compare_digest(a.encode("ascii"), b.encode("ascii"))


class HashingWriter:
    """Pass-through writer that SHA-256 hashes and counts everything written."""

    def __init__(self, raw: BinaryIO | None):
        self._raw = raw
        self._h = hashlib.sha256()
        self.bytes_written = 0

    def write(self, data) -> int:
        self._h.update(data)
        n = len(data)
        self.bytes_written += n
        if self._raw is not None:
            self._raw.write(data)
        return n

    def flush(self) -> None:
        if self._raw is not None:
            self._raw.flush()

    def hexdigest(self) -> str:
        return self._h.hexdigest()
