"""Crash journal for interrupted operations.

Before an operation creates anything on disk it records what it is about to
create in a small JSON file under the app-data folder. A successful operation
deletes its entry. If the app crashes, loses power or is killed mid-way, the
entry survives and the next launch offers to remove the incomplete maze or
partial output.

The journal stores paths only (no names of buried files, no secrets). The maze
root path is recorded, which reveals where a maze is on this computer; the
journal entry is deleted as soon as the operation finishes.
"""

from __future__ import annotations

import json
import os
import secrets
import sys
import time
from pathlib import Path

from utils.filesystem import atomic_write_bytes, remove_quietly


def app_data_dir() -> Path:
    override = os.environ.get("LOSTWITHIN_HOME")
    if override:
        base = Path(override)
    elif sys.platform == "win32":
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / "LostWithin"
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "LostWithin"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "lost-within"
    base.mkdir(parents=True, exist_ok=True)
    return base


class Journal:
    def __init__(self, base: Path | None = None):
        self.dir = Path(base) if base else app_data_dir() / "journal"
        self.dir.mkdir(parents=True, exist_ok=True)

    def _path(self, entry_id: str) -> Path:
        return self.dir / f"{entry_id}.json"

    def begin(self, op: str, *, descriptor: Path | None = None, file_id: str = "") -> str:
        entry_id = f"{int(time.time())}-{secrets.token_hex(4)}"
        self._write(entry_id, {"id": entry_id, "op": op, "started": time.time(), "paths": [],
                               "descriptor": str(descriptor) if descriptor else "", "file_id": file_id})
        return entry_id

    def add_path(self, entry_id: str, path: Path) -> None:
        entry = self._read(self._path(entry_id))
        if entry is None:
            return
        entry["paths"].append(str(path))
        self._write(entry_id, entry)

    def end(self, entry_id: str) -> None:
        try:
            self._path(entry_id).unlink()
        except OSError:
            pass

    def _write(self, entry_id: str, entry: dict) -> None:
        atomic_write_bytes(self._path(entry_id), json.dumps(entry, indent=1).encode("utf-8"), overwrite=True)

    @staticmethod
    def _read(path: Path) -> dict | None:
        try:
            entry = json.loads(path.read_text("utf-8"))
            if isinstance(entry, dict) and isinstance(entry.get("paths"), list) and "id" in entry:
                return entry
        except (OSError, ValueError):
            pass
        return None

    def pending(self) -> list[dict]:
        """Entries left behind by interrupted operations whose output still exists."""
        out = []
        for p in sorted(self.dir.glob("*.json")):
            entry = self._read(p)
            if entry is None:
                continue
            if self._completed(entry) or not any(os.path.lexists(x) for x in entry["paths"]):
                self.end(entry["id"])  # nothing to clean
                continue
            out.append(entry)
        return out

    @staticmethod
    def _completed(entry: dict) -> bool:
        """A bury that wrote its descriptor succeeded even if the journal wasn't cleared."""
        if entry.get("op") != "bury" or not entry.get("descriptor") or not entry.get("file_id"):
            return False
        try:
            from models.metadata import Descriptor
            desc = Descriptor.from_bytes(Path(entry["descriptor"]).read_bytes())
            return desc.payload.file_id.hex() == entry["file_id"]
        except Exception:
            return False

    def cleanup(self, entry: dict) -> list[str]:
        """Remove what an interrupted operation left behind. Returns removed paths."""
        removed = []
        if not self._completed(entry):
            for p in entry["paths"]:
                if os.path.lexists(p):
                    remove_quietly(Path(p))
                    removed.append(p)
        self.end(entry["id"])
        return removed
