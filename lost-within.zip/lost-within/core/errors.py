"""Exception hierarchy. Every message is written to be shown to the user as-is.

No exception message ever contains a password, key or recovery key.
"""


class LostWithinError(Exception):
    """Base class for all expected, user-facing failures."""

    title = "Operation failed"


class DescriptorError(LostWithinError):
    title = "Invalid recovery descriptor"


class WrongPasswordError(LostWithinError):
    title = "Wrong password"


class IntegrityError(LostWithinError):
    title = "Integrity check failed"


class MazeConfigError(LostWithinError):
    title = "Invalid maze configuration"


class MazeNotFoundError(LostWithinError):
    title = "Maze not found"


class PayloadNotFoundError(LostWithinError):
    title = "Encrypted payload not found"


class DestinationExistsError(LostWithinError):
    title = "Destination already exists"


class InsufficientSpaceError(LostWithinError):
    title = "Not enough disk space"


class SourceError(LostWithinError):
    title = "Cannot read source"


class OperationCancelled(LostWithinError):
    title = "Cancelled"

    def __init__(self, message: str = "The operation was cancelled. Incomplete output was removed."):
        super().__init__(message)
