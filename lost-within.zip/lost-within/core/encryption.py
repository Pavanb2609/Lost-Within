"""Streaming authenticated encryption (AES-256-GCM in a chunked "STREAM" layout).

AES-GCM itself comes from the ``cryptography`` library; this module only frames
it so arbitrarily large files can be processed chunk by chunk. The layout follows
the well-studied STREAM construction (Hoang, Reyhanitabar, Rogaway, Vizár 2015,
also used by Tink and age):

Payload file::

    header (28 bytes) = version:u8 | chunk_size:u32be | file_id[16] | nonce_prefix[7]
    chunk 0           = AES-GCM(key, nonce_0, plaintext[0:cs],  aad=header)  -> cs + 16 bytes
    chunk 1           = ...
    chunk n (last)    = AES-GCM(key, nonce_n, remaining bytes,   aad=header)  -> <= cs + 16 bytes

    nonce_i = nonce_prefix[7] | i:u32be | last_flag:u8   (12 bytes)

Why this detects every failure the spec asks for:

* wrong key            -> first chunk fails authentication
* modified ciphertext  -> that chunk's GCM tag fails
* reordered / dropped chunks -> the counter is part of the nonce, so tags fail
* truncation           -> the remaining last chunk was not encrypted with
                          last_flag=1, so it fails; no data at all also fails
* appended data        -> the real last chunk fails as a non-final chunk
* header tampering     -> the header is authenticated as AAD of every chunk

Each payload uses a fresh random key (derived from a random DEK and a random
file_id), so nonces can never repeat under the same key.
"""

from __future__ import annotations

import json
import os
import struct
from dataclasses import dataclass
from typing import BinaryIO, Callable, Optional

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from core.errors import IntegrityError
from core.streaming import CancelToken, read_exact

CIPHER_NAME = "AES-256-GCM-STREAM"
PAYLOAD_VERSION = 1
TAG_LEN = 16
NONCE_LEN = 12
NONCE_PREFIX_LEN = 7
FILE_ID_LEN = 16
MIN_CHUNK_SIZE = 64 * 1024
MAX_CHUNK_SIZE = 64 * 1024 * 1024
MAX_CHUNKS = 2 ** 32
_HEADER = struct.Struct(">BI16s7s")
HEADER_LEN = _HEADER.size  # 28


def valid_chunk_size(cs: int) -> bool:
    return MIN_CHUNK_SIZE <= cs <= MAX_CHUNK_SIZE and cs & (cs - 1) == 0


def ciphertext_size(plaintext_size: int, chunk_size: int) -> int:
    """Exact payload size for a given plaintext size."""
    full, rest = divmod(plaintext_size, chunk_size)
    # A trailing partial (or empty) final chunk always exists unless the data ends
    # exactly on a chunk boundary, in which case the last full chunk is final.
    chunks = full + (1 if rest or full == 0 else 0)
    return HEADER_LEN + plaintext_size + chunks * TAG_LEN


@dataclass(frozen=True)
class PayloadHeader:
    version: int
    chunk_size: int
    file_id: bytes
    nonce_prefix: bytes

    def pack(self) -> bytes:
        return _HEADER.pack(self.version, self.chunk_size, self.file_id, self.nonce_prefix)

    @classmethod
    def unpack(cls, data: bytes) -> "PayloadHeader":
        if len(data) != HEADER_LEN:
            raise IntegrityError("The payload is incomplete: its header is truncated.")
        version, cs, file_id, prefix = _HEADER.unpack(data)
        if version != PAYLOAD_VERSION:
            raise IntegrityError(f"Unsupported payload version {version}, or the payload is corrupted.")
        if not valid_chunk_size(cs):
            raise IntegrityError("The payload header is corrupted (invalid chunk size).")
        return cls(version, cs, file_id, prefix)


def _nonce(prefix: bytes, counter: int, final: bool) -> bytes:
    return prefix + counter.to_bytes(4, "big") + (b"\x01" if final else b"\x00")


class StreamEncryptor:
    """A write-only file-like object: plaintext in, encrypted payload out.

    Holds at most one chunk of plaintext in memory. Call :meth:`close` to emit the
    final (authenticated-as-last) chunk; without it the payload is detectably
    incomplete.
    """

    def __init__(self, out: BinaryIO, key: bytes, file_id: bytes, chunk_size: int,
                 nonce_prefix: Optional[bytes] = None):
        if len(key) != 32:
            raise ValueError("AES-256 requires a 32-byte key")
        if len(file_id) != FILE_ID_LEN:
            raise ValueError("file_id must be 16 bytes")
        if not valid_chunk_size(chunk_size):
            raise ValueError("invalid chunk size")
        self._out = out
        self._aead = AESGCM(key)
        self.header = PayloadHeader(PAYLOAD_VERSION, chunk_size, file_id,
                                    nonce_prefix or os.urandom(NONCE_PREFIX_LEN))
        self._aad = self.header.pack()
        self._cs = chunk_size
        self._buf = bytearray()
        self._counter = 0
        self._closed = False
        out.write(self._aad)

    def write(self, data) -> int:
        if self._closed:
            raise ValueError("write to closed StreamEncryptor")
        self._buf += data
        cs = self._cs
        # Strictly greater: keep the last full chunk buffered until we know
        # whether more data follows (it must be marked final if not).
        if len(self._buf) > cs:
            mv = memoryview(self._buf)
            offset = 0
            while len(self._buf) - offset > cs:
                self._emit(mv[offset:offset + cs], final=False)
                offset += cs
            mv.release()
            del self._buf[:offset]
        return len(data)

    def flush(self) -> None:  # file-like API (tarfile may call it)
        pass

    def _emit(self, chunk, final: bool) -> None:
        if self._counter >= MAX_CHUNKS:
            raise OverflowError("payload too large for this chunk size")
        nonce = _nonce(self.header.nonce_prefix, self._counter, final)
        self._out.write(self._aead.encrypt(nonce, bytes(chunk), self._aad))
        self._counter += 1

    def close(self) -> None:
        if not self._closed:
            self._emit(bytes(self._buf), final=True)
            self._buf = bytearray()
            self._closed = True

    @property
    def chunks_written(self) -> int:
        return self._counter


def decrypt_stream(src: BinaryIO, sink, key: bytes, *, expected_file_id: bytes,
                   expected_chunk_size: int,
                   on_ciphertext: Optional[Callable[[bytes], None]] = None,
                   cancel: Optional[CancelToken] = None) -> int:
    """Decrypt and authenticate a payload from ``src`` into ``sink``.

    Every chunk is authenticated before it is written. Returns the number of
    plaintext bytes produced. Raises :class:`IntegrityError` on any tampering,
    corruption or truncation. Callers must still treat output as untrusted until
    this function returns (a truncated stream is only detected at the end), which
    is why recovery writes to a temporary file and renames it afterwards.
    """
    header_bytes = read_exact(src, HEADER_LEN)
    header = PayloadHeader.unpack(header_bytes)
    if header.file_id != expected_file_id:
        raise IntegrityError("This payload belongs to a different burial (file ID mismatch).")
    if header.chunk_size != expected_chunk_size:
        raise IntegrityError("The payload header does not match the descriptor (chunk size).")
    if on_ciphertext:
        on_ciphertext(header_bytes)

    aead = AESGCM(key)
    ct_len = header.chunk_size + TAG_LEN
    current = read_exact(src, ct_len)
    if not current:
        raise IntegrityError("The payload is incomplete: it contains no encrypted data.")
    counter = 0
    total = 0
    while True:
        if cancel is not None:
            cancel.check()
        nxt = read_exact(src, ct_len) if len(current) == ct_len else b""
        final = not nxt
        if len(current) < TAG_LEN:
            raise IntegrityError("The payload is incomplete: the last chunk is truncated.")
        try:
            plain = aead.decrypt(_nonce(header.nonce_prefix, counter, final), current, header_bytes)
        except InvalidTag:
            if counter == 0 and not final:
                raise IntegrityError(
                    "The first chunk failed authentication. Either the payload was modified "
                    "or it does not match this descriptor.") from None
            if final:
                raise IntegrityError(
                    f"Chunk {counter + 1} failed authentication. The payload is incomplete "
                    "(truncated), was modified, or is corrupted.") from None
            raise IntegrityError(
                f"Chunk {counter + 1} failed authentication: the payload was modified or is corrupted.") from None
        if on_ciphertext:
            on_ciphertext(current)
        sink.write(plain)
        total += len(plain)
        counter += 1
        if final:
            return total
        current = nxt


# --------------------------------------------------------------------------- small AEAD helpers

def aead_encrypt(key: bytes, plaintext: bytes, aad: bytes) -> tuple[bytes, bytes]:
    nonce = os.urandom(NONCE_LEN)
    return nonce, AESGCM(key).encrypt(nonce, plaintext, aad)


def aead_decrypt(key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
    """Raises cryptography.exceptions.InvalidTag on failure."""
    return AESGCM(key).decrypt(nonce, ciphertext, aad)


def seal_json(key: bytes, obj: dict, aad: bytes) -> tuple[bytes, bytes]:
    data = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return aead_encrypt(key, data, aad)


def open_json(key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> dict:
    data = aead_decrypt(key, nonce, ciphertext, aad)
    obj = json.loads(data.decode("utf-8"))
    if not isinstance(obj, dict):
        raise ValueError("sealed metadata is not an object")
    return obj
