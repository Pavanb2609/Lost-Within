"""Chunked I/O primitives, cancellation and progress reporting.

Nothing here ever holds more than a couple of chunks in memory, which is what
lets Lost Within process files far larger than RAM (70 GB+).
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import BinaryIO, Callable, Optional

from core.errors import OperationCancelled

MiB = 1024 * 1024
DEFAULT_CHUNK_SIZE = 4 * MiB
IO_BUFFER = 1 * MiB


class CancelToken:
    """Thread-safe cancellation flag checked between chunks."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def check(self) -> None:
        if self._event.is_set():
            raise OperationCancelled()


@dataclass(frozen=True)
class ProgressInfo:
    stage: str              # e.g. "Encrypting"
    processed: int          # bytes (or items) done in this stage
    total: int              # 0 = indeterminate
    speed: float            # bytes per second (smoothed)
    eta: Optional[float]    # seconds remaining, None if unknown
    detail: str = ""        # current operation, human readable
    elapsed: float = 0.0    # seconds since the stage started

    @property
    def fraction(self) -> float:
        if self.total <= 0:
            return 0.0
        return max(0.0, min(1.0, self.processed / self.total))


ProgressCallback = Callable[[ProgressInfo], None]


class ProgressTracker:
    """Turns byte counts into throttled ProgressInfo events with speed and ETA.

    Speed is measured over a sliding 3-second window so it reacts to slowdowns
    (e.g. a USB drive's cache filling up) without jittering every update.
    """

    WINDOW = 3.0

    def __init__(self, callback: ProgressCallback | None, min_interval: float = 0.1,
                 cancel: CancelToken | None = None) -> None:
        self._cb = callback
        self._min_interval = min_interval
        self._cancel = cancel
        self.stage_name = ""
        self.detail = ""
        self.total = 0
        self.processed = 0
        self._t0 = time.monotonic()
        self._last_emit = 0.0
        self._samples: deque[tuple[float, int]] = deque()

    def stage(self, name: str, total: int = 0, detail: str = "") -> None:
        self.stage_name, self.total, self.detail = name, max(0, int(total)), detail
        self.processed = 0
        self._t0 = time.monotonic()
        self._samples.clear()
        self._samples.append((self._t0, 0))
        self._emit(force=True)

    def set_detail(self, detail: str) -> None:
        self.detail = detail
        self._emit(force=True)

    def advance(self, n: int) -> None:
        if self._cancel is not None:
            self._cancel.check()
        self.processed += n
        self._emit()

    def set_processed(self, n: int, force: bool = False) -> None:
        self.processed = n
        self._emit(force=force)

    def finish_stage(self) -> None:
        if self.total:
            self.processed = max(self.processed, self.total)
        self._emit(force=True)

    def _emit(self, force: bool = False) -> None:
        if self._cb is None:
            return
        now = time.monotonic()
        if not force and now - self._last_emit < self._min_interval:
            return
        self._last_emit = now
        self._samples.append((now, self.processed))
        while len(self._samples) > 2 and now - self._samples[0][0] > self.WINDOW:
            self._samples.popleft()
        t_old, p_old = self._samples[0]
        dt = now - t_old
        speed = (self.processed - p_old) / dt if dt > 0.05 else 0.0
        eta = None
        if self.total and speed > 0:
            eta = max(0.0, (self.total - self.processed) / speed)
        processed = min(self.processed, self.total) if self.total else self.processed
        self._cb(ProgressInfo(self.stage_name, processed, self.total, speed, eta,
                              self.detail, now - self._t0))


def read_exact(f: BinaryIO, n: int) -> bytes:
    """Read up to ``n`` bytes, looping over short reads. Returns < n only at EOF."""
    chunks = []
    remaining = n
    while remaining > 0:
        block = f.read(remaining)
        if not block:
            break
        chunks.append(block)
        remaining -= len(block)
    return b"".join(chunks)


class NullSink:
    """A writer that discards data (used for verify-only recovery)."""

    def write(self, data) -> int:
        return len(data)

    def flush(self) -> None:
        pass
