"""Maze generation: a randomized directory tree that hides where the payload is.

IMPORTANT: the maze is obfuscation, not security. Anyone with access to the
disk can list every file in it; the payload is usually the largest file. All
confidentiality comes from the encryption. The maze only makes casual browsing
uninformative and keeps the original name and location out of sight.

Shape for depth D and branching B::

    root/
      level 1:  B folders, one of them on the true path
      level 2:  B folders under the true one ...
      ...
      level D:  the payload sits in the deepest folder of the true path

Every false sibling continues as a dead-end chain of random length (up to the
full depth), so the true path's depth does not stand out. Extra decoy chains
branch from random folders, and optional decoy files of random bytes sit at
dead ends. All names come from the OS CSPRNG.
"""

from __future__ import annotations

import os
import secrets
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from core.errors import MazeConfigError
from core.streaming import CancelToken
from utils.filesystem import LONG_PATH_LIMIT, SAFE_PATH_LIMIT, os_path
from utils.random_names import name_entropy_bits, random_name, random_unique_name

PAYLOAD_EXT = ".dat"
PARTIAL_SUFFIX = ".partial"
ROOT_PREFIX = "LostWithin_"
ROOT_RANDOM_LEN = 8
MAX_TOTAL_DIRS = 20_000
DECOY_FILE_MIN = 4 * 1024
DECOY_FILE_MAX = 96 * 1024

# (min, max) for each setting. Also used to validate descriptors.
LIMITS = {
    "depth": (1, 64),
    "name_length": (4, 32),
    "branching": (1, 8),
    "decoy_dirs": (0, 1000),
    "decoy_files": (0, 500),
}


@dataclass(frozen=True)
class MazeConfig:
    depth: int = 8
    name_length: int = 8
    branching: int = 3
    decoy_dirs: int = 24
    decoy_files: int = 12

    def to_dict(self) -> dict:
        return dict(self.__dict__)

    @classmethod
    def from_dict(cls, d: dict) -> "MazeConfig":
        base = cls()
        vals = {}
        for k in LIMITS:
            v = d.get(k, getattr(base, k))
            vals[k] = int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else getattr(base, k)
        return cls(**vals)


@dataclass
class MazeCheck:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    estimated_dirs: int = 0
    longest_path: int = 0
    path_limit: int = SAFE_PATH_LIMIT
    name_entropy: float = 0.0

    @property
    def ok(self) -> bool:
        return not self.errors


@dataclass
class MazePlan:
    root_name: str
    directories: list[tuple[str, ...]]          # parents before children
    true_path: tuple[str, ...]
    payload_name: str
    decoy_files: list[tuple[tuple[str, ...], str, int]]  # (dir, name, size)

    @property
    def payload_relpath(self) -> tuple[str, ...]:
        return self.true_path + (self.payload_name,)


def default_root_name() -> str:
    return ROOT_PREFIX + random_name(ROOT_RANDOM_LEN)


def estimate_directories(cfg: MazeConfig) -> int:
    d, b = cfg.depth, cfg.branching
    level_nodes = d * b
    dead_end_chains = (b - 1) * d * (d - 1) // 4      # mean chain length (D-L-1)/2
    decoys = cfg.decoy_dirs * max(1, (max(1, d // 2) + 1) // 2 + 1)
    return level_nodes + dead_end_chains + decoys


def check_config(cfg: MazeConfig, base_dir: Path | None, *, long_paths: bool = False,
                 root_name_len: int = len(ROOT_PREFIX) + ROOT_RANDOM_LEN) -> MazeCheck:
    """Validate a configuration before anything touches the disk."""
    chk = MazeCheck(path_limit=LONG_PATH_LIMIT if long_paths else SAFE_PATH_LIMIT)
    for key, (lo, hi) in LIMITS.items():
        value = getattr(cfg, key)
        if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
            chk.errors.append(f"{key.replace('_', ' ').capitalize()} must be between {lo} and {hi}.")
    if chk.errors:
        return chk

    chk.estimated_dirs = estimate_directories(cfg)
    chk.name_entropy = name_entropy_bits(cfg.name_length)
    base_len = len(str(Path(base_dir).absolute())) if base_dir else 40
    payload_len = cfg.name_length + len(PAYLOAD_EXT) + len(PARTIAL_SUFFIX)
    chk.longest_path = base_len + 1 + root_name_len + cfg.depth * (cfg.name_length + 1) + 1 + payload_len

    if chk.longest_path > chk.path_limit:
        hint = "" if long_paths else " Reduce depth or name length, pick a shorter output folder, or enable long-path mode in Settings."
        chk.errors.append(f"The deepest path would be {chk.longest_path} characters; the limit is "
                          f"{chk.path_limit}.{hint}")
    if chk.estimated_dirs > MAX_TOTAL_DIRS:
        chk.errors.append(f"This maze would create about {chk.estimated_dirs:,} folders "
                          f"(limit {MAX_TOTAL_DIRS:,}). Lower the depth, branching or decoys.")
    if cfg.branching == 1 and cfg.decoy_dirs == 0:
        chk.warnings.append("With branching 1 and no decoys the maze is a single straight path.")
    if cfg.decoy_files == 0:
        chk.warnings.append("Without decoy files the payload is the only file in the maze.")
    if chk.estimated_dirs > 5000:
        chk.warnings.append("Large mazes are slow to create, copy and delete.")
    if long_paths and chk.longest_path > SAFE_PATH_LIMIT:
        chk.warnings.append("Paths exceed 240 characters. Some Windows tools (Explorer, zip, backup "
                            "software) may fail to copy or delete this maze.")
    return chk


def plan_maze(cfg: MazeConfig, root_name: Optional[str] = None) -> MazePlan:
    """Generate the maze layout in memory (no disk access)."""
    root_name = root_name or default_root_name()
    taken: dict[tuple[str, ...], set[str]] = defaultdict(set)
    children: dict[tuple[str, ...], int] = defaultdict(int)
    directories: list[tuple[str, ...]] = []

    def add_child(parent: tuple[str, ...]) -> tuple[str, ...]:
        node = parent + (random_unique_name(cfg.name_length, taken[parent]),)
        directories.append(node)
        children[parent] += 1
        return node

    def chain(start: tuple[str, ...], length: int) -> None:
        node = start
        for _ in range(length):
            node = add_child(node)

    current: tuple[str, ...] = ()
    for level in range(cfg.depth):
        real = secrets.randbelow(cfg.branching)
        nodes = [add_child(current) for _ in range(cfg.branching)]
        for i, node in enumerate(nodes):
            if i != real:
                # dead end that may reach the same depth as the real path
                chain(node, secrets.randbelow(cfg.depth - level))
        current = nodes[real]
    true_path = current

    shallow: list[tuple[str, ...]] = [()] + [d for d in directories if len(d) < cfg.depth]
    for _ in range(cfg.decoy_dirs):
        parent = shallow[secrets.randbelow(len(shallow))]
        start = len(directories)
        chain(parent, 1 + secrets.randbelow(cfg.depth - len(parent)))
        shallow.extend(d for d in directories[start:] if len(d) < cfg.depth)

    # payload name must not collide with a folder inside the deepest directory
    payload_name = random_unique_name(cfg.name_length, taken[true_path]) + PAYLOAD_EXT

    decoys: list[tuple[tuple[str, ...], str, int]] = []
    if cfg.decoy_files:
        leaves = [d for d in directories if children[d] == 0 and d != true_path] or list(directories)
        for _ in range(cfg.decoy_files):
            folder = leaves[secrets.randbelow(len(leaves))]
            name = random_unique_name(cfg.name_length, taken[folder]) + PAYLOAD_EXT
            size = DECOY_FILE_MIN + secrets.randbelow(DECOY_FILE_MAX - DECOY_FILE_MIN)
            decoys.append((folder, name, size))

    return MazePlan(root_name, directories, true_path, payload_name, decoys)


def build_maze(plan: MazePlan, base_dir: Path, *, cancel: Optional[CancelToken] = None,
               on_progress: Optional[Callable[[int, int], None]] = None) -> Path:
    """Create the planned maze under ``base_dir``. The root must not already exist.

    On failure the caller removes the root (see core.burial); this function only
    creates things.
    """
    root = Path(base_dir) / plan.root_name
    os.mkdir(os_path(root))  # raises FileExistsError if present: never reuse a folder
    total = len(plan.directories) + len(plan.decoy_files)
    done = 0
    for rel in plan.directories:
        if cancel is not None:
            cancel.check()
        os.mkdir(os_path(root.joinpath(*rel)))
        done += 1
        if on_progress and done % 50 == 0:
            on_progress(done, total)
    for folder, name, size in plan.decoy_files:
        if cancel is not None:
            cancel.check()
        with open(os_path(root.joinpath(*folder, name)), "xb") as fh:
            fh.write(os.urandom(size))  # indistinguishable from ciphertext
        done += 1
    if on_progress:
        on_progress(total, total)
    return root
