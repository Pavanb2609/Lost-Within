"""Bury: encrypt a file or folder into a new maze and write its recovery descriptor.

Order of operations (each step can fail; everything created is rolled back):

1. Validate the source, output folder, maze configuration and free space.
2. Generate a random data key (DEK) and file ID; derive the password KEK
   with Argon2id; wrap the DEK (and optionally under a recovery key).
3. Journal the operation, then create the maze folders and decoy files.
4. Stream the source (folders as an on-the-fly tar) through SHA-256 and the
   chunked AES-256-GCM encryptor into ``<payload>.partial``; fsync; rename.
5. Seal the original name, hashes and maze path; write the descriptor
   atomically. Writing the descriptor is the commit point.
"""

from __future__ import annotations

import os
import stat
import tarfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from core.encryption import CIPHER_NAME, FILE_ID_LEN, StreamEncryptor, aead_encrypt, ciphertext_size, seal_json, valid_chunk_size
from core.errors import (DestinationExistsError, InsufficientSpaceError, LostWithinError, MazeConfigError,
                         OperationCancelled, SourceError)
from core.hashing import HashingWriter, new_hasher
from core.journal import Journal
from core.key_derivation import (KDF_PRESETS, SALT_LEN, Argon2Params, derive_password_key, format_recovery_key,
                                 generate_recovery_key, metadata_key, payload_key, random_bytes, recovery_key_kek)
from core.maze import PARTIAL_SUFFIX, MazeConfig, build_maze, check_config, plan_maze
from core.streaming import DEFAULT_CHUNK_SIZE, IO_BUFFER, CancelToken, ProgressCallback, ProgressTracker
from models.metadata import (DESCRIPTOR_EXT, KIND_DIR, KIND_FILE, SLOT_PASSWORD, SLOT_RECOVERY, Descriptor, KeySlot,
                             MazeInfo, PayloadInfo, SealedMetadata, utc_now_iso)
from utils.filesystem import atomic_write_bytes, free_space, fsync_dir, is_within, os_path, remove_quietly

SPACE_MARGIN = 64 * 1024 * 1024


@dataclass
class BuryRequest:
    source: Path
    output_dir: Path
    password: str
    descriptor_path: Optional[Path] = None
    maze: MazeConfig = field(default_factory=MazeConfig)
    kdf: Argon2Params = field(default_factory=lambda: KDF_PRESETS["standard"])
    chunk_size: int = DEFAULT_CHUNK_SIZE
    create_recovery_key: bool = False
    overwrite_descriptor: bool = False
    long_paths: bool = False
    root_name: Optional[str] = None
    min_password_length: int = 8

    def __repr__(self) -> str:  # never let the password reach a log or traceback
        return f"BuryRequest(source={self.source!s}, output_dir={self.output_dir!s}, password=<hidden>)"


@dataclass
class BuryResult:
    descriptor_path: Path
    maze_root: Path
    payload_path: Path
    original_name: str
    kind: str
    original_size: int
    file_count: int
    plaintext_sha256: str
    payload_sha256: str
    payload_size: int
    directories_created: int
    decoy_files: int
    elapsed: float
    recovery_key: Optional[str] = None
    skipped: list[str] = field(default_factory=list)

    def __repr__(self) -> str:
        return f"BuryResult(descriptor={self.descriptor_path!s}, maze_root={self.maze_root!s})"


@dataclass
class SourceInfo:
    path: Path
    kind: str
    size: int            # real bytes of file data
    stream_size: int     # estimated bytes fed to the encryptor (tar size for folders)
    file_count: int
    skipped: list[str]


def default_descriptor_name(source: Path) -> str:
    return f"{Path(source).name}{DESCRIPTOR_EXT}"


def _tar_block(n: int) -> int:
    return (n + 511) // 512 * 512


def scan_source(source: Path, cancel: Optional[CancelToken] = None) -> SourceInfo:
    """Inspect a file or folder: kind, size, and (for folders) the tar size estimate."""
    source = Path(source)
    try:
        st = os.stat(os_path(source))
    except OSError as exc:
        raise SourceError(f"Cannot access {source}: {exc.strerror or exc}") from None
    if stat.S_ISREG(st.st_mode):
        return SourceInfo(source, KIND_FILE, st.st_size, st.st_size, 1, [])
    if not stat.S_ISDIR(st.st_mode):
        raise SourceError("Only regular files and folders can be buried.")
    size = files = 0
    est = 0
    skipped: list[str] = []
    for dirpath, dirnames, filenames in os.walk(os_path(source), followlinks=False):
        if cancel is not None:
            cancel.check()
        rel_depth = len(os.path.relpath(dirpath, os_path(source)))
        est += 512 + (1024 if rel_depth > 90 else 0)
        for d in list(dirnames):
            if os.path.islink(os.path.join(dirpath, d)):
                skipped.append(os.path.join(dirpath, d))
                dirnames.remove(d)
        for name in filenames:
            full = os.path.join(dirpath, name)
            try:
                fst = os.lstat(full)
            except OSError:
                skipped.append(full)
                continue
            if not stat.S_ISREG(fst.st_mode):
                skipped.append(full)
                continue
            files += 1
            size += fst.st_size
            est += 512 + _tar_block(fst.st_size) + (1024 if len(full) - len(dirpath) + rel_depth > 90 else 0)
    est = (est + 1024 + 10239) // 10240 * 10240
    return SourceInfo(source, KIND_DIR, size, est, files, skipped)


class _PlainTap:
    """Hashes plaintext, reports progress and forwards to the encryptor."""

    def __init__(self, enc: StreamEncryptor, tracker: ProgressTracker):
        self._enc = enc
        self._tracker = tracker
        self._h = new_hasher()
        self.count = 0

    def write(self, data) -> int:
        self._h.update(data)
        self._enc.write(data)
        n = len(data)
        self.count += n
        self._tracker.advance(n)  # also checks for cancellation
        return n

    def flush(self) -> None:
        pass

    def hexdigest(self) -> str:
        return self._h.hexdigest()


def _tar_filter(skipped: list[str]):
    def f(info: tarfile.TarInfo):
        if not (info.isfile() or info.isdir()):
            skipped.append(info.name)
            return None
        # strip owner details: they are not needed and would leak account names
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        return info
    return f


def bury(req: BuryRequest, progress: Optional[ProgressCallback] = None,
         cancel: Optional[CancelToken] = None, journal: Optional[Journal] = None) -> BuryResult:
    t_start = time.monotonic()
    cancel = cancel or CancelToken()
    tracker = ProgressTracker(progress, cancel=cancel)
    journal = journal or Journal()

    # ---------------------------------------------------------------- 1. validate
    tracker.stage("Preparing", detail="Checking source and destination")
    if not req.password or len(req.password) < req.min_password_length:
        raise LostWithinError(f"The password must be at least {req.min_password_length} characters.")
    if not valid_chunk_size(req.chunk_size):
        raise LostWithinError("Invalid chunk size.")
    source = Path(req.source).absolute()
    output_dir = Path(req.output_dir).absolute()
    if not output_dir.is_dir():
        raise LostWithinError(f"The output folder does not exist: {output_dir}")
    info = scan_source(source, cancel)
    if info.kind == KIND_DIR and is_within(source, output_dir):
        raise LostWithinError("The output folder cannot be inside the folder being buried.")

    descriptor_path = Path(req.descriptor_path) if req.descriptor_path else output_dir / default_descriptor_name(source)
    descriptor_path = descriptor_path.absolute()
    if not descriptor_path.parent.is_dir():
        raise LostWithinError(f"The descriptor folder does not exist: {descriptor_path.parent}")
    if descriptor_path.exists() and not req.overwrite_descriptor:
        raise DestinationExistsError(f"A descriptor already exists at {descriptor_path}. "
                                     "Choose another name or confirm overwriting it.")
    if info.kind == KIND_FILE and descriptor_path == source:
        raise LostWithinError("The descriptor cannot replace the source file.")

    root_name_len = len(req.root_name) if req.root_name else None
    chk = check_config(req.maze, output_dir, long_paths=req.long_paths,
                       **({"root_name_len": root_name_len} if root_name_len else {}))
    if not chk.ok:
        raise MazeConfigError(" ".join(chk.errors))

    payload_size = ciphertext_size(info.stream_size, req.chunk_size)
    needed = payload_size + req.maze.decoy_files * 96 * 1024 + chk.estimated_dirs * 4096 + SPACE_MARGIN
    available = free_space(output_dir)
    if available < needed:
        from utils.filesystem import human_size
        raise InsufficientSpaceError(f"About {human_size(needed)} is needed in {output_dir}, "
                                     f"but only {human_size(available)} is free.")

    # ---------------------------------------------------------------- 2. keys
    tracker.stage("Deriving key", detail=req.kdf.description)
    dek = random_bytes(32)
    file_id = random_bytes(FILE_ID_LEN)
    salt = random_bytes(SALT_LEN)
    try:
        kek = derive_password_key(req.password, salt, req.kdf)
    except MemoryError:
        raise LostWithinError("Not enough memory for the selected key-derivation strength. "
                              "Choose a lower preset in Settings.") from None
    cancel.check()
    slot_aad = lambda typ: b"lostwithin/v1/keyslot/" + typ.encode() + b"/" + file_id  # noqa: E731
    nonce, wrapped = aead_encrypt(kek, dek, slot_aad(SLOT_PASSWORD))
    slots = [KeySlot(SLOT_PASSWORD, salt, nonce, wrapped, req.kdf)]
    del kek
    recovery_text = None
    if req.create_recovery_key:
        rk = generate_recovery_key()
        rk_salt = random_bytes(SALT_LEN)
        nonce, wrapped = aead_encrypt(recovery_key_kek(rk, rk_salt), dek, slot_aad(SLOT_RECOVERY))
        slots.append(KeySlot(SLOT_RECOVERY, rk_salt, nonce, wrapped))
        recovery_text = format_recovery_key(rk)
        del rk

    # ---------------------------------------------------------------- 3. maze
    plan = plan_maze(req.maze, req.root_name)
    maze_root = output_dir / plan.root_name
    if os.path.lexists(os_path(maze_root)):
        raise DestinationExistsError(f"{maze_root} already exists.")
    entry = journal.begin("bury", descriptor=descriptor_path, file_id=file_id.hex())
    journal.add_path(entry, maze_root)
    created_root = False
    try:
        tracker.stage("Building maze", total=len(plan.directories) + len(plan.decoy_files),
                      detail=f"Carving {len(plan.directories):,} tunnels")
        created_root = True  # build_maze creates it first; cleanup is safe even if it fails
        build_maze(plan, output_dir, cancel=cancel,
                   on_progress=lambda done, total: tracker.set_processed(done))
        tracker.finish_stage()

        # ------------------------------------------------------------ 4. encrypt
        final_dir = maze_root.joinpath(*plan.true_path)
        payload_path = final_dir / plan.payload_name
        partial_path = final_dir / (plan.payload_name + PARTIAL_SUFFIX)
        tracker.stage("Encrypting", total=info.stream_size,
                      detail=f"AES-256-GCM · {info.file_count:,} file(s)" if info.kind == KIND_DIR else "AES-256-GCM")
        pkey = payload_key(dek, file_id)
        with open(os_path(partial_path), "xb", buffering=IO_BUFFER) as raw:
            ct_writer = HashingWriter(raw)
            enc = StreamEncryptor(ct_writer, pkey, file_id, req.chunk_size)
            tap = _PlainTap(enc, tracker)
            if info.kind == KIND_FILE:
                _copy_file(source, tap, req.chunk_size)
            else:
                skipped_in_tar: list[str] = []
                with tarfile.open(fileobj=tap, mode="w|", format=tarfile.PAX_FORMAT) as tar:
                    tar.add(os_path(source), arcname=source.name, recursive=True,
                            filter=_tar_filter(skipped_in_tar))
            enc.close()
            raw.flush()
            os.fsync(raw.fileno())
        del pkey
        stream_bytes = tap.count
        tracker.finish_stage()

        tracker.stage("Finalizing", detail="Sealing the descriptor")
        os.replace(os_path(partial_path), os_path(payload_path))
        fsync_dir(final_dir)
        expected = ciphertext_size(stream_bytes, req.chunk_size)
        if ct_writer.bytes_written != expected:  # paranoia: catches a short write
            raise LostWithinError("The encrypted payload has an unexpected size; aborting.")

        # ------------------------------------------------------------ 5. descriptor
        sealed = SealedMetadata(
            original_name=source.name,
            kind=info.kind,
            original_size=stream_bytes if info.kind == KIND_FILE else info.size,
            plaintext_sha256=tap.hexdigest(),
            maze_path=list(plan.true_path),
            payload_name=plan.payload_name,
            created_utc=utc_now_iso(),
            maze_root_hint=str(maze_root),
            file_count=info.file_count,
            skipped=len(info.skipped),
        )
        desc = Descriptor(
            key_slots=slots,
            maze=MazeInfo(plan.root_name, req.maze.depth, req.maze.name_length, req.maze.branching,
                          req.maze.decoy_dirs, req.maze.decoy_files),
            payload=PayloadInfo(file_id, ct_writer.bytes_written, ct_writer.hexdigest(), req.chunk_size),
        )
        desc.sealed_nonce, desc.sealed_ciphertext = seal_json(metadata_key(dek, file_id), sealed.to_dict(), desc.aad())
        del dek
        try:
            atomic_write_bytes(descriptor_path, desc.to_bytes(), overwrite=req.overwrite_descriptor)
        except FileExistsError:
            raise DestinationExistsError(f"A descriptor appeared at {descriptor_path} during the operation.") from None
        tracker.finish_stage()
    except BaseException as exc:
        if created_root:
            tracker.stage("Cleaning up", detail="Removing incomplete maze")
            remove_quietly(maze_root)
        journal.end(entry)
        if isinstance(exc, OperationCancelled | LostWithinError):
            raise
        if isinstance(exc, OSError):
            raise LostWithinError(f"File system error: {exc.strerror or exc} "
                                  f"({exc.filename or ''}). Incomplete output was removed.") from exc
        raise
    journal.end(entry)

    return BuryResult(
        descriptor_path=descriptor_path, maze_root=maze_root, payload_path=payload_path,
        original_name=source.name, kind=info.kind, original_size=sealed.original_size,
        file_count=info.file_count, plaintext_sha256=sealed.plaintext_sha256,
        payload_sha256=desc.payload.sha256, payload_size=desc.payload.size,
        directories_created=len(plan.directories), decoy_files=len(plan.decoy_files),
        elapsed=time.monotonic() - t_start, recovery_key=recovery_text, skipped=info.skipped,
    )


def _copy_file(source: Path, sink: _PlainTap, chunk_size: int) -> None:
    buf = bytearray(chunk_size)
    view = memoryview(buf)
    try:
        fh = open(os_path(source), "rb", buffering=0)
    except OSError as exc:
        raise SourceError(f"Cannot open {source.name}: {exc.strerror or exc}") from None
    with fh:
        while True:
            n = fh.readinto(buf)
            if not n:
                break
            sink.write(view[:n])
