"""Generate assets/icons/lost_within.png and .ico (run once; outputs are committed).

    python tools/make_icon.py
"""

from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).resolve().parent.parent / "assets" / "icons"
S = 1024  # draw large, downsample for crisp edges


def draw() -> Image.Image:
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((24, 24, S - 24, S - 24), radius=210, fill=(11, 14, 17, 255),
                        outline=(52, 66, 75, 255), width=14)
    # concentric labyrinth rings, each with a gap at a different angle
    rings = [(150, 205), (250, 330), (350, 95)]  # (inset, gap angle)
    for inset, gap in rings:
        box = (inset, inset, S - inset, S - inset)
        d.arc(box, start=gap + 28, end=gap + 360 - 28, fill=(150, 162, 170, 255), width=34)
    # warm glow in the centre
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((S / 2 - 150, S / 2 - 150, S / 2 + 150, S / 2 + 150), fill=(227, 168, 87, 150))
    glow = glow.filter(ImageFilter.GaussianBlur(60))
    img = Image.alpha_composite(img, glow)
    d = ImageDraw.Draw(img)
    d.ellipse((S / 2 - 58, S / 2 - 58, S / 2 + 58, S / 2 + 58), fill=(242, 194, 125, 255))
    return img


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    big = draw()
    big.resize((256, 256), Image.LANCZOS).save(OUT / "lost_within.png")
    big.resize((256, 256), Image.LANCZOS).save(
        OUT / "lost_within.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print("wrote", OUT)
