"""Command-line interface (also used for scripting and headless testing).

    python main.py bury  <file-or-folder> <output-dir> [--depth 8 ...]
    python main.py recover <file.lostwithin> <destination-dir>
    python main.py inspect <file.lostwithin>
    python main.py --self-test

Passwords are always read interactively (getpass) or from an environment
variable named with --password-env; never from a command-line argument, which
would end up in shell history and process listings.
"""

from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

from core import APP_NAME, __version__
from core.errors import LostWithinError
from core.streaming import ProgressInfo
from utils.filesystem import human_duration, human_size


def _progress_printer():
    last = {"stage": None}

    def cb(info: ProgressInfo) -> None:
        if info.stage != last["stage"]:
            if last["stage"] is not None:
                print()
            last["stage"] = info.stage
        if info.total:
            width = 28
            filled = int(width * info.fraction)
            bar = "█" * filled + "░" * (width - filled)
            line = (f"\r{info.stage:<18} {bar} {info.fraction * 100:5.1f}%  "
                    f"{human_size(info.processed)} / {human_size(info.total)}  "
                    f"{human_size(info.speed)}/s  ETA {human_duration(info.eta)}   ")
        else:
            line = f"\r{info.stage:<18} {info.detail}   "
        print(line, end="", flush=True)
    return cb


def _password(args, confirm: bool) -> str:
    if getattr(args, "password_env", None):
        value = os.environ.get(args.password_env)
        if not value:
            raise SystemExit(f"Environment variable {args.password_env} is empty or not set.")
        return value
    pw = getpass.getpass("Password: ")
    if confirm and getpass.getpass("Confirm password: ") != pw:
        raise SystemExit("Passwords do not match.")
    return pw


def main(argv: list[str]) -> int:
    from core.key_derivation import KDF_PRESETS
    from core.maze import MazeConfig

    p = argparse.ArgumentParser(prog="lostwithin", description=f"{APP_NAME} {__version__} — Enter. Disappear. Find your way back.")
    p.add_argument("--self-test", action="store_true", help="run the safe end-to-end test with small files")
    sub = p.add_subparsers(dest="cmd")

    b = sub.add_parser("bury", help="encrypt a file or folder into a new maze")
    b.add_argument("source", type=Path)
    b.add_argument("output_dir", type=Path)
    b.add_argument("--descriptor", type=Path, help="where to write the .lostwithin file")
    d = MazeConfig()
    b.add_argument("--depth", type=int, default=d.depth)
    b.add_argument("--name-length", type=int, default=d.name_length)
    b.add_argument("--branching", type=int, default=d.branching)
    b.add_argument("--decoy-dirs", type=int, default=d.decoy_dirs)
    b.add_argument("--decoy-files", type=int, default=d.decoy_files)
    b.add_argument("--kdf", choices=sorted(KDF_PRESETS), default="standard")
    b.add_argument("--recovery-key", action="store_true", help="also create a recovery key")
    b.add_argument("--long-paths", action="store_true", help="allow paths up to 1000 characters")
    b.add_argument("--password-env", metavar="VAR", help="read the password from this environment variable")

    r = sub.add_parser("recover", help="find your way back: restore from a .lostwithin descriptor")
    r.add_argument("descriptor", type=Path)
    r.add_argument("destination", type=Path, nargs="?")
    r.add_argument("--maze-root", type=Path)
    r.add_argument("--use-recovery-key", action="store_true", help="prompt for the recovery key instead")
    r.add_argument("--on-conflict", choices=("error", "rename", "overwrite"), default="error")
    r.add_argument("--verify-only", action="store_true", help="decrypt and verify without writing files")
    r.add_argument("--password-env", metavar="VAR")

    i = sub.add_parser("inspect", help="show the public part of a descriptor")
    i.add_argument("descriptor", type=Path)

    args = p.parse_args(argv)
    try:
        if args.self_test:
            from core.selftest import run_self_test
            return 0 if run_self_test() else 1
        if args.cmd == "bury":
            from core.burial import BuryRequest, bury
            req = BuryRequest(args.source, args.output_dir, _password(args, confirm=True),
                              descriptor_path=args.descriptor,
                              maze=MazeConfig(args.depth, args.name_length, args.branching, args.decoy_dirs,
                                              args.decoy_files),
                              kdf=KDF_PRESETS[args.kdf], create_recovery_key=args.recovery_key,
                              long_paths=args.long_paths)
            res = bury(req, progress=_progress_printer())
            print(f"\n\n✓ Buried {res.original_name} ({human_size(res.original_size)}) in {res.elapsed:.1f}s")
            print(f"  Descriptor : {res.descriptor_path}")
            print(f"  Maze       : {res.maze_root}  ({res.directories_created} folders)")
            if res.recovery_key:
                print(f"  Recovery key (write it down, it is shown only once):\n    {res.recovery_key}")
            print("  Keep the descriptor safe: without it, recovery may be impossible.")
            return 0
        if args.cmd == "recover":
            from core.recovery import RecoverRequest, recover
            if not args.verify_only and args.destination is None:
                p.error("destination is required unless --verify-only is given")
            if args.use_recovery_key:
                secret = {"recovery_key": getpass.getpass("Recovery key: ")}
            else:
                secret = {"password": _password(args, confirm=False)}
            res = recover(RecoverRequest(args.descriptor, args.destination, maze_root=args.maze_root,
                                         conflict=args.on_conflict, verify_only=args.verify_only, **secret),
                          progress=_progress_printer())
            print("\n\n✓ You found your way back.\n")
            print("Integrity verified (SHA-256)." if res.verify_only else "File recovered successfully.")
            print(f"\nOriginal {'folder' if res.kind == 'dir' else 'file'}:\n{res.original_name}")
            if res.output_path:
                print(f"\nRestored to:\n{res.output_path}")
            print("\nIntegrity:\nSHA-256 verified")
            for note in res.notes:
                print(f"Note: {note}")
            return 0
        if args.cmd == "inspect":
            from core.recovery import find_maze_root_public, load_descriptor
            desc = load_descriptor(args.descriptor)
            root = find_maze_root_public(desc, args.descriptor)
            print(f"Format       : Lost Within descriptor v{desc.version} ({desc.app})")
            print(f"Cipher       : AES-256-GCM (chunked, {human_size(desc.payload.chunk_size)} chunks)")
            print(f"KDF          : {desc.slots('password')[0].kdf.description}")
            print(f"Recovery key : {'yes' if desc.has_recovery_key else 'no'}")
            print(f"Payload      : {human_size(desc.payload.size)}, SHA-256 {desc.payload.sha256[:16]}…")
            print(f"Maze         : {desc.maze.root_name} — depth {desc.maze.depth}, branching {desc.maze.branching}")
            print(f"Maze found   : {root or 'not next to descriptor'}")
            return 0
        p.print_help()
        return 0
    except LostWithinError as exc:
        print(f"\n✗ {exc.title}: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted. Incomplete output was removed.", file=sys.stderr)
        return 130
