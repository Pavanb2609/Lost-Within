"""Lost Within — Enter. Disappear. Find your way back.

    python main.py                 start the desktop app
    python main.py --self-test     run the safe end-to-end test
    python main.py bury|recover|inspect ...   command-line mode (see cli.py)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Make the project importable however the script is launched (and when frozen).
ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _cli_requested(argv: list[str]) -> bool:
    return bool(argv) and (argv[0] in {"bury", "recover", "inspect", "-h", "--help"} or "--self-test" in argv)


def main() -> int:
    argv = sys.argv[1:]
    if _cli_requested(argv):
        # A --windowed PyInstaller build has no console. When started from cmd or
        # PowerShell, attach to that console so CLI output and prompts work.
        if sys.stdout is None and sys.platform == "win32":
            try:
                import ctypes
                if ctypes.windll.kernel32.AttachConsole(-1):  # ATTACH_PARENT_PROCESS
                    sys.stdout = open("CONOUT$", "w", encoding="utf-8")
                    sys.stderr = open("CONOUT$", "w", encoding="utf-8")
                    sys.stdin = open("CONIN$", "r")
            except Exception:
                pass
        if sys.stdout is None:
            sys.stdout = open(os.devnull, "w")
        if sys.stderr is None:
            sys.stderr = open(os.devnull, "w")
        try:
            sys.stdout.reconfigure(encoding="utf-8")  # ✓/█ on legacy Windows consoles
        except (AttributeError, ValueError):
            pass
        from cli import main as cli_main
        return cli_main(argv)

    from ui.main_window import run_app
    return run_app(argv)


if __name__ == "__main__":
    sys.exit(main())
