@echo off
REM Build LostWithin.exe with PyInstaller. Run from the project folder
REM inside the virtual environment (see README).
setlocal

python -m pytest -q || (echo Tests failed - not building. & exit /b 1)

pyinstaller --noconfirm --clean --windowed --onefile ^
  --name LostWithin ^
  --icon assets\icons\lost_within.ico ^
  --add-data "assets;assets" ^
  --collect-submodules argon2 ^
  --exclude-module pytest --exclude-module PIL --exclude-module tkinter ^
  main.py || exit /b 1

echo.
echo Built dist\LostWithin.exe
dist\LostWithin.exe --self-test
