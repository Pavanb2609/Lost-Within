import io
import os

import pytest

from core.encryption import (HEADER_LEN, TAG_LEN, StreamEncryptor, ciphertext_size, decrypt_stream,
                             seal_json, open_json)
from core.errors import IntegrityError
from core.key_derivation import (KDF_PRESETS, TEST_KDF, Argon2Params, derive_password_key, format_recovery_key,
                                 generate_recovery_key, parse_recovery_key)
from core.errors import DescriptorError

CS = 64 * 1024
KEY = bytes(range(32))
FID = b"F" * 16


def encrypt(data: bytes, write_sizes=None) -> bytes:
    out = io.BytesIO()
    enc = StreamEncryptor(out, KEY, FID, CS)
    if write_sizes is None:
        enc.write(data)
    else:  # feed in odd-sized pieces to exercise buffering
        pos = 0
        i = 0
        while pos < len(data):
            n = write_sizes[i % len(write_sizes)]
            enc.write(data[pos:pos + n])
            pos += n
            i += 1
    enc.close()
    return out.getvalue()


def decrypt(blob: bytes, key=KEY, fid=FID) -> bytes:
    out = io.BytesIO()
    decrypt_stream(io.BytesIO(blob), out, key, expected_file_id=fid, expected_chunk_size=CS)
    return out.getvalue()


@pytest.mark.parametrize("size", [0, 1, CS - 1, CS, CS + 1, 3 * CS, 3 * CS + 777])
def test_roundtrip_sizes(size):
    data = os.urandom(size)
    blob = encrypt(data)
    assert len(blob) == ciphertext_size(size, CS)
    assert decrypt(blob) == data


def test_streaming_writes_of_odd_sizes():
    data = os.urandom(5 * CS + 123)
    assert decrypt(encrypt(data, write_sizes=[1, 7000, CS + 3, 2 * CS])) == data


def test_ciphertext_differs_each_time():
    data = b"same data" * 100
    assert encrypt(data) != encrypt(data)  # random nonce prefix


def test_wrong_key_fails():
    with pytest.raises(IntegrityError):
        decrypt(encrypt(b"hello" * 1000), key=bytes(32))


def test_bit_flip_detected():
    blob = bytearray(encrypt(os.urandom(2 * CS + 10)))
    blob[HEADER_LEN + CS + TAG_LEN + 5] ^= 1  # second chunk
    with pytest.raises(IntegrityError, match="Chunk 2"):
        decrypt(bytes(blob))


def test_header_tamper_detected():
    blob = bytearray(encrypt(os.urandom(1000)))
    blob[25] ^= 1  # a nonce-prefix byte inside the authenticated header
    with pytest.raises(IntegrityError):
        decrypt(bytes(blob))


@pytest.mark.parametrize("cut", [1, TAG_LEN, CS + TAG_LEN])
def test_truncation_detected(cut):
    blob = encrypt(os.urandom(3 * CS + 500))
    with pytest.raises(IntegrityError):
        decrypt(blob[:-cut])


def test_truncation_at_chunk_boundary_detected():
    blob = encrypt(os.urandom(3 * CS))  # exactly three full chunks
    # drop the final chunk entirely: the remaining last chunk is not marked final
    with pytest.raises(IntegrityError):
        decrypt(blob[: HEADER_LEN + 2 * (CS + TAG_LEN)])


def test_header_only_is_incomplete():
    blob = encrypt(b"abc")
    with pytest.raises(IntegrityError, match="incomplete"):
        decrypt(blob[:HEADER_LEN])


def test_appended_data_detected():
    blob = encrypt(os.urandom(CS))
    with pytest.raises(IntegrityError):
        decrypt(blob + os.urandom(CS + TAG_LEN))


def test_chunk_swap_detected():
    blob = encrypt(os.urandom(3 * CS + 10))
    n = CS + TAG_LEN
    c0, c1 = blob[HEADER_LEN:HEADER_LEN + n], blob[HEADER_LEN + n:HEADER_LEN + 2 * n]
    swapped = blob[:HEADER_LEN] + c1 + c0 + blob[HEADER_LEN + 2 * n:]
    with pytest.raises(IntegrityError):
        decrypt(swapped)


def test_wrong_file_id_rejected():
    with pytest.raises(IntegrityError, match="different burial"):
        decrypt(encrypt(b"x"), fid=b"G" * 16)


def test_seal_json_roundtrip_and_aad():
    nonce, ct = seal_json(KEY, {"name": "ü.txt"}, b"aad")
    assert open_json(KEY, nonce, ct, b"aad") == {"name": "ü.txt"}
    with pytest.raises(Exception):
        open_json(KEY, nonce, ct, b"other aad")


def test_argon2_deterministic_and_salted():
    k1 = derive_password_key("pässwörd", b"s" * 16, TEST_KDF)
    assert k1 == derive_password_key("pässwörd", b"s" * 16, TEST_KDF)
    assert k1 != derive_password_key("pässwörd", b"t" * 16, TEST_KDF)
    assert len(k1) == 32


def test_argon2_unicode_normalization():
    composed, decomposed = "café", "café"
    assert derive_password_key(composed, b"s" * 16, TEST_KDF) == derive_password_key(decomposed, b"s" * 16, TEST_KDF)


def test_argon2_matches_reference_implementation():
    from argon2.low_level import Type, hash_secret_raw
    ours = derive_password_key("pw", b"0123456789abcdef", TEST_KDF)
    ref = hash_secret_raw(b"pw", b"0123456789abcdef", TEST_KDF.time_cost, TEST_KDF.memory_cost_kib,
                          TEST_KDF.parallelism, 32, Type.ID)
    assert ours == ref


def test_argon2_param_limits():
    for p in KDF_PRESETS.values():
        p.validate()
    with pytest.raises(DescriptorError):
        Argon2Params(1, 64 * 1024 * 1024, 1).validate()  # 64 GiB: rejected


def test_recovery_key_format_and_typos():
    raw = generate_recovery_key()
    text = format_recovery_key(raw)
    assert text.startswith("LW1-") and len(text.replace("-", "")) == 59
    assert parse_recovery_key(text) == raw
    assert parse_recovery_key(text.lower().replace("-", " ")) == raw
    bad = list(text)
    i = 10 if text[10] != "A" else 11
    bad[i] = "A" if text[i] != "A" else "B"
    with pytest.raises(ValueError, match="typo"):
        parse_recovery_key("".join(bad))
