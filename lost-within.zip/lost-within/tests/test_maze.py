from collections import Counter
from pathlib import Path

import pytest

from core.maze import (LIMITS, MAX_TOTAL_DIRS, PAYLOAD_EXT, MazeConfig, build_maze, check_config, plan_maze)
from utils.filesystem import SAFE_PATH_LIMIT
from utils.random_names import random_name, random_unique_name
from utils.validation import is_safe_maze_component, sanitize_filename


def test_plan_shape():
    cfg = MazeConfig(depth=6, name_length=8, branching=3, decoy_dirs=10, decoy_files=5)
    plan = plan_maze(cfg)
    assert len(plan.true_path) == 6
    assert plan.payload_name.endswith(PAYLOAD_EXT)
    assert all(len(d) <= cfg.depth for d in plan.directories)
    assert set(plan.directories) >= {plan.true_path[:i] for i in range(1, 7)}
    # every level of the true path has `branching` siblings
    for level in range(6):
        parent = plan.true_path[:level]
        siblings = [d for d in plan.directories if len(d) == level + 1 and d[:level] == parent]
        assert len(siblings) >= 3  # decoy chains may add more
    assert len(plan.decoy_files) == 5
    assert all(f[0] != plan.true_path for f in plan.decoy_files)


def test_names_unique_case_insensitively():
    plan = plan_maze(MazeConfig(depth=4, name_length=4, branching=8, decoy_dirs=200))
    by_parent = Counter((d[:-1], d[-1].casefold()) for d in plan.directories)
    assert max(by_parent.values()) == 1


def test_plans_are_unpredictable():
    a, b = plan_maze(MazeConfig()), plan_maze(MazeConfig())
    assert a.true_path != b.true_path and a.root_name != b.root_name


def test_random_names_use_csprng_alphabet():
    names = {random_name(8) for _ in range(500)}
    assert len(names) == 500
    assert all(n.isalnum() and len(n) == 8 for n in names)
    taken = set()
    assert random_unique_name(6, taken).casefold() in taken


def test_build_creates_tree(tmp_path):
    plan = plan_maze(MazeConfig(depth=4, name_length=6, branching=2, decoy_dirs=3, decoy_files=3))
    root = build_maze(plan, tmp_path)
    assert root.is_dir() and root.name == plan.root_name
    assert root.joinpath(*plan.true_path).is_dir()
    files = [p for p in root.rglob("*") if p.is_file()]
    assert len(files) == 3 and all(4096 <= p.stat().st_size < 96 * 1024 for p in files)
    with pytest.raises(FileExistsError):
        build_maze(plan, tmp_path)  # never reuses an existing root


def test_check_rejects_out_of_range():
    chk = check_config(MazeConfig(depth=0), Path("C:/x"))
    assert not chk.ok
    chk = check_config(MazeConfig(branching=LIMITS["branching"][1] + 1), Path("C:/x"))
    assert not chk.ok


def test_check_path_length_limit():
    base = Path("/" + "a" * 60)
    deep = MazeConfig(depth=30, name_length=10, branching=1, decoy_dirs=0, decoy_files=0)
    chk = check_config(deep, base)
    assert not chk.ok and chk.longest_path > SAFE_PATH_LIMIT
    assert check_config(deep, base, long_paths=True).ok
    assert check_config(MazeConfig(), base).ok


def test_check_directory_count_limit():
    chk = check_config(MazeConfig(depth=64, name_length=4, branching=8, decoy_dirs=1000), Path("/a"), long_paths=True)
    assert chk.estimated_dirs > MAX_TOTAL_DIRS and not chk.ok


@pytest.mark.parametrize("bad,expected", [
    ("../../etc/passwd", "passwd"),
    ("..\\..\\Windows\\system.ini", "system.ini"),
    ("C:\\Users\\x\\evil.exe", "evil.exe"),
    ("/abs/path.txt", "path.txt"),
    ("..", "recovered_item"),
    ("", "recovered_item"),
    ("CON.txt", "_CON.txt"),
    ("nul", "_nul"),
    ('a<b>c:"d|e?*.txt', "a_b_c__d_e__.txt"),
    ("trailing. ", "trailing"),
    ("normal name (1).zip", "normal name (1).zip"),
])
def test_sanitize_filename(bad, expected):
    assert sanitize_filename(bad) == expected


def test_sanitize_long_name_keeps_extension():
    out = sanitize_filename("x" * 400 + ".zip")
    assert out.endswith(".zip") and len(out.encode()) <= 255


def test_maze_component_validation():
    assert is_safe_maze_component("aZ72Lm")
    assert is_safe_maze_component("aZ72Lm.dat")
    for bad in ("..", "a/b", "a\\b", "", "CON", "x" * 65, 5, None, ".dat"):
        assert not is_safe_maze_component(bad)
