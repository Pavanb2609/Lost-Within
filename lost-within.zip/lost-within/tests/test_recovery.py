import hashlib
import json
import os
import shutil
from pathlib import Path

import pytest

from core.burial import BuryRequest, bury
from core.errors import (DescriptorError, DestinationExistsError, IntegrityError, LostWithinError, MazeConfigError,
                         MazeNotFoundError, OperationCancelled, PayloadNotFoundError, WrongPasswordError)
from core.journal import Journal
from core.key_derivation import TEST_KDF
from core.maze import MazeConfig
from core.recovery import RecoverRequest, find_maze_root_public, load_descriptor, recover, unlock
from core.selftest import run_self_test
from core.streaming import CancelToken
from models.metadata import Descriptor

PW = "a long test passphrase 42"
CS = 64 * 1024
MAZE = MazeConfig(depth=4, name_length=6, branching=2, decoy_dirs=3, decoy_files=2)


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


@pytest.fixture
def env(tmp_path):
    src, out, dest = tmp_path / "src", tmp_path / "out", tmp_path / "dest"
    for p in (src, out, dest):
        p.mkdir()
    journal = Journal(tmp_path / "journal")

    def do_bury(path, **kw):
        kw.setdefault("maze", MAZE)
        return bury(BuryRequest(path, out, kw.pop("password", PW), kdf=TEST_KDF, chunk_size=CS, **kw),
                    journal=journal)

    def do_recover(desc, **kw):
        kw.setdefault("password", PW)
        return recover(RecoverRequest(desc, kw.pop("destination_dir", dest), **kw), journal=journal)

    return src, out, dest, do_bury, do_recover, journal


def make(src: Path, name="report.pdf", size=CS * 3 + 17) -> Path:
    f = src / name
    f.write_bytes(os.urandom(size))
    return f


def test_full_roundtrip(env):
    src, out, dest, do_bury, do_recover, journal = env
    f = make(src)
    b = do_bury(f)
    assert b.descriptor_path == out / "report.pdf.lostwithin"
    assert b.payload_path.is_file() and b.payload_path.is_relative_to(b.maze_root)
    assert "report" not in str(b.payload_path.relative_to(out))
    r = do_recover(b.descriptor_path)
    assert r.output_path == dest / "report.pdf" and sha(r.output_path) == sha(f)
    assert not journal.pending()
    assert [p.name for p in dest.iterdir()] == ["report.pdf"]  # no temp files left


def test_descriptor_contents(env):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    raw = b.descriptor_path.read_bytes()
    d = json.loads(raw)
    assert d["cipher"] == "AES-256-GCM-STREAM" and d["kdf"] == "argon2id"
    assert d["key_slots"][0]["kdf"]["memory_cost_kib"] == TEST_KDF.memory_cost_kib
    assert b"report" not in raw and PW.encode() not in raw
    assert d["payload"]["sha256"] == sha(b.payload_path)


def test_wrong_password(env):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    with pytest.raises(WrongPasswordError):
        do_recover(b.descriptor_path, password="wrong password!")
    assert list(dest.iterdir()) == []


def test_recovery_key(env):
    src, out, dest, do_bury, do_recover, _ = env
    f = make(src)
    b = do_bury(f, create_recovery_key=True)
    r = do_recover(b.descriptor_path, password=None, recovery_key=b.recovery_key)
    assert sha(r.output_path) == sha(f)
    with pytest.raises(WrongPasswordError):
        b2 = do_bury(make(src, "other.bin"))
        do_recover(b2.descriptor_path, password=None, recovery_key=b.recovery_key)


@pytest.mark.parametrize("mutate", [
    lambda d: d["maze"].__setitem__("depth", d["maze"]["depth"] + 1),
    lambda d: d["payload"].__setitem__("size", d["payload"]["size"] + 1),
    lambda d: d["key_slots"][0]["kdf"].__setitem__("time_cost", 2),
])
def test_descriptor_tamper_detected(env, mutate):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    d = json.loads(b.descriptor_path.read_text())
    mutate(d)
    b.descriptor_path.write_text(json.dumps(d))
    with pytest.raises((DescriptorError, WrongPasswordError, IntegrityError)):
        do_recover(b.descriptor_path)


@pytest.mark.parametrize("payload", [
    b"not json",
    b'{"format": "something-else"}',
    b'{"format": "lostwithin-descriptor", "version": 99}',
    json.dumps({"format": "lostwithin-descriptor", "version": 1}).encode(),
])
def test_invalid_descriptors_rejected(tmp_path, payload):
    with pytest.raises(DescriptorError):
        Descriptor.from_bytes(payload)


def test_unknown_fields_and_bad_kdf_rejected(env):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    d = json.loads(b.descriptor_path.read_text())
    d["extra"] = 1
    with pytest.raises(DescriptorError, match="unexpected"):
        Descriptor.from_bytes(json.dumps(d).encode())
    d = json.loads(b.descriptor_path.read_text())
    d["key_slots"][0]["kdf"]["memory_cost_kib"] = 1 << 30  # DoS attempt
    with pytest.raises(DescriptorError):
        Descriptor.from_bytes(json.dumps(d).encode())


def test_path_traversal_in_sealed_name_is_neutralised(env, monkeypatch):
    src, out, dest, do_bury, do_recover, _ = env
    f = make(src, "innocent.txt", 100)
    import core.burial as burial
    real = burial.SealedMetadata

    def evil(**kw):
        kw["original_name"] = "../../escape.txt"
        return real(**kw)
    monkeypatch.setattr(burial, "SealedMetadata", evil)
    b = do_bury(f)
    r = do_recover(b.descriptor_path)
    assert r.output_path == dest / "escape.txt"
    assert not (dest.parent / "escape.txt").exists()
    assert r.notes


def test_maze_path_traversal_rejected(env):
    from core.recovery import unlock
    from models.metadata import SealedMetadata
    with pytest.raises(DescriptorError):
        SealedMetadata.from_dict({"original_name": "a", "kind": "file", "original_size": 1,
                                  "plaintext_sha256": "0" * 64, "maze_path": ["..", "x"],
                                  "payload_name": "a.dat", "created_utc": "now"})


def test_payload_corruption_and_truncation(env):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    orig = b.payload_path.read_bytes()
    bad = bytearray(orig)
    bad[len(bad) // 2] ^= 0x80
    b.payload_path.write_bytes(bad)
    with pytest.raises(IntegrityError):
        do_recover(b.descriptor_path)
    assert list(dest.iterdir()) == []  # partial output removed
    b.payload_path.write_bytes(orig[: len(orig) // 2])
    with pytest.raises(IntegrityError, match="incomplete"):
        do_recover(b.descriptor_path)


def test_missing_payload_and_maze(env):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    b.payload_path.unlink()
    with pytest.raises(PayloadNotFoundError):
        do_recover(b.descriptor_path)
    shutil.rmtree(b.maze_root)
    with pytest.raises(MazeNotFoundError):
        do_recover(b.descriptor_path)


def test_moved_maze_and_renamed_folders(env, tmp_path):
    src, out, dest, do_bury, do_recover, _ = env
    f = make(src)
    b = do_bury(f)
    elsewhere = tmp_path / "usb"
    elsewhere.mkdir()
    moved_desc = elsewhere / b.descriptor_path.name
    shutil.move(b.descriptor_path, moved_desc)
    shutil.move(b.maze_root, elsewhere / b.maze_root.name)
    # maze next to descriptor -> found automatically
    assert find_maze_root_public(load_descriptor(moved_desc), moved_desc) == elsewhere / b.maze_root.name
    # rename an intermediate maze folder -> fallback scan finds the payload
    first = next(p for p in (elsewhere / b.maze_root.name).iterdir()
                 if b.payload_path.relative_to(b.maze_root).parts[0] == p.name)
    first.rename(first.with_name("renamed"))
    r = do_recover(moved_desc)
    assert sha(r.output_path) == sha(f) and any("scanning" in n for n in r.notes)


def test_conflict_policies(env):
    src, out, dest, do_bury, do_recover, _ = env
    f = make(src, size=500)
    b = do_bury(f)
    do_recover(b.descriptor_path)
    with pytest.raises(DestinationExistsError):
        do_recover(b.descriptor_path)
    r = do_recover(b.descriptor_path, conflict="rename")
    assert r.output_path.name == "report (1).pdf" and r.renamed
    (dest / "report.pdf").write_bytes(b"old")
    r = do_recover(b.descriptor_path, conflict="overwrite")
    assert sha(r.output_path) == sha(f)


def test_verify_only_writes_nothing(env):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    r = do_recover(b.descriptor_path, verify_only=True, destination_dir=None)
    assert r.output_path is None and list(dest.iterdir()) == []


def test_folder_roundtrip_with_unicode(env):
    src, out, dest, do_bury, do_recover, _ = env
    folder = src / "Fötos 2026"
    (folder / "a" / "b").mkdir(parents=True)
    (folder / "empty").mkdir()
    (folder / "a" / "b" / "日本.txt").write_text("こんにちは", "utf-8")
    (folder / "big.bin").write_bytes(os.urandom(CS * 2 + 1))
    if hasattr(os, "symlink"):
        try:
            os.symlink("/etc/passwd", folder / "link")
        except OSError:
            pass
    b = do_bury(folder)
    r = do_recover(b.descriptor_path)
    assert r.kind == "dir" and r.output_path == dest / "Fötos 2026"
    assert (r.output_path / "a" / "b" / "日本.txt").read_text("utf-8") == "こんにちは"
    assert sha(r.output_path / "big.bin") == sha(folder / "big.bin")
    assert (r.output_path / "empty").is_dir()
    assert not (r.output_path / "link").exists()  # links are skipped, never followed


def test_existing_descriptor_not_overwritten(env):
    src, out, dest, do_bury, do_recover, _ = env
    f = make(src)
    do_bury(f)
    before = set(out.iterdir())
    with pytest.raises(DestinationExistsError):
        do_bury(f)
    assert set(out.iterdir()) == before  # nothing created
    do_bury(f, overwrite_descriptor=True)


def test_invalid_maze_rejected_before_writing(env):
    src, out, dest, do_bury, do_recover, _ = env
    with pytest.raises(MazeConfigError):
        do_bury(make(src), maze=MazeConfig(depth=60, name_length=32, branching=1, decoy_dirs=0, decoy_files=0))
    assert list(out.iterdir()) == []


def test_short_password_rejected(env):
    src, out, dest, do_bury, do_recover, _ = env
    with pytest.raises(LostWithinError):
        do_bury(make(src), password="short")


def test_cancel_cleans_up(env):
    src, out, dest, do_bury, do_recover, journal = env
    f = make(src, size=CS * 20)
    token = CancelToken()

    def cb(info):
        if info.stage == "Encrypting":
            token.cancel()
    with pytest.raises(OperationCancelled):
        bury(BuryRequest(f, out, PW, maze=MAZE, kdf=TEST_KDF, chunk_size=CS), progress=cb, cancel=token,
             journal=journal)
    assert list(out.iterdir()) == [] and not journal.pending()


def test_journal_cleans_interrupted_operation(tmp_path):
    j = Journal(tmp_path / "j")
    maze = tmp_path / "LostWithin_abc"
    (maze / "x").mkdir(parents=True)
    entry = j.begin("bury", descriptor=tmp_path / "never-written.lostwithin", file_id="00" * 16)
    j.add_path(entry, maze)
    pending = j.pending()
    assert len(pending) == 1
    assert j.cleanup(pending[0]) == [str(maze)]
    assert not maze.exists() and not j.pending()


def test_journal_keeps_completed_burial(env):
    src, out, dest, do_bury, do_recover, journal = env
    b = do_bury(make(src))
    entry = journal.begin("bury", descriptor=b.descriptor_path, file_id=load_descriptor(b.descriptor_path).payload.file_id.hex())
    journal.add_path(entry, b.maze_root)
    assert journal.pending() == []  # descriptor exists -> it succeeded, nothing to clean
    assert b.maze_root.exists()


def test_unlock_does_not_need_maze(env):
    src, out, dest, do_bury, do_recover, _ = env
    b = do_bury(make(src))
    dek, sealed = unlock(load_descriptor(b.descriptor_path), password=PW)
    assert sealed.original_name == "report.pdf" and len(dek) == 32


def test_self_test_mode_passes(tmp_path, monkeypatch):
    monkeypatch.setenv("LOSTWITHIN_HOME", str(tmp_path))
    lines = []
    assert run_self_test(lines.append), "\n".join(lines)
