"""Unpredictable names for maze directories and files.

All randomness comes from :mod:`secrets` (the OS CSPRNG). The ``random`` module
is never used for anything that ends up on disk.
"""

from __future__ import annotations

import math
import secrets
import string

ALPHABET = string.ascii_letters + string.digits

# Device names Windows refuses to use as file or folder names (with any extension).
WINDOWS_RESERVED = frozenset(
    {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"}
    | {f"COM{i}" for i in range(10)}
    | {f"LPT{i}" for i in range(10)}
)


def random_name(length: int, alphabet: str = ALPHABET) -> str:
    """Return a random name of ``length`` characters drawn uniformly from ``alphabet``."""
    if length < 1:
        raise ValueError("name length must be at least 1")
    while True:
        name = "".join(secrets.choice(alphabet) for _ in range(length))
        if name.upper() not in WINDOWS_RESERVED:
            return name


def random_unique_name(length: int, taken: set[str], alphabet: str = ALPHABET) -> str:
    """Return a random name not already in ``taken`` (compared case-insensitively).

    Windows and macOS file systems are case-insensitive, so ``aB3x`` and ``Ab3X``
    would collide. ``taken`` stores casefolded names and is updated in place.
    """
    for _ in range(10_000):
        name = random_name(length, alphabet)
        key = name.casefold()
        if key not in taken:
            taken.add(key)
            return name
    raise RuntimeError("Could not generate a unique name; increase the folder-name length.")


def name_entropy_bits(length: int, alphabet_size: int = len(ALPHABET)) -> float:
    """Bits of entropy in one random name (an upper bound on how hard it is to guess)."""
    return length * math.log2(alphabet_size)
