"""Input validation: untrusted metadata fields, restored filenames, passwords."""

from __future__ import annotations

import base64
import binascii
import math
import re
import unicodedata

from core.errors import DescriptorError
from utils.random_names import WINDOWS_RESERVED

MAX_FILENAME_BYTES = 255
_INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f\x7f]')
_MAZE_COMPONENT = re.compile(r"^[A-Za-z0-9_]{1,64}(\.[a-z]{1,8})?$")
_HEX = re.compile(r"^[0-9a-f]+$")


# --------------------------------------------------------------------------- filenames

def sanitize_filename(name: str, fallback: str = "recovered_item") -> str:
    """Turn a stored original filename into a safe single path component.

    Defends against path traversal (``../``, absolute paths, drive letters),
    characters Windows rejects, reserved device names and over-long names.
    The result never contains a path separator.
    """
    if not isinstance(name, str):
        return fallback
    name = unicodedata.normalize("NFC", name)
    # Keep only the final component, whatever separator was used.
    name = re.split(r"[\\/]", name)[-1]
    name = _INVALID_CHARS.sub("_", name)
    name = name.strip().rstrip(". ")
    if name in ("", ".", ".."):
        return fallback
    stem = name.split(".")[0]
    if stem.upper() in WINDOWS_RESERVED:
        name = "_" + name
    # Truncate to 255 UTF-8 bytes, preserving a short extension if possible.
    if len(name.encode("utf-8")) > MAX_FILENAME_BYTES:
        base, dot, ext = name.rpartition(".")
        if dot and 0 < len(ext) <= 16:
            budget = MAX_FILENAME_BYTES - len(ext.encode("utf-8")) - 1
            base = base.encode("utf-8")[:budget].decode("utf-8", "ignore")
            name = f"{base}.{ext}"
        else:
            name = name.encode("utf-8")[:MAX_FILENAME_BYTES].decode("utf-8", "ignore")
    return name or fallback


def is_safe_maze_component(name: object) -> bool:
    """Strict check for maze folder/file names read back from a descriptor."""
    return (
        isinstance(name, str)
        and bool(_MAZE_COMPONENT.match(name))
        and name.split(".")[0].upper() not in WINDOWS_RESERVED
    )


# --------------------------------------------------------------------------- metadata fields

def require_type(obj: object, typ: type, field: str):
    # bool is a subclass of int; never accept it where a number is expected.
    if typ is int and isinstance(obj, bool):
        raise DescriptorError(f"Field '{field}' has the wrong type.")
    if not isinstance(obj, typ):
        raise DescriptorError(f"Field '{field}' is missing or has the wrong type.")
    return obj


def require_int(obj: object, field: str, lo: int, hi: int) -> int:
    value = require_type(obj, int, field)
    if not lo <= value <= hi:
        raise DescriptorError(f"Field '{field}' is out of range ({value}).")
    return value


def require_str(obj: object, field: str, max_len: int = 1024, choices: tuple[str, ...] | None = None) -> str:
    value = require_type(obj, str, field)
    if len(value) > max_len:
        raise DescriptorError(f"Field '{field}' is too long.")
    if choices is not None and value not in choices:
        raise DescriptorError(f"Field '{field}' has an unsupported value: {value[:40]!r}.")
    return value


def require_b64(obj: object, field: str, *, length: int | None = None, min_len: int = 0, max_len: int = 1 << 20) -> bytes:
    value = require_str(obj, field, max_len=4 * max_len // 3 + 8)
    try:
        raw = base64.b64decode(value.encode("ascii"), validate=True)
    except (binascii.Error, UnicodeEncodeError):
        raise DescriptorError(f"Field '{field}' is not valid base64.") from None
    if length is not None and len(raw) != length:
        raise DescriptorError(f"Field '{field}' has the wrong length.")
    if not min_len <= len(raw) <= max_len:
        raise DescriptorError(f"Field '{field}' has the wrong length.")
    return raw


def require_hex(obj: object, field: str, nbytes: int) -> str:
    value = require_str(obj, field, max_len=nbytes * 2)
    if len(value) != nbytes * 2 or not _HEX.match(value):
        raise DescriptorError(f"Field '{field}' must be {nbytes * 2} lowercase hex characters.")
    return value


def require_keys(obj: object, field: str, required: set[str], optional: set[str] = frozenset()) -> dict:
    """Require a dict with exactly the expected keys (unknown keys are rejected)."""
    d = require_type(obj, dict, field)
    keys = set(d)
    missing = required - keys
    unknown = keys - required - set(optional)
    if missing:
        raise DescriptorError(f"Section '{field}' is missing: {', '.join(sorted(missing))}.")
    if unknown:
        raise DescriptorError(f"Section '{field}' has unexpected fields: {', '.join(sorted(unknown))[:120]}.")
    return d


def b64e(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


# --------------------------------------------------------------------------- passwords

_COMMON = {
    "password", "password1", "123456", "12345678", "123456789", "1234567890", "qwerty",
    "qwerty123", "letmein", "iloveyou", "admin", "welcome", "monkey", "dragon", "football",
    "abc123", "111111", "000000", "passw0rd", "trustno1", "sunshine", "princess", "lostwithin",
}


def estimate_password_bits(password: str) -> float:
    """Rough guessing-entropy estimate. Heuristic only: it cannot detect phrases,
    keyboard walks or personal information, so treat the result as optimistic."""
    if not password:
        return 0.0
    pool = 0
    if re.search(r"[a-z]", password):
        pool += 26
    if re.search(r"[A-Z]", password):
        pool += 26
    if re.search(r"[0-9]", password):
        pool += 10
    if re.search(r"[^A-Za-z0-9]", password):
        pool += 33
    if any(ord(c) > 127 for c in password):
        pool += 64
    unique_ratio = len(set(password)) / len(password)
    effective_len = len(password) * min(1.0, 0.35 + unique_ratio)
    bits = effective_len * math.log2(max(pool, 2))
    if password.lower() in _COMMON or password.lower().rstrip("0123456789!") in _COMMON:
        bits = min(bits, 10.0)
    return bits


def password_strength(password: str) -> tuple[int, str]:
    """Return (score 0..4, label)."""
    bits = estimate_password_bits(password)
    for limit, score, label in ((28, 0, "Very weak"), (45, 1, "Weak"), (60, 2, "Fair"), (80, 3, "Strong")):
        if bits < limit:
            return score, label
    return 4, "Very strong"


def password_problems(password: str, confirm: str | None = None, min_length: int = 12) -> list[str]:
    problems = []
    if len(password) < min_length:
        problems.append(f"Use at least {min_length} characters.")
    if password and password_strength(password)[0] < 2:
        problems.append("This password is too easy to guess. Use a longer passphrase.")
    if confirm is not None and password != confirm:
        problems.append("The passwords do not match.")
    return problems
