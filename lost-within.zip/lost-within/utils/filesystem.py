"""Filesystem helpers: atomic writes, no-clobber renames, safe deletion, long paths."""

from __future__ import annotations

import errno
import os
import secrets
import shutil
import stat
import sys
from pathlib import Path

IS_WINDOWS = sys.platform == "win32"

# Classic Windows MAX_PATH is 260 characters including the drive and terminator.
WINDOWS_MAX_PATH = 260
# Default limit for generated paths: leaves headroom for temp suffixes and tools
# (Explorer, zip utilities, backup software) that still choke on long paths.
SAFE_PATH_LIMIT = 240
# Limit in "long path mode". Windows allows ~32k with the \\?\ prefix, but very
# long paths are painful to move, copy or delete, so we cap well below that.
LONG_PATH_LIMIT = 1000


def os_path(path: Path | str) -> str:
    """Return a path string usable by OS calls even beyond MAX_PATH on Windows.

    On Windows, absolute paths longer than the classic limit get the ``\\\\?\\``
    extended-length prefix. Elsewhere the path is returned unchanged.
    """
    s = str(path)
    if not IS_WINDOWS or s.startswith("\\\\?\\"):
        return s
    if len(s) < WINDOWS_MAX_PATH - 12:
        return s
    s = os.path.abspath(s)
    if s.startswith("\\\\"):  # UNC path
        return "\\\\?\\UNC\\" + s[2:]
    return "\\\\?\\" + s


def fsync_dir(path: Path) -> None:
    """Flush a directory entry to disk (POSIX only; a no-op on Windows)."""
    if IS_WINDOWS:
        return
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def rename_no_clobber(src: Path, dst: Path) -> None:
    """Rename ``src`` to ``dst``, failing with FileExistsError if ``dst`` exists."""
    s, d = os_path(src), os_path(dst)
    if IS_WINDOWS:
        os.rename(s, d)  # Windows rename never replaces an existing file
        return
    try:
        os.link(s, d)  # atomic "create if absent"
    except FileExistsError:
        raise
    except OSError as exc:
        if exc.errno not in (errno.EPERM, errno.ENOTSUP, errno.EOPNOTSUPP, errno.EXDEV, errno.EMLINK):
            raise
        # File system without hard links (FAT/exFAT, some network shares).
        if os.path.lexists(d):
            raise FileExistsError(errno.EEXIST, "File exists", str(dst)) from None
        os.rename(s, d)
        return
    os.unlink(s)


def atomic_write_bytes(path: Path, data: bytes, *, overwrite: bool = False) -> None:
    """Write ``data`` to ``path`` via a temporary file + rename, so readers never
    see a half-written file. Without ``overwrite`` an existing file is never replaced."""
    path = Path(path)
    if not overwrite and path.exists():
        raise FileExistsError(errno.EEXIST, "File exists", str(path))
    tmp = path.with_name(f".{secrets.token_hex(6)}.lw-tmp")
    try:
        with open(os_path(tmp), "xb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        if overwrite:
            os.replace(os_path(tmp), os_path(path))
        else:
            rename_no_clobber(tmp, path)
        fsync_dir(path.parent)
    except BaseException:
        try:
            os.unlink(os_path(tmp))
        except OSError:
            pass
        raise


def unique_path(path: Path) -> Path:
    """Return ``path`` or the first free ``name (n).ext`` variant next to it."""
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    if path.is_dir():
        stem, suffix = path.name, ""
    for n in range(1, 10_000):
        candidate = path.with_name(f"{stem} ({n}){suffix}")
        if not candidate.exists():
            return candidate
    raise FileExistsError(f"No free name available next to {path}")


def existing_ancestor(path: Path) -> Path:
    path = Path(path).absolute()
    while not path.exists() and path.parent != path:
        path = path.parent
    return path


def free_space(path: Path) -> int:
    """Free bytes on the volume that holds ``path`` (or its nearest existing parent)."""
    return shutil.disk_usage(existing_ancestor(path)).free


def is_within(root: Path, candidate: Path) -> bool:
    """True if ``candidate`` resolves to ``root`` or somewhere beneath it.

    Symlinks and ``..`` are resolved first, so this is a path-traversal guard.
    """
    try:
        root_r = Path(os.path.realpath(root))
        cand_r = Path(os.path.realpath(candidate))
    except OSError:
        return False
    try:
        cand_r.relative_to(root_r)
        return True
    except ValueError:
        return False


def _make_writable_and_retry(func, path, exc):  # rmtree onexc handler
    try:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
        func(path)
    except OSError:
        pass


def remove_tree(path: Path) -> None:
    """Recursively delete a directory tree we created (handles read-only files)."""
    p = os_path(path)
    if not os.path.lexists(p):
        return
    if os.path.islink(p) or not os.path.isdir(p):
        os.unlink(p)
        return
    if sys.version_info >= (3, 12):
        shutil.rmtree(p, onexc=_make_writable_and_retry)
    else:  # pragma: no cover
        shutil.rmtree(p, onerror=_make_writable_and_retry)


def remove_quietly(path: Path | None) -> None:
    if path is None:
        return
    try:
        p = os_path(path)
        if os.path.isdir(p) and not os.path.islink(p):
            remove_tree(path)
        elif os.path.lexists(p):
            os.unlink(p)
    except OSError:
        pass


def human_size(n: float) -> str:
    """Format a byte count with binary multiples and familiar labels (1 KB = 1024 B)."""
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{int(n)} B" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"  # pragma: no cover


def human_duration(seconds: float | None) -> str:
    if seconds is None or seconds != seconds or seconds < 0:
        return "—"
    seconds = int(round(seconds))
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m"
