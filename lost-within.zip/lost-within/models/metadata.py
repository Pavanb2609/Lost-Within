"""The ``.lostwithin`` recovery descriptor.

The descriptor is a small JSON file with two parts:

* a **public header**: format version, algorithms, KDF salt/parameters, wrapped
  data keys, maze shape and the payload's size and SHA-256. Nothing here reveals
  the original name or where in the maze the payload lives.
* a **sealed section**: AES-256-GCM encrypted under a key derived from the data
  key. It holds the original filename, size, plaintext SHA-256 and the path
  through the maze. The whole public header is its associated data, so any edit
  to the descriptor is detected once it is unlocked.

The descriptor never contains the password, the data key or the recovery key.
Every field is validated before use; unknown fields are rejected.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone

from core import __version__
from core.encryption import CIPHER_NAME, FILE_ID_LEN, NONCE_LEN, TAG_LEN, HEADER_LEN, valid_chunk_size
from core.errors import DescriptorError
from core.key_derivation import Argon2Params, KEY_LEN, SALT_LEN
from utils.validation import (b64e, is_safe_maze_component, require_b64, require_hex, require_int,
                              require_keys, require_str, require_type)

FORMAT_ID = "lostwithin-descriptor"
DESCRIPTOR_VERSION = 1
DESCRIPTOR_EXT = ".lostwithin"
MAX_DESCRIPTOR_BYTES = 1024 * 1024
MAX_PAYLOAD_SIZE = 1 << 60
WARNING_TEXT = ("This recovery descriptor is required to restore the buried item. It does not "
                "contain the password. Without it, recovery may be impossible. Back it up.")
KIND_FILE, KIND_DIR = "file", "dir"
SLOT_PASSWORD, SLOT_RECOVERY = "password", "recovery_key"


def canonical_json(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


# --------------------------------------------------------------------------- parts

@dataclass
class KeySlot:
    type: str
    salt: bytes
    nonce: bytes
    wrapped_key: bytes
    kdf: Argon2Params | None = None

    def to_dict(self) -> dict:
        d = {"type": self.type, "salt": b64e(self.salt), "nonce": b64e(self.nonce),
             "wrapped_key": b64e(self.wrapped_key)}
        if self.kdf is not None:
            d["kdf"] = self.kdf.to_dict()
        return d

    @classmethod
    def from_dict(cls, d: object) -> "KeySlot":
        d = require_keys(d, "key_slot", {"type", "salt", "nonce", "wrapped_key"}, {"kdf"})
        typ = require_str(d["type"], "key_slot.type", 32, (SLOT_PASSWORD, SLOT_RECOVERY))
        kdf = None
        if typ == SLOT_PASSWORD:
            k = require_keys(d.get("kdf"), "key_slot.kdf",
                             {"algorithm", "version", "time_cost", "memory_cost_kib", "parallelism"})
            require_str(k["algorithm"], "kdf.algorithm", 16, ("argon2id",))
            require_int(k["version"], "kdf.version", 19, 19)
            kdf = Argon2Params(
                time_cost=require_int(k["time_cost"], "kdf.time_cost", 1, Argon2Params.MAX_TIME),
                memory_cost_kib=require_int(k["memory_cost_kib"], "kdf.memory_cost_kib",
                                            Argon2Params.MIN_MEMORY, Argon2Params.MAX_MEMORY),
                parallelism=require_int(k["parallelism"], "kdf.parallelism", 1, Argon2Params.MAX_PARALLELISM),
            ).validate()
        elif "kdf" in d:
            raise DescriptorError("Recovery-key slots must not carry KDF parameters.")
        return cls(
            type=typ,
            salt=require_b64(d["salt"], "key_slot.salt", min_len=SALT_LEN, max_len=64),
            nonce=require_b64(d["nonce"], "key_slot.nonce", length=NONCE_LEN),
            wrapped_key=require_b64(d["wrapped_key"], "key_slot.wrapped_key", length=KEY_LEN + TAG_LEN),
            kdf=kdf,
        )


@dataclass
class MazeInfo:
    root_name: str
    depth: int
    name_length: int
    branching: int
    decoy_dirs: int
    decoy_files: int

    def to_dict(self) -> dict:
        return dict(self.__dict__)

    @classmethod
    def from_dict(cls, d: object) -> "MazeInfo":
        from core.maze import LIMITS  # local import avoids a cycle
        d = require_keys(d, "maze", {"root_name", "depth", "name_length", "branching", "decoy_dirs", "decoy_files"})
        root = require_str(d["root_name"], "maze.root_name", 64)
        if not is_safe_maze_component(root):
            raise DescriptorError("The maze root name is not a safe folder name.")
        return cls(root, *(require_int(d[k], f"maze.{k}", *LIMITS[k])
                           for k in ("depth", "name_length", "branching", "decoy_dirs", "decoy_files")))


@dataclass
class PayloadInfo:
    file_id: bytes
    size: int
    sha256: str
    chunk_size: int

    def to_dict(self) -> dict:
        return {"file_id": self.file_id.hex(), "size": self.size, "sha256": self.sha256,
                "chunk_size": self.chunk_size}

    @classmethod
    def from_dict(cls, d: object) -> "PayloadInfo":
        d = require_keys(d, "payload", {"file_id", "size", "sha256", "chunk_size"})
        cs = require_int(d["chunk_size"], "payload.chunk_size", 1, 1 << 30)
        if not valid_chunk_size(cs):
            raise DescriptorError("Unsupported chunk size in descriptor.")
        return cls(
            file_id=bytes.fromhex(require_hex(d["file_id"], "payload.file_id", FILE_ID_LEN)),
            size=require_int(d["size"], "payload.size", HEADER_LEN + TAG_LEN, MAX_PAYLOAD_SIZE),
            sha256=require_hex(d["sha256"], "payload.sha256", 32),
            chunk_size=cs,
        )


@dataclass
class SealedMetadata:
    """The encrypted part of the descriptor."""
    original_name: str
    kind: str
    original_size: int
    plaintext_sha256: str
    maze_path: list[str]
    payload_name: str
    created_utc: str
    maze_root_hint: str = ""
    file_count: int = 1
    skipped: int = 0

    def to_dict(self) -> dict:
        return dict(self.__dict__)

    @classmethod
    def from_dict(cls, d: object) -> "SealedMetadata":
        d = require_keys(d, "sealed", {"original_name", "kind", "original_size", "plaintext_sha256",
                                       "maze_path", "payload_name", "created_utc"},
                         {"maze_root_hint", "file_count", "skipped"})
        path = require_type(d["maze_path"], list, "sealed.maze_path")
        if not 1 <= len(path) <= 64 or not all(is_safe_maze_component(p) for p in path):
            raise DescriptorError("The stored maze path is invalid.")
        payload_name = require_str(d["payload_name"], "sealed.payload_name", 80)
        if not is_safe_maze_component(payload_name):
            raise DescriptorError("The stored payload name is invalid.")
        return cls(
            # The name is sanitized again at restore time; here we only bound it.
            original_name=require_str(d["original_name"], "sealed.original_name", 1024),
            kind=require_str(d["kind"], "sealed.kind", 8, (KIND_FILE, KIND_DIR)),
            original_size=require_int(d["original_size"], "sealed.original_size", 0, MAX_PAYLOAD_SIZE),
            plaintext_sha256=require_hex(d["plaintext_sha256"], "sealed.plaintext_sha256", 32),
            maze_path=list(path),
            payload_name=payload_name,
            created_utc=require_str(d["created_utc"], "sealed.created_utc", 40),
            maze_root_hint=require_str(d.get("maze_root_hint", ""), "sealed.maze_root_hint", 4096),
            file_count=require_int(d.get("file_count", 1), "sealed.file_count", 0, 1 << 40),
            skipped=require_int(d.get("skipped", 0), "sealed.skipped", 0, 1 << 40),
        )


# --------------------------------------------------------------------------- descriptor

@dataclass
class Descriptor:
    key_slots: list[KeySlot]
    maze: MazeInfo
    payload: PayloadInfo
    sealed_nonce: bytes = b""
    sealed_ciphertext: bytes = b""
    app: str = field(default_factory=lambda: f"Lost Within {__version__}")
    version: int = DESCRIPTOR_VERSION

    def public_dict(self) -> dict:
        return {
            "format": FORMAT_ID,
            "version": self.version,
            "app": self.app,
            "warning": WARNING_TEXT,
            "cipher": CIPHER_NAME,
            "kdf": "argon2id",
            "integrity": "sha256",
            "key_slots": [s.to_dict() for s in self.key_slots],
            "maze": self.maze.to_dict(),
            "payload": self.payload.to_dict(),
        }

    def aad(self) -> bytes:
        """Associated data binding the sealed section to every public field."""
        return b"lostwithin/v1/descriptor\x00" + canonical_json(self.public_dict())

    def to_bytes(self) -> bytes:
        d = self.public_dict()
        d["sealed"] = {"alg": "AES-256-GCM", "nonce": b64e(self.sealed_nonce),
                       "ciphertext": b64e(self.sealed_ciphertext)}
        return (json.dumps(d, indent=2, ensure_ascii=True) + "\n").encode("ascii")

    def slots(self, typ: str) -> list[KeySlot]:
        return [s for s in self.key_slots if s.type == typ]

    @property
    def has_recovery_key(self) -> bool:
        return bool(self.slots(SLOT_RECOVERY))

    @classmethod
    def from_bytes(cls, data: bytes) -> "Descriptor":
        if len(data) > MAX_DESCRIPTOR_BYTES:
            raise DescriptorError("The descriptor file is too large to be a Lost Within descriptor.")
        try:
            obj = json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise DescriptorError("This file is not a Lost Within descriptor (not valid JSON).") from None
        if not isinstance(obj, dict) or obj.get("format") != FORMAT_ID:
            raise DescriptorError("This file is not a Lost Within descriptor.")
        version = obj.get("version")
        if isinstance(version, int) and not isinstance(version, bool) and version > DESCRIPTOR_VERSION:
            raise DescriptorError(f"This descriptor was created by a newer version of Lost Within "
                                  f"(format {version}). Please update the application.")
        d = require_keys(obj, "descriptor",
                         {"format", "version", "app", "warning", "cipher", "kdf", "integrity",
                          "key_slots", "maze", "payload", "sealed"})
        require_int(d["version"], "version", DESCRIPTOR_VERSION, DESCRIPTOR_VERSION)
        require_str(d["cipher"], "cipher", 32, (CIPHER_NAME,))
        require_str(d["kdf"], "kdf", 16, ("argon2id",))
        require_str(d["integrity"], "integrity", 16, ("sha256",))
        if d["warning"] != WARNING_TEXT:
            raise DescriptorError("The descriptor's header text was modified.")
        slots_raw = require_type(d["key_slots"], list, "key_slots")
        if not 1 <= len(slots_raw) <= 8:
            raise DescriptorError("The descriptor has an invalid number of key slots.")
        slots = [KeySlot.from_dict(s) for s in slots_raw]
        if not any(s.type == SLOT_PASSWORD for s in slots):
            raise DescriptorError("The descriptor has no password key slot.")
        sealed = require_keys(d["sealed"], "sealed", {"alg", "nonce", "ciphertext"})
        require_str(sealed["alg"], "sealed.alg", 16, ("AES-256-GCM",))
        desc = cls(
            key_slots=slots,
            maze=MazeInfo.from_dict(d["maze"]),
            payload=PayloadInfo.from_dict(d["payload"]),
            sealed_nonce=require_b64(sealed["nonce"], "sealed.nonce", length=NONCE_LEN),
            sealed_ciphertext=require_b64(sealed["ciphertext"], "sealed.ciphertext",
                                          min_len=TAG_LEN + 2, max_len=64 * 1024),
            app=require_str(d["app"], "app", 64),
            version=DESCRIPTOR_VERSION,
        )
        return desc
