"""User preferences, stored as JSON in the app-data folder. Never contains secrets."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

from core.journal import app_data_dir
from core.key_derivation import KDF_PRESETS
from core.maze import MazeConfig
from utils.filesystem import atomic_write_bytes

CHUNK_CHOICES_MIB = (1, 4, 16)


@dataclass
class AppSettings:
    maze: dict = field(default_factory=lambda: MazeConfig().to_dict())
    kdf_preset: str = "standard"
    chunk_size_mib: int = 4
    long_paths: bool = False
    min_password_length: int = 12
    create_recovery_key: bool = True
    animations: bool = True
    remember_folders: bool = True
    last_output_dir: str = ""
    last_restore_dir: str = ""

    @property
    def maze_config(self) -> MazeConfig:
        return MazeConfig.from_dict(self.maze)

    @property
    def chunk_size(self) -> int:
        return self.chunk_size_mib * 1024 * 1024

    @staticmethod
    def path() -> Path:
        return app_data_dir() / "settings.json"

    @classmethod
    def load(cls) -> "AppSettings":
        s = cls()
        try:
            data = json.loads(cls.path().read_text("utf-8"))
        except (OSError, ValueError):
            return s
        if not isinstance(data, dict):
            return s
        for f in fields(cls):
            if f.name in data and isinstance(data[f.name], type(getattr(s, f.name))):
                setattr(s, f.name, data[f.name])
        # sanitize
        s.maze = MazeConfig.from_dict(s.maze if isinstance(s.maze, dict) else {}).to_dict()
        if s.kdf_preset not in KDF_PRESETS:
            s.kdf_preset = "standard"
        if s.chunk_size_mib not in CHUNK_CHOICES_MIB:
            s.chunk_size_mib = 4
        s.min_password_length = max(8, min(64, s.min_password_length))
        return s

    def save(self) -> None:
        if not self.remember_folders:
            self.last_output_dir = self.last_restore_dir = ""
        try:
            atomic_write_bytes(self.path(), json.dumps(asdict(self), indent=2).encode("utf-8"), overwrite=True)
        except OSError:
            pass
