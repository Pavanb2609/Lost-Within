# LOST WITHIN
**Secure File Maze** — *Enter. Disappear. Find your way back.*

Lost Within encrypts a file or folder with AES-256-GCM, buries the encrypted payload deep inside a
randomly generated maze of folders, and writes a small `.lostwithin` recovery descriptor. With the
descriptor and your password (or an optional Recovery Key) you can find your way back: the payload is
located, every chunk is authenticated, both SHA-256 digests are verified, and only then is the original
restored under its original name.

> **The maze is not the lock.** It keeps the name and location out of casual sight, but anyone who can
> browse the disk can find the payload. All confidentiality comes from the encryption and from the
> strength of your password. See [Limitations](#limitations).

---

## Contents

1. [Installation (Windows)](#installation-windows)
2. [Running](#running)
3. [Example usage](#example-usage)
4. [Building the .exe](#building-the-exe)
5. [Tests and test mode](#tests-and-test-mode)
6. [Architecture](#architecture)
7. [Security model](#security-model)
8. [File formats](#file-formats)
9. [Interrupted operations](#interrupted-operations)
10. [Limitations](#limitations)

---

## Installation (Windows)

Requires **Python 3.12+** (from python.org; tick *“Add python.exe to PATH”*) on Windows 10 or 11.

```bat
cd lost-within
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

macOS/Linux work the same way (`python3 -m venv .venv && source .venv/bin/activate`); the app is
designed and path-limited for Windows but is cross-platform.

## Running

```bat
:: desktop app
python main.py

:: open a file or descriptor directly (also works by dragging it onto LostWithin.exe)
python main.py "D:\backups\example.zip.lostwithin"

:: safe end-to-end test with small files
python main.py --self-test
```

### Command line

The same engine is available headless — handy for scripting or very large jobs on a server:

```bat
python main.py bury "D:\Projects\thesis.zip" "E:\Vault" --depth 10 --branching 3 --recovery-key
python main.py inspect "E:\Vault\thesis.zip.lostwithin"
python main.py recover "E:\Vault\thesis.zip.lostwithin" "D:\Restored"
python main.py recover "E:\Vault\thesis.zip.lostwithin" --verify-only
python main.py recover "E:\Vault\thesis.zip.lostwithin" "D:\Restored" --use-recovery-key --on-conflict rename
```

Passwords are prompted for (hidden), never accepted as arguments. For automation,
`--password-env VARNAME` reads it from an environment variable.

## Example usage

**Bury**

1. Drop `example.zip` (or a whole folder) onto the window, or use *Browse Files / Browse Folder*.
2. Press **BURY FILE**. Choose the maze location, the descriptor name/folder and a passphrase.
   Tick *Recovery Key* if you want a second, independent way to unlock.
3. **NEXT: MAZE** — choose depth, folder-name length, branching and decoys. The page validates the
   configuration live (path length against the Windows limit, folder count) and shows a preview.
4. **ENTER THE MAZE**. Progress shows bytes, percentage, speed, ETA and the current stage.
5. Done: note the descriptor path and, if created, the Recovery Key (shown once — copy or save it).

Result on disk (names are random every time):

```text
E:\Vault\
├── example.zip.lostwithin            ← recovery descriptor (keep it safe, back it up)
└── LostWithin_q8Kp91aZ\
    ├── aZ72Lm9Q\ …                   ← dead ends and decoy passages
    ├── P91xQa3k\
    │   └── mK72Lp0w\
    │       └── …\
    │           └── X3fq81Lw.dat      ← the encrypted payload
    └── …                             ← decoy .dat files of random bytes
```

**Recover**

1. Press **RECOVER** (or drop the `.lostwithin` file onto the window).
2. The descriptor's public header is shown, and the maze is located automatically if it sits next to
   the descriptor. If you moved it, use *Select maze folder…*.
3. Enter the password (or the Recovery Key), choose where to restore, press **FIND YOUR WAY BACK**.

```text
✓ You found your way back.

File recovered successfully.

Original file:
example.zip

Integrity:
SHA-256 verified
```

If a file with that name already exists you are asked to *Keep both* (saved as `example (1).zip`)
or *Replace* (with a second confirmation). Folders are never overwritten. *Verify only* decrypts and
checks everything without writing a file.

## Building the .exe

From the activated virtual environment:

```bat
build.bat
```

which runs the tests and then:

```bat
pyinstaller --noconfirm --clean --windowed --onefile ^
  --name LostWithin ^
  --icon assets\icons\lost_within.ico ^
  --add-data "assets;assets" ^
  --collect-submodules argon2 ^
  --exclude-module pytest --exclude-module PIL --exclude-module tkinter ^
  main.py
```

The result is `dist\LostWithin.exe` (≈70 MB, no installation needed). It also accepts the CLI
commands when started from a terminal, e.g. `dist\LostWithin.exe --self-test`.
Windows SmartScreen may warn about an unsigned executable; sign it with your own code-signing
certificate for distribution. Antivirus heuristics occasionally flag PyInstaller one-file builds;
dropping `--onefile` (a folder build) usually avoids that.

## Tests and test mode

```bat
python -m pytest          :: 75 unit tests, ~1–2 seconds
python main.py --self-test
```

* `tests/test_encryption.py` — streaming AES-GCM round trips at every chunk boundary, bit flips,
  header tampering, truncation (including exactly at a chunk boundary), appended data, swapped
  chunks, Argon2id determinism/normalisation/reference-implementation equality, recovery-key typos.
* `tests/test_maze.py` — maze shape, case-insensitive name uniqueness, unpredictability, path-length
  and folder-count validation, filename sanitisation (path traversal, reserved device names).
* `tests/test_recovery.py` — full bury → recover workflows: files, folders with Unicode names,
  symlinks skipped, wrong password, recovery key, descriptor tampering, unknown fields, KDF DoS
  values, malicious stored names, corrupted/truncated/missing payloads, moved mazes and renamed
  folders, conflict policies, verify-only, cancellation clean-up, crash journal.

**Test mode** (`--self-test`, or *Settings → Test mode → Run self-test* in the app) runs 15 checks
of the complete bury → maze → recovery workflow on small generated files inside a temporary folder
that is deleted afterwards. It never touches your files. It uses deliberately weak Argon2id settings
and 64 KiB chunks so multi-chunk paths are exercised in a couple of seconds.

The engine has also been exercised with a 6 GB file: bury and recovery each took ~45 s on a 2-core
VM, the restored file was byte-identical, and peak memory was ~90 MB (64 MiB of which is Argon2id).
Memory use does not grow with file size, so 70 GB+ files are handled the same way.

## Architecture

```text
lost-within/
├── main.py                 entry point: GUI, or CLI when arguments are given
├── cli.py                  bury / recover / inspect / --self-test
├── core/                   engine — no Qt imports, fully testable headless
│   ├── encryption.py       chunked AES-256-GCM (STREAM), key wrapping, sealed JSON
│   ├── key_derivation.py   Argon2id presets, HKDF subkeys, Recovery Key encoding
│   ├── maze.py             maze config, validation, planning, creation
│   ├── burial.py           bury orchestration (+ rollback)
│   ├── recovery.py         recover orchestration (unlock, locate, decrypt, verify, restore)
│   ├── hashing.py          streaming SHA-256, constant-time digest compare
│   ├── streaming.py        progress tracker (speed/ETA), cancel token, chunked I/O
│   ├── journal.py          crash journal for interrupted operations
│   ├── selftest.py         test mode
│   └── errors.py           user-facing exception types
├── models/
│   ├── metadata.py         .lostwithin descriptor: strict parsing and validation
│   └── settings.py         user preferences (JSON, no secrets)
├── utils/
│   ├── random_names.py     CSPRNG names (secrets), Windows reserved names
│   ├── validation.py       metadata field checks, filename sanitising, password strength
│   └── filesystem.py       atomic writes, no-clobber rename, long paths, safe deletion
├── ui/                     PySide6 front end
│   ├── main_window.py      navigation, drag & drop, bury/recover controllers
│   ├── home_page.py        Home
│   ├── bury_page.py        Bury File
│   ├── maze_page.py        Maze Configuration (+ live preview)
│   ├── progress_page.py    Encryption Progress / Recovery Progress / results
│   ├── recovery_page.py    Recovery
│   ├── settings_page.py    Settings (+ self-test, interrupted-operation clean-up)
│   ├── about_page.py       About Lost Within
│   ├── widgets.py          drop zone, maze visualisation, progress bar, backdrop
│   ├── workers.py          QThread runner (UI never blocks)
│   └── styles.py           palette, fonts, stylesheet
├── tests/                  pytest suites
├── tools/make_icon.py      regenerates the icon
└── assets/icons/           app icon (.ico/.png), UI chevrons
```

Long operations run on a worker `QThread`. The engine reports progress through a callback that is
throttled to 10 Hz and checks a cancellation token between chunks, so cancelling is immediate and
always followed by clean-up.

## Security model

### Key hierarchy

```text
password ──Argon2id(salt, 64 MiB, t=3, p=4)──► KEK_pw ─┐
                                                        ├── AES-256-GCM wrap ──► DEK (random 256-bit)
Recovery Key (256-bit) ──HKDF-SHA256(salt)───► KEK_rk ─┘                          │
                                                       HKDF(DEK, file_id, "payload")  ─► payload key
                                                       HKDF(DEK, file_id, "metadata") ─► metadata key
```

* A fresh random **data key (DEK)** and **file ID** are generated per burial; they never touch disk
  unwrapped. Because each payload has its own key, nonces can never repeat under one key.
* Argon2id parameters are stored per burial (presets: Standard = RFC 9106's 64 MiB/t=3/p=4,
  Strong = 256 MiB, Maximum = 1 GiB). Values read from a descriptor are bounded so a crafted file
  cannot make the app allocate unbounded memory.
* Passwords are Unicode-NFC-normalised so the same password typed on another system still works.
* The **Recovery Key** is 256 random bits shown as `LW1-XXXX-…` (base32 + 24-bit checksum that
  catches typos). It is never written to disk unless you choose *Save as text file*.

### Payload encryption (large-file safe)

AES-256-GCM from the `cryptography` library, framed with the **STREAM** construction
(Hoang–Reyhanitabar–Rogaway–Vizár, as used by Tink and age): the file is processed in 4 MiB chunks,
each sealed with nonce = `prefix(7) ‖ counter(4) ‖ last-flag(1)` and the payload header as associated
data. No custom cryptography is implemented; only the framing. This detects:

| Failure | How it is detected |
|---|---|
| Wrong password | the key slot fails to unwrap (GCM tag), before any file is read |
| Modified ciphertext | that chunk's GCM tag fails |
| Reordered/removed chunks | the chunk counter is part of each nonce |
| Truncated / incomplete file | the last remaining chunk was not sealed as final; size pre-check |
| Appended data | the real final chunk fails when treated as non-final |
| Corrupted file | GCM tags + SHA-256 of the whole payload |
| Edited descriptor | the sealed metadata authenticates every public field (AAD) |
| Wrong payload for descriptor | random file ID in the authenticated header |

SHA-256 is computed over the ciphertext and over the original data while streaming (no extra pass)
and compared in constant time after decryption.

### What the descriptor reveals

The public header contains format/version, algorithms, KDF salt and parameters, wrapped keys, the
maze's root folder name and shape, the payload size and its SHA-256. The **original filename, its
size, its SHA-256, the creation time and the path through the maze are encrypted.** The password,
DEK and Recovery Key are never stored.

### Restore safety

* Restored names are sanitised: path separators, `..`, drive letters, characters Windows rejects
  and reserved device names (`CON`, `NUL`, …) can never escape or misbehave.
* Maze paths read from the descriptor must be plain random-name components and must resolve inside
  the maze root (symlinks resolved).
* Data is decrypted into a hidden temporary file and moved into place only after every check passes.
  Folders are packed as tar and extracted with Python's `data` extraction filter (no absolute paths,
  no `..`, no links that escape, no device files). Symbolic links are skipped when burying.
* Nothing is overwritten without explicit confirmation; folders are never overwritten.

### Process hygiene

Passwords are never logged, printed, saved in settings or included in error messages or reprs.
Password fields are cleared as soon as an operation starts. Randomness for keys, salts, nonces and
every maze name comes from the OS CSPRNG (`secrets`, `os.urandom`). MD5/SHA-1 are not used.

## File formats

### `.lostwithin` descriptor (JSON)

```json
{
  "format": "lostwithin-descriptor",
  "version": 1,
  "app": "Lost Within 1.0.0",
  "warning": "This recovery descriptor is required to restore …",
  "cipher": "AES-256-GCM-STREAM",
  "kdf": "argon2id",
  "integrity": "sha256",
  "key_slots": [
    {"type": "password", "salt": "…", "nonce": "…", "wrapped_key": "…",
     "kdf": {"algorithm": "argon2id", "version": 19, "time_cost": 3, "memory_cost_kib": 65536, "parallelism": 4}},
    {"type": "recovery_key", "salt": "…", "nonce": "…", "wrapped_key": "…"}
  ],
  "maze": {"root_name": "LostWithin_q8Kp91aZ", "depth": 8, "name_length": 8, "branching": 3,
           "decoy_dirs": 24, "decoy_files": 12},
  "payload": {"file_id": "…hex…", "size": 1048649, "sha256": "…", "chunk_size": 4194304},
  "sealed": {"alg": "AES-256-GCM", "nonce": "…", "ciphertext": "…"}
}
```

`sealed` decrypts to `original_name`, `kind` (file/dir), `original_size`, `plaintext_sha256`,
`maze_path`, `payload_name`, `created_utc`, `maze_root_hint`, `file_count`, `skipped`.
Parsing is strict: unknown fields, wrong types, out-of-range values and newer format versions are
rejected with a clear message.

### Payload (`*.dat` inside the maze)

```text
header (28 B): version u8 | chunk_size u32 BE | file_id 16 B | nonce_prefix 7 B
chunks:        AES-256-GCM(chunk_i) ‖ tag (16 B) …   (last chunk sealed with last-flag = 1)
```

The payload contains no magic bytes or plaintext names; it is indistinguishable from the decoy files
except by size.

## Interrupted operations

* **Cancel**: everything created so far (maze, partial payload, partial restore) is removed.
* **Errors** (disk full, permission denied, drive unplugged): the same rollback runs, and the
  message says what happened.
* **Crashes / power loss**: before creating anything, each operation records what it is about to
  create in a journal under `%APPDATA%\LostWithin\journal`. On the next launch the app offers to
  remove leftovers (also under *Settings → Interrupted operations*). A burial whose descriptor was
  already written is recognised as complete and is never removed.
* Writes are atomic where practical: the payload is written as `*.partial`, fsynced, then renamed;
  the descriptor is written to a temporary file and renamed (its appearance is the commit point);
  recovered files appear under their real name only after verification.
* Free disk space is checked before starting.

## Limitations

Please read these before relying on Lost Within.

* **The maze is obfuscation, not security.** The payload is usually the largest file in the maze and
  can be found by anyone with disk access. Its size, timestamps and the existence of the maze are
  visible.
* **Your password is the security.** Argon2id makes guessing expensive, but someone holding the
  descriptor can attempt guesses offline indefinitely. Use a long passphrase (4+ random words).
* **Lose the descriptor and recovery may be impossible.** It contains the wrapped data key. Back it
  up, ideally separately from the maze. A copy of the descriptor is harmless without the password.
* **No forward secrecy / password changes.** Changing a password means re-burying. (The key
  hierarchy would allow adding key slots later without re-encrypting.)
* **Compromised machines are out of scope.** Malware, keyloggers or anyone with access to your
  unlocked session can capture the password or the recovered data.
* **Memory hygiene is best-effort.** Python cannot reliably wipe passwords and keys from RAM; they
  may persist in memory, the page file or hibernation file until overwritten.
* **Originals are not deleted.** Lost Within never deletes your original. Secure deletion is not
  reliable on SSDs, flash drives, journaling file systems or cloud-synced folders.
* **Descriptor names can leak.** The default descriptor name contains the original filename; use
  *Randomize* if that matters. Folder burials store owner names as empty.
* **AES-GCM is not key-committing.** This matters only for exotic multi-key attacks that do not
  apply to a single-recipient file tool, but it is noted for completeness.
* **Not audited.** It relies on the widely reviewed `cryptography` library (OpenSSL) and standard
  constructions, and has an extensive test suite, but the application itself has not had an
  independent security audit.
* **Long paths.** By default generated paths stay under 240 characters. Long-path mode allows
  deeper mazes, but some Windows tools cannot copy or delete such paths.
* Folder recovery needs roughly twice the folder's size in free space (the authenticated archive is
  verified before it is unpacked).
